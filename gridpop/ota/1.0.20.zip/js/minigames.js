'use strict';
// =====================================================================
//  MINI GAMES ("Assorti") — a hub of small candy games, kept fully
//  separate from the block-puzzle engine so it can't break it.
//  DOM/CSS based. Reuses the candy palette (TILE_COLORS) and SFX.
// =====================================================================
const MiniGames = (() => {
  const PAL = TILE_COLORS;
  const $ = id => document.getElementById(id);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const sfx = (n, ...a) => { try { if (typeof Sfx !== 'undefined' && Sfx[n]) Sfx[n](...a); } catch (e) {} };
  const vibe = n => { try { if (typeof Haptic !== 'undefined' && Haptic[n]) Haptic[n](); } catch (e) {} };
  const rnd = n => (Math.random() * n) | 0;
  const getBest = k => +localStorage.getItem('gp_mg_' + k) || 0;
  const setBest = (k, v) => { if (v > getBest(k)) localStorage.setItem('gp_mg_' + k, v); };
  function candyCss(ci) {
    const c = PAL[ci % PAL.length];
    return `background:linear-gradient(${c.light},${c.base});box-shadow:inset 0 -5px 0 ${c.dark},inset 0 4px 0 rgba(255,255,255,.45);`;
  }

  // ---------------- navigation ----------------
  let active = null;   // current game key (for keyboard input)
  function openHub() { renderHub(); $('menu').classList.remove('show'); $('mini').classList.remove('show'); $('games').classList.add('show'); active = null; sfx('button'); }
  function backToMenu() { $('games').classList.remove('show'); $('mini').classList.remove('show'); $('menu').classList.add('show'); active = null; sfx('button'); }
  function openGame(key) { $('games').classList.remove('show'); $('mini').classList.add('show'); active = key; GAMES[key].start(); sfx('button'); vibe('light'); }
  function backToHub() { $('mini').classList.remove('show'); renderHub(); $('games').classList.add('show'); active = null; sfx('button'); }

  const GAME_LIST = [
    { key: 'blast', name: 'Candy Blast', tag: 'Tap to pop', c: 0 },
    { key: 'merge', name: '2048 Merge', tag: 'Swipe to join', c: 4 },
    { key: 'memory', name: 'Memory', tag: 'Find the pairs', c: 3 },
    { key: 'sort', name: 'Color Sort', tag: 'Sort the tubes', c: 5 },
  ];
  function renderHub() {
    const g = $('gamesGrid'); g.innerHTML = '';
    GAME_LIST.forEach(it => {
      const card = el('button', 'game-card');
      const best = getBest(it.key);
      card.innerHTML =
        `<div class="gc-art">${[0, 1, 2, 3].map(i => `<span style="${candyCss((it.c + i) % PAL.length)}"></span>`).join('')}</div>` +
        `<b>${it.name}</b><small>${it.tag}</small>` +
        (best ? `<em class="gc-best">Best ${best}</em>` : '');
      card.onclick = () => openGame(it.key);
      g.appendChild(card);
    });
  }

  // shell helpers -----------------------------------------------------
  function shell(title, scoreHtml) {
    $('miniTitle').textContent = title;
    $('miniScore').innerHTML = scoreHtml || '';
    // #miniBoard is a flex wrapper that centres an inner board element; the inner
    // div (not #miniBoard itself) carries the grid/tube class, so the id selector
    // on #miniBoard can't override its display.
    const host = $('miniBoard'); host.innerHTML = '';
    const b = el('div', 'mini-inner'); host.appendChild(b);
    $('miniFoot').innerHTML = '';
    return b;
  }
  function footButton(label, fn) {
    const f = $('miniFoot'); const btn = el('button', 'mini-btn', label); btn.onclick = fn; f.appendChild(btn); return btn;
  }
  function toastMini(text, color) {
    const o = el('div', 'mini-pop', text); if (color) o.style.color = color;
    $('mini').appendChild(o); setTimeout(() => o.remove(), 1100);
  }

  // =================================================================
  //  1) CANDY BLAST — tap a group of 2+ same-colour candies to pop
  // =================================================================
  const Blast = (() => {
    const COLS = 8, ROWS = 9, NC = 5;
    let grid, score;
    function start() {
      score = 0;
      grid = [];
      for (let r = 0; r < ROWS; r++) { grid[r] = []; for (let c = 0; c < COLS; c++) grid[r][c] = rnd(NC); }
      draw();
    }
    function draw() {
      const b = shell('Candy Blast', scoreHtml());
      b.className = 'grid-board';
      b.style.setProperty('--cols', COLS);
      b.style.maxWidth = Math.min(COLS * 48, 400) + 'px';
      for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
        const v = grid[r][c];
        const cell = el('button', 'cell');
        if (v < 0) { cell.style.visibility = 'hidden'; }
        else { cell.style.cssText += candyCss(v); cell.onclick = () => tap(r, c); }
        b.appendChild(cell);
      }
      footButton('New game', start);
    }
    function scoreHtml() { return `<i></i>${score} <small>best ${getBest('blast')}</small>`; }
    function group(r, c) {
      const col = grid[r][c]; if (col < 0) return [];
      const seen = new Set(), stack = [[r, c]], out = [];
      while (stack.length) {
        const [y, x] = stack.pop(), k = y * COLS + x;
        if (seen.has(k)) continue; seen.add(k);
        if (y < 0 || x < 0 || y >= ROWS || x >= COLS || grid[y][x] !== col) continue;
        out.push([y, x]);
        stack.push([y + 1, x], [y - 1, x], [y, x + 1], [y, x - 1]);
      }
      return out;
    }
    function tap(r, c) {
      const grp = group(r, c);
      if (grp.length < 2) { sfx('nope'); vibe('light'); return; }
      grp.forEach(([y, x]) => grid[y][x] = -1);
      score += grp.length * (grp.length + 1);
      setBest('blast', score);
      sfx('clear', Math.min(grp.length, 4), 1); vibe(grp.length >= 5 ? 'heavy' : 'medium');
      gravity();
      draw();
    }
    function gravity() {
      for (let c = 0; c < COLS; c++) {
        const colv = [];
        for (let r = ROWS - 1; r >= 0; r--) if (grid[r][c] >= 0) colv.push(grid[r][c]);
        for (let r = ROWS - 1; r >= 0; r--) grid[r][c] = colv[ROWS - 1 - r] != null ? colv[ROWS - 1 - r] : rnd(NC);
      }
    }
    return { start };
  })();

  // =================================================================
  //  2) 2048 MERGE — swipe to slide & merge equal candies
  // =================================================================
  const Merge = (() => {
    const N = 4;
    let g, score;
    function start() { g = Array.from({ length: N }, () => Array(N).fill(0)); score = 0; spawn(); spawn(); draw(); }
    function spawn() {
      const empty = [];
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!g[r][c]) empty.push([r, c]);
      if (!empty.length) return false;
      const [r, c] = empty[rnd(empty.length)]; g[r][c] = Math.random() < 0.9 ? 2 : 4; return true;
    }
    function slideRow(row) {
      let a = row.filter(v => v); let out = []; let gained = 0;
      for (let i = 0; i < a.length; i++) {
        if (i + 1 < a.length && a[i] === a[i + 1]) { out.push(a[i] * 2); gained += a[i] * 2; i++; }
        else out.push(a[i]);
      }
      while (out.length < N) out.push(0);
      return { out, gained };
    }
    function move(dir) {
      // dir: 0 left,1 right,2 up,3 down. Normalise to left-slide.
      const before = JSON.stringify(g);
      const rows = [];
      for (let i = 0; i < N; i++) {
        let line = [];
        for (let j = 0; j < N; j++) {
          if (dir === 0) line.push(g[i][j]);
          else if (dir === 1) line.push(g[i][N - 1 - j]);
          else if (dir === 2) line.push(g[j][i]);
          else line.push(g[N - 1 - j][i]);
        }
        rows.push(line);
      }
      rows.forEach((line, i) => {
        const { out, gained } = slideRow(line); score += gained;
        for (let j = 0; j < N; j++) {
          if (dir === 0) g[i][j] = out[j];
          else if (dir === 1) g[i][N - 1 - j] = out[j];
          else if (dir === 2) g[j][i] = out[j];
          else g[N - 1 - j][i] = out[j];
        }
      });
      if (JSON.stringify(g) === before) return;   // nothing moved
      setBest('merge', score);
      sfx('place', 2); vibe('light'); spawn(); draw();
      if (!canMove()) { toastMini('No moves!', '#ff9'); sfx('lose'); }
    }
    function canMove() {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        if (!g[r][c]) return true;
        if (c + 1 < N && g[r][c] === g[r][c + 1]) return true;
        if (r + 1 < N && g[r][c] === g[r + 1][c]) return true;
      }
      return false;
    }
    function draw() {
      const b = shell('2048 Merge', `<i></i>${score} <small>best ${getBest('merge')}</small>`);
      b.className = 'grid-board';
      b.style.setProperty('--cols', N); b.style.maxWidth = '360px';
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const v = g[r][c]; const cell = el('div', 'cell merge-cell');
        if (v) { const lvl = Math.log2(v) - 1; cell.style.cssText += candyCss(lvl % PAL.length); cell.innerHTML = `<span>${v}</span>`; cell.classList.add('pop'); }
        b.appendChild(cell);
      }
      // swipe input
      let sx = 0, sy = 0;
      b.onpointerdown = e => { sx = e.clientX; sy = e.clientY; };
      b.onpointerup = e => {
        const dx = e.clientX - sx, dy = e.clientY - sy;
        if (Math.abs(dx) < 20 && Math.abs(dy) < 20) return;
        if (Math.abs(dx) > Math.abs(dy)) move(dx > 0 ? 1 : 0); else move(dy > 0 ? 3 : 2);
      };
      footButton('New game', start);
    }
    function key(e) {
      const m = { ArrowLeft: 0, ArrowRight: 1, ArrowUp: 2, ArrowDown: 3 };
      if (m[e.key] != null) { e.preventDefault(); move(m[e.key]); }
    }
    return { start, key };
  })();

  // =================================================================
  //  3) MEMORY MATCH — flip candy cards, find the pairs
  // =================================================================
  const Memory = (() => {
    const COLS = 4, ROWS = 3, PAIRS = 6;
    let deck, state, first, lock, moves, matched;
    function start() {
      const faces = [];
      for (let i = 0; i < PAIRS; i++) faces.push(i, i);
      for (let i = faces.length - 1; i > 0; i--) { const j = rnd(i + 1);[faces[i], faces[j]] = [faces[j], faces[i]]; }
      deck = faces; state = faces.map(() => 'down'); first = -1; lock = false; moves = 0; matched = 0;
      draw();
    }
    function flip(i) {
      if (lock || state[i] !== 'down') return;
      state[i] = 'up'; sfx('pick'); vibe('light'); draw();
      if (first < 0) { first = i; return; }
      moves++;
      if (deck[first] === deck[i]) {
        state[first] = state[i] = 'matched'; matched++; first = -1; sfx('coin'); vibe('medium'); draw();
        if (matched === PAIRS) { setBest('memory', bestScore()); setTimeout(() => { toastMini('You win! ' + moves + ' moves', '#86e391'); sfx('win'); vibe('success'); }, 200); }
      } else {
        lock = true; const a = first, bI = i; first = -1;
        setTimeout(() => { state[a] = 'down'; state[bI] = 'down'; lock = false; draw(); }, 720);
      }
    }
    function bestScore() { const prev = getBest('memory'); const s = Math.max(1, 100 - moves * 2); return prev ? Math.min(prev, moves) || moves : moves; }
    function draw() {
      const b = shell('Memory', `<i></i>${moves} <small>moves</small>`);
      b.className = 'grid-board';
      b.style.setProperty('--cols', COLS); b.style.maxWidth = '360px';
      for (let i = 0; i < deck.length; i++) {
        const card = el('button', 'card');
        if (state[i] === 'down') { card.classList.add('face-down'); card.onclick = () => flip(i); }
        else { card.style.cssText += candyCss(deck[i]); card.innerHTML = '<span class="pip"></span>'; if (state[i] === 'matched') card.classList.add('matched'); }
        b.appendChild(card);
      }
      footButton('New game', start);
    }
    return { start };
  })();

  // =================================================================
  //  4) COLOR SORT — pour candies so each tube is one colour
  // =================================================================
  const Sort = (() => {
    const CAP = 4, COLORS = 5, EMPTY = 2;
    let tubes, sel, moves;
    function start() {
      const NT = COLORS + EMPTY;
      tubes = Array.from({ length: NT }, () => []);
      // start solved, then scramble with reverse single-unit moves -> always solvable
      for (let i = 0; i < COLORS; i++) for (let k = 0; k < CAP; k++) tubes[i].push(i);
      for (let n = 0; n < 200; n++) {
        const src = rnd(NT), dst = rnd(NT);
        if (src !== dst && tubes[src].length && tubes[dst].length < CAP) tubes[dst].push(tubes[src].pop());
      }
      sel = -1; moves = 0; draw();
    }
    function solved() {
      return tubes.every(t => t.length === 0 || (t.length === CAP && t.every(v => v === t[0])));
    }
    function tap(i) {
      if (sel < 0) { if (tubes[i].length) { sel = i; sfx('pick'); vibe('light'); draw(); } return; }
      if (sel === i) { sel = -1; draw(); return; }
      const src = tubes[sel], dst = tubes[i];
      const col = src[src.length - 1];
      if (dst.length < CAP && (dst.length === 0 || dst[dst.length - 1] === col)) {
        let moved = 0;
        while (src.length && dst.length < CAP && src[src.length - 1] === col) { dst.push(src.pop()); moved++; }
        if (moved) { moves++; sfx('place', 2); vibe('light'); }
      } else { sfx('nope'); }
      sel = -1; draw();
      if (solved()) { setBest('sort', Math.max(1, 200 - moves)); setTimeout(() => { toastMini('Solved! ' + moves + ' moves', '#86e391'); sfx('win'); vibe('success'); }, 150); }
    }
    function draw() {
      const b = shell('Color Sort', `<i></i>${moves} <small>moves</small>`);
      b.className = 'tube-board';
      tubes.forEach((t, i) => {
        const tube = el('button', 'tube' + (sel === i ? ' sel' : ''));
        for (let k = CAP - 1; k >= 0; k--) {
          const seg = el('span', 'seg');
          if (t[k] != null) seg.style.cssText = candyCss(t[k]); else seg.classList.add('empty');
          tube.appendChild(seg);
        }
        tube.onclick = () => tap(i);
        b.appendChild(tube);
      });
      footButton('Restart', start);
    }
    return { start };
  })();

  const GAMES = { blast: Blast, merge: Merge, memory: Memory, sort: Sort };

  // keyboard (desktop) — only 2048 uses it
  window.addEventListener('keydown', e => { if ($('mini').classList.contains('show') && active === 'merge') Merge.key(e); });

  // wiring
  function wire() {
    const m = $('mAssorti'); if (m) m.onclick = openHub;
    const gb = $('gamesBack'); if (gb) gb.onclick = backToMenu;
    const mb = $('miniBack'); if (mb) mb.onclick = backToHub;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();

  return { open: openHub };
})();
