'use strict';
// =====================================================================
//  MINI GAMES ("Assorti") — a hub of small candy games, kept fully
//  separate from the block-puzzle engine. DOM/CSS, juicy & animated.
// =====================================================================
const MiniGames = (() => {
  const PAL = TILE_COLORS;
  const $ = id => document.getElementById(id);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const sfx = (n, ...a) => { try { if (typeof Sfx !== 'undefined' && Sfx[n]) Sfx[n](...a); } catch (e) {} };
  const vibe = n => { try { if (typeof Haptic !== 'undefined' && Haptic[n]) Haptic[n](); } catch (e) {} };
  const rnd = n => (Math.random() * n) | 0;
  const getBest = k => +localStorage.getItem('gp_mg_' + k) || 0;
  const setBest = (k, v) => { if (v > getBest(k)) localStorage.setItem('gp_mg_' + k, v); };
  // glossy candy fill: a soft shine spot + gradient body + rounded 3D shadow
  function candyCss(ci) {
    const c = PAL[ci % PAL.length];
    return `background:radial-gradient(circle at 34% 24%, rgba(255,255,255,.65), rgba(255,255,255,0) 46%), linear-gradient(${c.light},${c.base});` +
      `box-shadow:inset 0 -5px 0 ${c.dark}, inset 0 4px 0 rgba(255,255,255,.32);`;
  }
  // floating "+score" text + a little candy-coloured spark burst at (cx,cy) viewport coords
  function burst(cx, cy, text, color) {
    const host = $('mini');
    if (text) { const p = el('div', 'mg-float', text); p.style.left = cx + 'px'; p.style.top = cy + 'px'; if (color) p.style.color = color; host.appendChild(p); setTimeout(() => p.remove(), 760); }
    for (let i = 0; i < 9; i++) {
      const s = el('span', 'mg-spark'); const a = Math.random() * 6.283, d = 18 + Math.random() * 38;
      s.style.left = cx + 'px'; s.style.top = cy + 'px';
      s.style.setProperty('--dx', (Math.cos(a) * d).toFixed(1) + 'px');
      s.style.setProperty('--dy', (Math.sin(a) * d).toFixed(1) + 'px');
      s.style.background = PAL[rnd(PAL.length)].base;
      host.appendChild(s); setTimeout(() => s.remove(), 600);
    }
  }
  const centerOf = node => { const r = node.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; };

  // ---------------- navigation ----------------
  let active = null;
  function openHub() { renderHub(); $('menu').classList.remove('show'); $('mini').classList.remove('show'); $('games').classList.add('show'); active = null; sfx('button'); }
  function backToMenu() { $('games').classList.remove('show'); $('mini').classList.remove('show'); $('menu').classList.add('show'); active = null; sfx('button'); }
  function openGame(key) { $('games').classList.remove('show'); $('mini').classList.add('show'); active = key; GAMES[key].start(); sfx('button'); vibe('light'); }
  function backToHub() { $('mini').classList.remove('show'); renderHub(); $('games').classList.add('show'); active = null; sfx('button'); }

  const GAME_LIST = [
    { key: 'blast', name: 'Candy Blast', tag: 'Tap to pop', c: 0 },
    { key: 'merge', name: '2048 Merge', tag: 'Swipe to join', c: 4 },
    { key: 'memory', name: 'Memory', tag: 'Find the pairs', c: 3 },
    { key: 'sort', name: 'Color Sort', tag: 'Sort the tubes', c: 5 },
  ];
  function renderHub() {
    const g = $('gamesGrid'); g.innerHTML = '';
    GAME_LIST.forEach(it => {
      const card = el('button', 'game-card');
      const best = getBest(it.key);
      card.innerHTML =
        `<div class="gc-art">${[0, 1, 2, 3].map(i => `<span style="${candyCss((it.c + i) % PAL.length)}"></span>`).join('')}</div>` +
        `<b>${it.name}</b><small>${it.tag}</small>` +
        (best ? `<em class="gc-best">Best ${best}</em>` : '');
      card.onclick = () => openGame(it.key);
      g.appendChild(card);
    });
  }

  function shell(title, scoreHtml) {
    $('miniTitle').textContent = title;
    $('miniScore').innerHTML = scoreHtml || '';
    const host = $('miniBoard'); host.innerHTML = '';
    const b = el('div', 'mini-inner'); host.appendChild(b);
    $('miniFoot').innerHTML = '';
    return b;
  }
  function footButton(label, fn) { const btn = el('button', 'mini-btn', label); btn.onclick = fn; $('miniFoot').appendChild(btn); return btn; }
  function toastMini(text, color) { const o = el('div', 'mini-pop', text); if (color) o.style.color = color; $('mini').appendChild(o); setTimeout(() => o.remove(), 1200); }

  // =================================================================
  //  1) CANDY BLAST
  // =================================================================
  // Canvas match-3: SWIPE a candy to swap with a neighbour; 3+ in a line clears
  // with cascading combos. Reuses the main game's glossy candy art (drawTile).
  const Blast = (() => {
    const COLS = 8, ROWS = 9, NC = 5;
    let cv, ctx, DPR, cs = 44, bw, bh, hudH = 52;
    let grid, offX, offY, parts, pops, score, level, target, moves, shake, flash, winT, lock, gen = 0, drag = null;
    const tileColor = i => TILE_COLORS[i % TILE_COLORS.length].base;
    function setLevel(n) { level = n; target = 150 + n * 150; moves = 18 + Math.min(n, 12); }

    function start() {
      score = 0; setLevel(1); mount(); newBoard();
      const g = ++gen; let last = performance.now();
      (function loop(t) {
        if (g !== gen || active !== 'blast' || !$('mini').classList.contains('show')) return;
        let dt = (t - last) / 1000; last = t; if (dt > 0.05) dt = 0.05;
        update(dt); render(); requestAnimationFrame(loop);
      })(last);
    }
    function mount() {
      $('miniTitle').textContent = 'Candy Blast'; $('miniScore').innerHTML = '';
      const host = $('miniBoard'); host.innerHTML = '';
      cv = document.createElement('canvas'); cv.className = 'mini-canvas'; cv.style.touchAction = 'none';
      host.appendChild(cv);
      $('miniFoot').innerHTML = ''; footButton('New game', () => { score = 0; setLevel(1); newBoard(); });
      DPR = Math.min(window.devicePixelRatio || 1, 2);
      const wcss = Math.min(window.innerWidth * 0.92, 384);
      cs = Math.floor(wcss / COLS); bw = cs * COLS; bh = hudH + cs * ROWS;
      cv.style.width = bw + 'px'; cv.style.height = bh + 'px'; cv.width = bw * DPR; cv.height = bh * DPR;
      ctx = cv.getContext('2d'); ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      cv.onpointerdown = onDown; cv.onpointerup = onUp; cv.onpointercancel = () => { drag = null; };
    }
    function newBoard() {
      grid = []; offX = []; offY = []; parts = []; pops = []; shake = 0; flash = 0; winT = 0; lock = false; drag = null;
      for (let r = 0; r < ROWS; r++) { grid[r] = []; offX[r] = []; offY[r] = []; for (let c = 0; c < COLS; c++) { grid[r][c] = rnd(NC); offX[r][c] = 0; offY[r][c] = -(r + 2) * cs - Math.random() * cs * 3; } }
      let m, guard = 0; while ((m = findMatches()).size && guard++ < 80) m.forEach(k => { grid[(k / COLS) | 0][k % COLS] = rnd(NC); });
      if (!hasMove()) shuffle();
    }
    function findMatches() {
      const m = new Set();
      for (let r = 0; r < ROWS; r++) { let run = 1; for (let c = 1; c <= COLS; c++) { if (c < COLS && grid[r][c] >= 0 && grid[r][c] === grid[r][c - 1]) run++; else { if (run >= 3) for (let k = 1; k <= run; k++) m.add(r * COLS + (c - k)); run = 1; } } }
      for (let c = 0; c < COLS; c++) { let run = 1; for (let r = 1; r <= ROWS; r++) { if (r < ROWS && grid[r][c] >= 0 && grid[r][c] === grid[r - 1][c]) run++; else { if (run >= 3) for (let k = 1; k <= run; k++) m.add((r - k) * COLS + c); run = 1; } } }
      return m;
    }
    function swapCells(r, c, r2, c2) {
      const t = grid[r][c]; grid[r][c] = grid[r2][c2]; grid[r2][c2] = t;
      offX[r][c] = (c2 - c) * cs; offY[r][c] = (r2 - r) * cs;
      offX[r2][c2] = (c - c2) * cs; offY[r2][c2] = (r - r2) * cs;
    }
    function cellAt(e) { const rect = cv.getBoundingClientRect(); const x = e.clientX - rect.left, y = e.clientY - rect.top; return [Math.floor((y - hudH) / cs), Math.floor(x / cs), x, y]; }
    function onDown(e) { if (lock || winT > 0) return; const [r, c, x, y] = cellAt(e); if (r < 0 || c < 0 || r >= ROWS || c >= COLS) return; drag = { r, c, x, y }; }
    function onUp(e) {
      if (!drag || lock) { drag = null; return; }
      const [, , x, y] = cellAt(e); const dx = x - drag.x, dy = y - drag.y; const d = drag; drag = null;
      if (Math.hypot(dx, dy) < cs * 0.33) return;
      let dr = 0, dc = 0; if (Math.abs(dx) > Math.abs(dy)) dc = dx > 0 ? 1 : -1; else dr = dy > 0 ? 1 : -1;
      const r2 = d.r + dr, c2 = d.c + dc;
      if (r2 < 0 || c2 < 0 || r2 >= ROWS || c2 >= COLS) return;
      swapCells(d.r, d.c, r2, c2); sfx('pick'); vibe('light'); lock = true;
      if (findMatches().size) { moves--; setTimeout(() => resolve(1), 170); }
      else setTimeout(() => { swapCells(d.r, d.c, r2, c2); sfx('nope'); lock = false; }, 200);
    }
    function resolve(combo) {
      const m = findMatches();
      if (!m.size) {
        lock = false;
        if (score >= target) { winT = 0.01; sfx('win'); vibe('success'); }
        else if (moves <= 0) { lock = true; setTimeout(() => toastMini('Out of moves!', '#ffb020'), 150); setTimeout(() => { score = 0; setLevel(1); newBoard(); }, 1500); }
        else if (!hasMove()) shuffle();
        return;
      }
      const gained = m.size * 10 * combo; score += gained; setBest('blast', score);
      shake = Math.min(16, 3 + m.size + combo * 2);
      sfx('clear', Math.min(m.size, 4), Math.min(1 + combo * 0.3, 2.5)); vibe(combo >= 3 ? 'heavy' : 'medium');
      if (combo >= 2) { sfx('praise', Math.min(combo, 9)); pops.push({ x: bw / 2, y: hudH + cs * 1.6, t: 0, text: 'COMBO x' + combo, size: 32, col: '#ffd86b' }); }
      let cx = 0, cy = 0, nn = 0;
      m.forEach(k => {
        const r = (k / COLS) | 0, c = k % COLS, px = c * cs + cs / 2 + offX[r][c], py = hudH + r * cs + cs / 2 + offY[r][c];
        cx += px; cy += py; nn++;
        for (let i = 0; i < 5; i++) parts.push({ x: px, y: py, vx: (Math.random() - .5) * 320, vy: -Math.random() * 300 - 40, life: .6, max: .6, col: tileColor(grid[r][c]), s: cs * (.2 + Math.random() * .22) });
        grid[r][c] = -1;
      });
      pops.push({ x: cx / nn, y: cy / nn - cs * .4, t: 0, text: '+' + gained, size: 24 + Math.min(nn, 10) * 2, col: combo >= 2 ? '#ffd86b' : '#fff' });
      gravity();
      setTimeout(() => resolve(combo + 1), 250);
    }
    function gravity() {
      for (let c = 0; c < COLS; c++) {
        const keep = [];
        for (let r = ROWS - 1; r >= 0; r--) if (grid[r][c] >= 0) keep.push({ col: grid[r][c], oy: r * cs + offY[r][c] });
        for (let r = ROWS - 1, i = 0; r >= 0; r--, i++) {
          if (i < keep.length) { grid[r][c] = keep[i].col; offY[r][c] = keep[i].oy - r * cs; offX[r][c] = 0; }
          else { grid[r][c] = rnd(NC); offY[r][c] = -r * cs - cs * 2 - Math.random() * cs * 2; offX[r][c] = 0; }
        }
      }
    }
    function hasMove() {
      for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) for (const [dr, dc] of [[0, 1], [1, 0]]) {
        const r2 = r + dr, c2 = c + dc; if (r2 >= ROWS || c2 >= COLS) continue;
        const t = grid[r][c]; grid[r][c] = grid[r2][c2]; grid[r2][c2] = t;
        const ok = findMatches().size > 0;
        grid[r2][c2] = grid[r][c]; grid[r][c] = t;
        if (ok) return true;
      }
      return false;
    }
    function shuffle() {
      for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) { grid[r][c] = rnd(NC); offY[r][c] = -(r + 2) * cs; offX[r][c] = 0; }
      let m, g = 0; while ((m = findMatches()).size && g++ < 80) m.forEach(k => { grid[(k / COLS) | 0][k % COLS] = rnd(NC); });
      if (!hasMove() && g < 78) shuffle();
    }
    function nextLevel() {
      setLevel(level + 1); newBoard(); flash = 1;
      pops.push({ x: bw / 2, y: hudH + cs * ROWS / 2, t: 0, text: 'LEVEL ' + level + '!', size: 42, col: '#ffd86b' });
      for (let i = 0; i < 90; i++) parts.push({ x: Math.random() * bw, y: -10, vx: (Math.random() - .5) * 220, vy: 60 + Math.random() * 220, life: 2, max: 2, col: tileColor(rnd(7)), s: 7 + Math.random() * 6, conf: true });
      sfx('reward'); vibe('medium');
    }
    function update(dt) {
      const k = 1 - Math.exp(-16 * dt);
      for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
        if (grid[r][c] < 0) continue;
        if (Math.abs(offX[r][c]) > 0.4 || Math.abs(offY[r][c]) > 0.4) { offX[r][c] += -offX[r][c] * k; offY[r][c] += -offY[r][c] * k; }
        else { offX[r][c] = 0; offY[r][c] = 0; }
      }
      for (const p of parts) { if (!p.conf) p.vy += 900 * dt; else p.vy += 300 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt; }
      parts = parts.filter(p => p.life > 0 && p.y < bh + 40);
      for (const p of pops) p.t += dt; pops = pops.filter(p => p.t < 0.85);
      if (shake > 0) shake = Math.max(0, shake - dt * 42);
      if (flash > 0) flash = Math.max(0, flash - dt * 2);
      if (winT > 0) { winT += dt; if (winT > 1.5) nextLevel(); }
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    function render() {
      ctx.clearRect(0, 0, bw, bh);
      const sx = shake ? (Math.random() - .5) * shake : 0, sy = shake ? (Math.random() - .5) * shake : 0;
      ctx.save(); ctx.translate(sx, sy);
      rr(0, hudH, bw, cs * ROWS, 14); ctx.fillStyle = 'rgba(255,255,255,.06)'; ctx.fill();
      ctx.save(); rr(0, hudH, bw, cs * ROWS, 14); ctx.clip();
      for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) { if (grid[r][c] < 0) continue; drawTile(ctx, c * cs + offX[r][c] + 2, hudH + r * cs + offY[r][c] + 2, cs - 4, grid[r][c]); }
      ctx.restore();
      for (const p of parts) { ctx.globalAlpha = Math.max(0, Math.min(1, p.life / p.max)); ctx.fillStyle = p.col; if (p.conf) ctx.fillRect(p.x, p.y, p.s, p.s * 1.4); else { ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, 6.283); ctx.fill(); } }
      ctx.globalAlpha = 1; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (const p of pops) { ctx.globalAlpha = Math.max(0, 1 - p.t / 0.85); const sz = p.size * (p.t < .12 ? p.t / .12 : 1); ctx.font = `${sz}px "Lilita One", sans-serif`; ctx.lineWidth = sz * .22; ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(40,20,10,.6)'; ctx.fillStyle = p.col; const yy = p.y - p.t * 42; ctx.strokeText(p.text, p.x, yy); ctx.fillText(p.text, p.x, yy); }
      ctx.globalAlpha = 1; ctx.restore();
      drawHud();
      if (flash > 0) { ctx.fillStyle = `rgba(255,255,255,${flash * .4})`; ctx.fillRect(0, 0, bw, bh); }
    }
    function drawHud() {
      ctx.textBaseline = 'middle';
      ctx.textAlign = 'left'; ctx.font = '16px "Lilita One", sans-serif'; ctx.fillStyle = '#fff'; ctx.fillText('Lv ' + level, 4, 13);
      ctx.textAlign = 'right'; ctx.fillStyle = '#ffd86b'; ctx.fillText(score + ' / ' + target, bw - 4, 13);
      const by = 25, p = Math.min(1, score / target);
      rr(4, by, bw - 8, 8, 4); ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fill();
      if (p > 0) { rr(4, by, (bw - 8) * p, 8, 4); ctx.fillStyle = '#7fd86b'; ctx.fill(); }
      ctx.textAlign = 'center'; ctx.font = '13px "Lilita One", sans-serif'; ctx.fillStyle = moves <= 3 ? '#ff7a6b' : '#d8cff0'; ctx.fillText(moves + ' moves', bw / 2, 43);
    }
    return { start };
  })();

  // =================================================================
  //  2) 2048 MERGE
  // =================================================================
  const Merge = (() => {
    const N = 4;
    let g, score, lastSpawn, mergedSet;
    function start() { g = Array.from({ length: N }, () => Array(N).fill(0)); score = 0; lastSpawn = null; mergedSet = new Set(); spawn(); spawn(); draw(); }
    function spawn() {
      const empty = [];
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!g[r][c]) empty.push([r, c]);
      if (!empty.length) return false;
      const [r, c] = empty[rnd(empty.length)]; g[r][c] = Math.random() < 0.9 ? 2 : 4; lastSpawn = r * N + c; return true;
    }
    function slideRow(row) {
      let a = row.filter(v => v), out = [], merged = [], gained = 0;
      for (let i = 0; i < a.length; i++) {
        if (i + 1 < a.length && a[i] === a[i + 1]) { out.push(a[i] * 2); merged.push(out.length - 1); gained += a[i] * 2; i++; }
        else out.push(a[i]);
      }
      while (out.length < N) out.push(0);
      return { out, gained, merged };
    }
    function move(dir) {
      const before = JSON.stringify(g); mergedSet = new Set();
      for (let i = 0; i < N; i++) {
        let line = [];
        for (let j = 0; j < N; j++) line.push(dir === 0 ? g[i][j] : dir === 1 ? g[i][N - 1 - j] : dir === 2 ? g[j][i] : g[N - 1 - j][i]);
        const { out, gained, merged } = slideRow(line); score += gained;
        for (let j = 0; j < N; j++) {
          const v = out[j];
          if (dir === 0) g[i][j] = v; else if (dir === 1) g[i][N - 1 - j] = v; else if (dir === 2) g[j][i] = v; else g[N - 1 - j][i] = v;
        }
        merged.forEach(j => {
          const key = dir === 0 ? i * N + j : dir === 1 ? i * N + (N - 1 - j) : dir === 2 ? j * N + i : (N - 1 - j) * N + i;
          mergedSet.add(key);
        });
      }
      if (JSON.stringify(g) === before) return;
      setBest('merge', score);
      sfx('place', 2); vibe(mergedSet.size ? 'medium' : 'light'); spawn(); draw();
      if (!canMove()) { toastMini('No moves!', '#ffd86b'); sfx('lose'); }
    }
    function canMove() {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        if (!g[r][c]) return true;
        if (c + 1 < N && g[r][c] === g[r][c + 1]) return true;
        if (r + 1 < N && g[r][c] === g[r + 1][c]) return true;
      }
      return false;
    }
    function draw() {
      const b = shell('2048 Merge', `<b>${score}</b> <small>best ${getBest('merge')}</small>`);
      b.className = 'grid-board'; b.style.setProperty('--cols', N); b.style.maxWidth = '360px';
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const v = g[r][c]; const k = r * N + c; const cell = el('div', 'cell merge-cell');
        if (v) {
          cell.style.cssText += candyCss((Math.log2(v) - 1) % PAL.length);
          cell.innerHTML = `<span>${v}</span>`;
          if (mergedSet.has(k)) cell.classList.add('merged');
          else if (k === lastSpawn) cell.classList.add('spawn');
        }
        b.appendChild(cell);
      }
      let sx = 0, sy = 0;
      b.onpointerdown = e => { sx = e.clientX; sy = e.clientY; };
      b.onpointerup = e => {
        const dx = e.clientX - sx, dy = e.clientY - sy;
        if (Math.abs(dx) < 18 && Math.abs(dy) < 18) return;
        if (Math.abs(dx) > Math.abs(dy)) move(dx > 0 ? 1 : 0); else move(dy > 0 ? 3 : 2);
      };
      footButton('New game', start);
    }
    function key(e) { const m = { ArrowLeft: 0, ArrowRight: 1, ArrowUp: 2, ArrowDown: 3 }; if (m[e.key] != null) { e.preventDefault(); move(m[e.key]); } }
    return { start, key };
  })();

  // =================================================================
  //  3) MEMORY MATCH  (persistent cards -> smooth 3D flip)
  // =================================================================
  const Memory = (() => {
    const COLS = 4, PAIRS = 6;
    let deck, first, lock, moves, matched, cards, movesEl;
    function start() {
      const faces = []; for (let i = 0; i < PAIRS; i++) faces.push(i, i);
      for (let i = faces.length - 1; i > 0; i--) { const j = rnd(i + 1);[faces[i], faces[j]] = [faces[j], faces[i]]; }
      deck = faces; first = -1; lock = false; moves = 0; matched = 0; cards = [];
      const b = shell('Memory', `<b id="mgMoves">0</b> <small>moves</small>`);
      movesEl = $('mgMoves');
      b.className = 'grid-board'; b.style.setProperty('--cols', COLS); b.style.maxWidth = '360px';
      for (let i = 0; i < deck.length; i++) {
        const card = el('button', 'mcard');
        card.innerHTML = `<span class="mcard-in"><span class="mcard-back">?</span><span class="mcard-front" style="${candyCss(deck[i])}"><i class="pip"></i></span></span>`;
        card.onclick = () => flip(i);
        cards.push(card); b.appendChild(card);
      }
      footButton('New game', start);
    }
    function flip(i) {
      const card = cards[i];
      if (lock || card.classList.contains('flipped') || card.classList.contains('matched')) return;
      card.classList.add('flipped'); sfx('pick'); vibe('light');
      if (first < 0) { first = i; return; }
      moves++; if (movesEl) movesEl.textContent = moves;
      const a = first; first = -1;
      if (deck[a] === deck[i]) {
        setTimeout(() => { cards[a].classList.add('matched'); card.classList.add('matched'); }, 260);
        matched++; sfx('coin'); vibe('medium');
        const [cx, cy] = centerOf(card); burst(cx, cy, '', '#fff');
        if (matched === PAIRS) { setBest('memory', Math.max(1, 120 - moves * 3)); setTimeout(() => { toastMini('You win! ' + moves + ' moves', '#86e391'); sfx('win'); vibe('success'); }, 350); }
      } else {
        lock = true;
        setTimeout(() => { cards[a].classList.remove('flipped'); card.classList.remove('flipped'); lock = false; }, 760);
      }
    }
    return { start };
  })();

  // =================================================================
  //  4) COLOR SORT  (pour drop-in animation)
  // =================================================================
  const Sort = (() => {
    const CAP = 4, COLORS = 5, EMPTY = 2;
    let tubes, sel, moves, lastPour;
    function start() {
      const NT = COLORS + EMPTY;
      tubes = Array.from({ length: NT }, () => []);
      for (let i = 0; i < COLORS; i++) for (let k = 0; k < CAP; k++) tubes[i].push(i);
      for (let n = 0; n < 220; n++) { const s = rnd(NT), d = rnd(NT); if (s !== d && tubes[s].length && tubes[d].length < CAP) tubes[d].push(tubes[s].pop()); }
      sel = -1; moves = 0; lastPour = null; draw();
    }
    function solved() { return tubes.every(t => t.length === 0 || (t.length === CAP && t.every(v => v === t[0]))); }
    function tap(i) {
      lastPour = null;
      if (sel < 0) { if (tubes[i].length) { sel = i; sfx('pick'); vibe('light'); draw(); } return; }
      if (sel === i) { sel = -1; draw(); return; }
      const src = tubes[sel], dst = tubes[i], col = src[src.length - 1];
      if (dst.length < CAP && (dst.length === 0 || dst[dst.length - 1] === col)) {
        let moved = 0;
        while (src.length && dst.length < CAP && src[src.length - 1] === col) { dst.push(src.pop()); moved++; }
        if (moved) { moves++; sfx('place', 2); vibe('light'); lastPour = { tube: i, count: moved }; }
      } else sfx('nope');
      sel = -1; draw();
      if (solved()) { setBest('sort', Math.max(1, 220 - moves)); setTimeout(() => { toastMini('Solved! ' + moves + ' moves', '#86e391'); sfx('win'); vibe('success'); }, 250); }
    }
    function draw() {
      const b = shell('Color Sort', `<b>${moves}</b> <small>moves</small>`);
      b.className = 'tube-board';
      tubes.forEach((t, i) => {
        const tube = el('button', 'tube' + (sel === i ? ' sel' : ''));
        for (let k = CAP - 1; k >= 0; k--) {
          const seg = el('span', 'seg');
          if (t[k] != null) {
            seg.style.cssText = candyCss(t[k]);
            if (lastPour && lastPour.tube === i && k >= t.length - lastPour.count) { seg.classList.add('drop'); seg.style.animationDelay = ((t.length - 1 - k) * 0.05).toFixed(3) + 's'; }
          } else seg.classList.add('empty');
          tube.appendChild(seg);
        }
        tube.onclick = () => tap(i);
        b.appendChild(tube);
      });
      footButton('Restart', start);
    }
    return { start };
  })();

  const GAMES = { blast: Blast, merge: Merge, memory: Memory, sort: Sort };
  window.addEventListener('keydown', e => { if ($('mini').classList.contains('show') && active === 'merge') Merge.key(e); });

  function wire() {
    const m = $('mAssorti'); if (m) m.onclick = openHub;
    const gb = $('gamesBack'); if (gb) gb.onclick = backToMenu;
    const mb = $('miniBack'); if (mb) mb.onclick = backToHub;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
  return { open: openHub };
})();
