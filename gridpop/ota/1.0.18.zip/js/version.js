// Written by tools/ota-publish.sh. WEB_VERSION = version of these web files.
// NATIVE_COMPAT changes only when native plugins change (then a new App Store build is needed).
const WEB_VERSION = '1.0.18';
const NATIVE_COMPAT = '1';
