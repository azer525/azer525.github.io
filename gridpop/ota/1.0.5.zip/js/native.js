'use strict';
// =====================================================================
//  NATIVE: AdMob ads + haptics through Capacitor, with web fallbacks
// =====================================================================
const Native = (() => {
  const C = window.Capacitor;
  const isNative = !!(C && C.isNativePlatform && C.isNativePlatform());
  const platform = C && C.getPlatform ? C.getPlatform() : 'web';
  // Native plugins must be registered through Capacitor core (js/vendor/capacitor.js);
  // window.Capacitor.Plugins stays empty otherwise.
  const P = {};
  if (isNative && window.capacitorExports && capacitorExports.registerPlugin) {
    for (const name of ['AdMob', 'Haptics', 'CapacitorUpdater']) {
      try { P[name] = capacitorExports.registerPlugin(name); } catch (e) { console.warn('[native] plugin', name, e); }
    }
  }
  return { isNative, platform, P };
})();

// ---------------- Haptics ----------------
const Haptic = (() => {
  let enabled = true;
  const H = () => Native.P.Haptics;
  const impact = (style, ms) => {
    if (!enabled) return;
    if (H()) H().impact({ style }).catch(() => {});
    else if (navigator.vibrate) navigator.vibrate(ms);
  };
  return {
    set enabled(v) { enabled = v; }, get enabled() { return enabled; },
    light: () => impact('LIGHT', 8),
    medium: () => impact('MEDIUM', 18),
    heavy: () => impact('HEAVY', 35),
    success() { if (!enabled) return; if (H()) H().notification({ type: 'SUCCESS' }).catch(() => {}); else if (navigator.vibrate) navigator.vibrate([15, 40, 15]); },
    error() { if (!enabled) return; if (H()) H().notification({ type: 'ERROR' }).catch(() => {}); else if (navigator.vibrate) navigator.vibrate([50, 30, 50]); },
  };
})();

// ---------------- Ads ----------------
// ADS_TEST_MODE = true  → Google's sample ads (safe while you test on your own phone).
// ADS_TEST_MODE = false → real ads that earn money. Switch to false only for the App Store release build.
// Never tap real ads on your own device: AdMob can close the account for invalid traffic.
// Developer switch: tap the version label in Settings 7 times to use test ads on your own phone.
const ADS_TEST_MODE = false || localStorage.getItem('gp_test_ads') === '1';
const AD_UNITS = {
  // AdMob app "Grid Pop: Block Adventure" (iOS), app id ca-app-pub-7337203307048384~6372971576
  ios: { rewarded: 'ca-app-pub-7337203307048384/6527130225', interstitial: 'ca-app-pub-7337203307048384/5775360729' },
  // AdMob app "Grid Pop: Block Adventure" (Android), app id ca-app-pub-7337203307048384~1603844715
  android: { rewarded: 'ca-app-pub-7337203307048384/1412273027', interstitial: 'ca-app-pub-7337203307048384/1982992358' },
};
const TEST_UNITS = {
  ios: { rewarded: 'ca-app-pub-3940256099942544/1712485313', interstitial: 'ca-app-pub-3940256099942544/4411468910' },
  android: { rewarded: 'ca-app-pub-3940256099942544/5224354917', interstitial: 'ca-app-pub-3940256099942544/1033173712' },
};
const Ads = (() => {
  const A = () => Native.P.AdMob;
  // A platform without its own real units (Android until its AdMob app exists) gets
  // Google's sample units: another platform's real ids would never fill there.
  const ids = () => {
    const p = Native.platform === 'android' ? 'android' : 'ios';
    return (!ADS_TEST_MODE && AD_UNITS[p]) || TEST_UNITS[p];
  };
  let rewardedReady = false, interReady = false, busy = false;

  const removeAll = handles => handles.forEach(h => Promise.resolve(h).then(x => x && x.remove && x.remove()).catch(() => {}));
  function pauseAudio() { if (typeof Audio2 !== 'undefined') Audio2.Music.stop(); }
  function resumeAudio() { if (typeof Audio2 !== 'undefined' && window.__musicOn) Audio2.Music.start(); }

  function loadRewarded() {
    if (!A()) return;
    A().prepareRewardVideoAd({ adId: ids().rewarded })
      .then(() => { rewardedReady = true; })
      .catch(() => { rewardedReady = false; setTimeout(loadRewarded, 30000); });
  }
  function loadInter() {
    if (!A()) return;
    A().prepareInterstitial({ adId: ids().interstitial })
      .then(() => { interReady = true; })
      .catch(() => { interReady = false; setTimeout(loadInter, 45000); });
  }
  function demoAd(onReward) {
    const el = document.getElementById('ad'), cnt = document.getElementById('adCount');
    let n = 3; cnt.textContent = n; el.classList.add('show');
    const t = setInterval(() => {
      n--; cnt.textContent = n;
      if (n <= 0) { clearInterval(t); el.classList.remove('show'); onReward(); }
    }, 1000);
  }

  return {
    async init() {
      if (!A()) return;
      try {
        await A().initialize({});
        try {
          const info = await A().requestConsentInfo();
          if (info && info.isConsentFormAvailable && info.status === 'REQUIRED') await A().showConsentForm();
        } catch (e) { /* consent not configured yet */ }
        loadRewarded(); loadInter();
      } catch (e) { console.warn('[ads] init failed', e); }
    },
    // onReward runs only if the player watched the ad to the end
    showRewarded(onReward, onUnavailable) {
      if (!Native.isNative) return demoAd(onReward);
      if (busy) return;
      if (!rewardedReady) {
        loadRewarded();
        if (onUnavailable) onUnavailable();
        return;
      }
      busy = true;
      let earned = false, finished = false, granted = false;
      const handles = [];
      const grant = () => { if (granted) return; granted = true; setTimeout(onReward, 50); };
      const done = () => {
        if (finished) return; finished = true; busy = false;
        removeAll(handles); resumeAudio();
        rewardedReady = false; loadRewarded();
        if (earned) grant();
      };
      handles.push(A().addListener('onRewardedVideoAdReward', () => { earned = true; }));
      handles.push(A().addListener('onRewardedVideoAdDismissed', done));
      handles.push(A().addListener('onRewardedVideoAdFailedToShow', done));
      pauseAudio();
      A().showRewardVideoAd()
        .then(r => { if (r && r.amount > 0) { earned = true; if (finished) grant(); } })
        .catch(done);
    },
    showInterstitial() {
      if (!Native.isNative || !interReady || busy) return;
      busy = true; interReady = false;
      const handles = [];
      const done = () => { busy = false; removeAll(handles); resumeAudio(); loadInter(); };
      handles.push(A().addListener('interstitialAdDismissed', done));
      handles.push(A().addListener('interstitialAdFailedToShow', done));
      pauseAudio();
      A().showInterstitial().catch(done);
    },
  };
})();

// ---------------- OTA (over-the-air) web updates ----------------
// The app checks a small JSON file on GitHub Pages. If a newer web bundle exists
// (same NATIVE_COMPAT), it downloads it in the background and switches to it
// the next time the app starts, so a game in progress is never interrupted.
const OTA_URL = 'https://azer525.github.io/gridpop/ota/latest.json';
const OTA = (() => {
  const U = () => Native.P.CapacitorUpdater;
  const newer = (a, b) => {
    const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
    for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); }
    return false;
  };
  return {
    async check() {
      if (!U()) return;
      try {
        await U().notifyAppReady();           // tells the updater this bundle works (else it rolls back)
        const res = await fetch(OTA_URL + '?t=' + Date.now(), { cache: 'no-store' });
        if (!res.ok) return;
        const info = await res.json();
        if (!info || !info.version || !info.url) return;
        if (String(info.native) !== NATIVE_COMPAT) return;
        if (!newer(info.version, WEB_VERSION)) return;
        const bundle = await U().download({ url: info.url, version: info.version });
        await U().next({ id: bundle.id });    // applied on next launch / return from background
        console.log('[ota] update', info.version, 'ready');
      } catch (e) { console.warn('[ota]', e); }
    },
  };
})();
