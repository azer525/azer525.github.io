'use strict';
// =====================================================================
//  ART: palette, themes, icons, tile/scene painters
// =====================================================================
let DPR = 1;

function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

const TILE_COLORS = [
  { base: '#f2564d', light: '#ff8f78', dark: '#b3302c' }, // coral
  { base: '#f7962a', light: '#ffc35e', dark: '#c0650f' }, // tangerine
  { base: '#f4c936', light: '#ffe880', dark: '#bb9012' }, // lemon
  { base: '#46bf68', light: '#86e391', dark: '#278543' }, // mint
  { base: '#33a0e4', light: '#76ccff', dark: '#1a6aab' }, // sky
  { base: '#7c61e6', light: '#ab97ff', dark: '#4f3cab' }, // grape
  { base: '#e85c9c', light: '#ff96c4', dark: '#a8376c' }, // pink
];
const TILE_GREY = { base: '#8b8798', light: '#b5b1c2', dark: '#5c5868' };
const TILE_STONE = { base: '#5d6178', light: '#8c91aa', dark: '#383b4e' };
const ICE_THICK = { base: '#bfe8ff', light: '#f4fcff', dark: '#79b3d8' };
const ICE_THIN = { base: '#8fd2f2', light: '#d2f1ff', dark: '#5597c0' };

const THEMES = [
  { id: 'meadow', name: 'Sunny Meadow', scene: 'meadow', amb: 'pollen', sky: ['#78c6ee', '#d6f2ff'],
    frame: ['#dba062', '#9a5f2c'], board: '#6a3e1e', empty: '#7c4b26', accent: '#ffcf3f',
    rc: '#4cbf3e', rd: '#2c8a22', mapBg: 'linear-gradient(#a8e493,#6cbf57)', tag: 'Clear lines, score points' },
  { id: 'caves', name: 'Crystal Caves', scene: 'caves', amb: 'sparkle', sky: ['#1c0b3a', '#4d2b7d'],
    frame: ['#ae90e6', '#5d3e9f'], board: '#22113c', empty: '#321b55', accent: '#c89bff',
    rc: '#9b6cf0', rd: '#5f3fb6', mapBg: 'linear-gradient(#43256f,#22103d)', tag: 'New: gems' },
  { id: 'frozen', name: 'Frozen Peaks', scene: 'frozen', amb: 'snow', sky: ['#98cff4', '#ecf7ff'],
    frame: ['#f6fcff', '#a4cde8'], board: '#33608a', empty: '#41719b', accent: '#7fd4ff',
    rc: '#3aa6e8', rd: '#1d6fb0', mapBg: 'linear-gradient(#f3f9ff,#c8e4f7)', tag: 'New: ice blocks' },
  { id: 'volcano', name: 'Volcano Rush', scene: 'volcano', amb: 'ember', sky: ['#260a0d', '#b9411d'],
    frame: ['#6e4a41', '#2d1b18'], board: '#21100c', empty: '#361e16', accent: '#ff9b2e',
    rc: '#f05a4a', rd: '#b23527', mapBg: 'linear-gradient(#57241a,#290f0b)', tag: 'New: bombs' },
  { id: 'jungle', name: 'Jungle Ruins', scene: 'jungle', amb: 'firefly', sky: ['#0c3828', '#3b8c57'],
    frame: ['#a0ae6a', '#56643a'], board: '#193023', empty: '#234332', accent: '#a8e65d',
    rc: '#5bb84a', rd: '#367a29', mapBg: 'linear-gradient(#378c59,#174930)', tag: 'Everything mixed' },
  { id: 'neon', name: 'Neon City', scene: 'neon', amb: 'neon', sky: ['#0b091d', '#34175c'],
    frame: ['#5a6084', '#22253a'], board: '#0d0e21', empty: '#191b39', accent: '#4de6ff',
    rc: '#e94fb0', rd: '#a52c7a', mapBg: 'linear-gradient(#24174c,#0b0a1a)', tag: 'Everything mixed' },
];
const CLASSIC = { id: 'classic', name: 'Endless', scene: 'classic', amb: 'bokeh', sky: ['#24596a', '#0d232e'],
  frame: ['#e9b872', '#a66e2e'], board: '#13313b', empty: '#1c414f', accent: '#ffcf3f' };

// ---------------------------------------------------------------------
//  SVG icons (UI)
// ---------------------------------------------------------------------
const LINE_TILES = [['#f2564d', '#b3302c'], ['#f4c936', '#bb9012'], ['#46bf68', '#278543'], ['#33a0e4', '#1a6aab']];
const ICONS = {
  back: '<svg viewBox="0 0 24 24"><path d="M15 4 7 12l8 8" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  coin: '<svg viewBox="0 0 40 40"><circle cx="20" cy="21.5" r="16.5" fill="#bf6f0c"/><circle cx="20" cy="19" r="16.5" fill="#f7a823"/><circle cx="20" cy="19" r="12" fill="#ffcd3f"/><path d="M20 11.5l2.2 4.6 5 .6-3.7 3.4 1 5-4.5-2.5-4.5 2.5 1-5-3.7-3.4 5-.6z" fill="#e8901b"/><path d="M9 14a12 12 0 0 1 8-7.5" stroke="#fff" stroke-width="2.5" stroke-linecap="round" fill="none" opacity=".75"/></svg>',
  star: '<svg viewBox="0 0 48 48"><path d="M24 5l6 12.4 13.6 1.8-10 9.5 2.6 13.5L24 35.6l-12.2 6.6 2.6-13.5-10-9.5L18 17.4z" fill="#ffcf3f" stroke="#d4860f" stroke-width="3.2" stroke-linejoin="round"/><path d="M17.5 21.5l2-4.2M30 19.5l4.5.6" stroke="#fff7cf" stroke-width="3" stroke-linecap="round"/></svg>',
  crown: '<svg viewBox="0 0 40 40"><path d="M6 29 4 12l9 7 7-11 7 11 9-7-2 17z" fill="#ffcf3f" stroke="#d4860f" stroke-width="2.6" stroke-linejoin="round"/><rect x="6" y="28" width="28" height="6" rx="2.5" fill="#f7a823" stroke="#d4860f" stroke-width="2.6"/><circle cx="20" cy="20" r="2.4" fill="#f2564d"/></svg>',
  hammer: '<svg viewBox="0 0 40 40"><g transform="rotate(-35 20 20)"><rect x="17" y="13" width="6.5" height="24" rx="3" fill="#9a5a2a" stroke="#4a2c17" stroke-width="2"/><rect x="8" y="4" width="24" height="12" rx="3.5" fill="#c3cbdc" stroke="#4a2c17" stroke-width="2.2"/><rect x="10.5" y="6.3" width="19" height="3" rx="1.5" fill="#fff" opacity=".8"/></g></svg>',
  gem: '<svg viewBox="0 0 40 40"><path d="M11 9h18l7 8-16 19L4 17z" fill="#27c7dc"/><path d="M11 9h18l7 8H4z" fill="#8cefff"/><path d="M15 9h10l4 8H11z" fill="#d6fcff"/><path d="M4 17h16v19z" fill="#1fb0cc"/><path d="M20 17h16L20 36z" fill="#1592b4"/><path d="M11 9h18l7 8-16 19L4 17z" fill="none" stroke="#0b4f63" stroke-width="2.4" stroke-linejoin="round"/></svg>',
  ice: '<svg viewBox="0 0 40 40"><rect x="3" y="5" width="34" height="33" rx="8" fill="#79b3d8"/><rect x="3" y="3" width="34" height="30" rx="8" fill="#d8f3ff"/><rect x="7.5" y="7.5" width="25" height="21" rx="5" fill="none" stroke="#fff" stroke-width="2.6"/><path d="M13 24l5-10M20 25.5l4.5-9" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><rect x="3" y="3" width="34" height="35" rx="8" fill="none" stroke="#4d86ad" stroke-width="1.6"/></svg>',
  bomb: '<svg viewBox="0 0 40 40"><circle cx="18" cy="24" r="13" fill="#24232f"/><circle cx="13.5" cy="19.5" r="3.6" fill="#fff" opacity=".35"/><rect x="20.5" y="8" width="7" height="6" rx="1.5" transform="rotate(40 24 11)" fill="#5a596f"/><path d="M27 9q3-5 7-3" stroke="#c9a36b" stroke-width="2.6" fill="none" stroke-linecap="round"/><circle cx="34" cy="6" r="3.4" fill="#ffb02e"/><circle cx="34" cy="6" r="1.5" fill="#fff6b0"/></svg>',
  lines: '<svg viewBox="0 0 40 40">' + LINE_TILES.map((c, i) => `<rect x="${1 + i * 9.7}" y="15" width="9" height="11" rx="2.5" fill="${c[1]}"/><rect x="${1 + i * 9.7}" y="14" width="9" height="9.5" rx="2.5" fill="${c[0]}"/><rect x="${2.6 + i * 9.7}" y="15.4" width="5.8" height="2.4" rx="1.2" fill="#fff" opacity=".55"/>`).join('') + '<path d="M8 8l2 3M20 5v4M32 8l-2 3M8 33l2-3M20 36v-4M32 33l-2-3" stroke="#f5a524" stroke-width="2.6" stroke-linecap="round"/></svg>',
  lock: '<svg viewBox="0 0 40 40"><path d="M13 18v-5a7 7 0 0 1 14 0v5" fill="none" stroke="#5d564f" stroke-width="4"/><rect x="9" y="17" width="22" height="18" rx="5" fill="#5d564f"/><circle cx="20" cy="24.5" r="2.6" fill="#c9c4bd"/><rect x="19" y="25.5" width="2" height="5" rx="1" fill="#c9c4bd"/></svg>',
  play: '<svg viewBox="0 0 24 24"><path d="M7 4.5v15a1 1 0 0 0 1.5.9l12-7.5a1 1 0 0 0 0-1.8l-12-7.5A1 1 0 0 0 7 4.5z" fill="#fff"/></svg>',
  map: '<svg viewBox="0 0 24 24"><path d="M3 6.2 9 4l6 2.2L21 4v13.8L15 20l-6-2.2L3 20z" fill="#fff" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/><path d="M9 4.5v13M15 6.5v13" stroke="#2a92e0" stroke-width="1.8"/></svg>',
  infinity: '<svg viewBox="0 0 24 24"><path d="M6.5 8.5C4.5 8.5 3 10.1 3 12s1.5 3.5 3.5 3.5C10 15.5 14 8.5 17.5 8.5c2 0 3.5 1.6 3.5 3.5s-1.5 3.5-3.5 3.5C14 15.5 10 8.5 6.5 8.5z" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/></svg>',
  film: '<svg viewBox="0 0 24 24"><rect x="2" y="5.5" width="14.5" height="13" rx="3" fill="#fff"/><path d="M17 10.5l5-3.2v9.4l-5-3.2z" fill="#fff"/><circle cx="6.5" cy="10" r="1.7" fill="#f58a1f"/></svg>',
  retry: '<svg viewBox="0 0 24 24"><path d="M19 12.5a7 7 0 1 1-2.2-5.3" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/><path d="M18 2.8v5h-5" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  pin: '<svg viewBox="0 0 40 50"><ellipse cx="20" cy="47" rx="8" ry="2.5" fill="rgba(0,0,0,.25)"/><path d="M20 44C9 30 5 24 5 17a15 15 0 0 1 30 0c0 7-4 13-15 27z" fill="#f05a4a" stroke="#fff" stroke-width="3"/><circle cx="20" cy="17" r="6" fill="#fff"/></svg>',
  gear: '<svg viewBox="0 0 24 24"><path d="M10.3 2h3.4l.5 2.6 1.9.8 2.2-1.5 2.4 2.4-1.5 2.2.8 1.9 2.6.5v3.4l-2.6.5-.8 1.9 1.5 2.2-2.4 2.4-2.2-1.5-1.9.8-.5 2.6h-3.4l-.5-2.6-1.9-.8-2.2 1.5-2.4-2.4 1.5-2.2-.8-1.9L2 13.7v-3.4l2.6-.5.8-1.9-1.5-2.2 2.4-2.4 2.2 1.5 1.9-.8z" fill="currentColor"/><circle cx="12" cy="12" r="3.6" fill="#f6e4c4"/></svg>',
  gift: '<svg viewBox="0 0 40 40"><rect x="5" y="16" width="30" height="21" rx="4" fill="#e8453a"/><rect x="3" y="11" width="34" height="9" rx="3" fill="#ff6b5b"/><rect x="17" y="11" width="6" height="26" fill="#ffcf3f"/><path d="M20 11c-3-6-10-7-10-2 0 3 6 3 10 2zM20 11c3-6 10-7 10-2 0 3-6 3-10 2z" fill="none" stroke="#ffcf3f" stroke-width="3" stroke-linejoin="round"/><rect x="5" y="20" width="30" height="2.5" fill="rgba(0,0,0,.15)"/></svg>',
  music: '<svg viewBox="0 0 24 24"><path d="M9 17V5l11-2v12" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round"/><circle cx="6.5" cy="17.5" r="3.2" fill="currentColor"/><circle cx="17.5" cy="15.5" r="3.2" fill="currentColor"/></svg>',
  sound: '<svg viewBox="0 0 24 24"><path d="M3 9h4l5-4.5v15L7 15H3z" fill="currentColor"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
  vibe: '<svg viewBox="0 0 24 24"><rect x="7" y="2.5" width="10" height="19" rx="2.5" fill="currentColor"/><rect x="9" y="5" width="6" height="11" rx="1" fill="#fff6e6"/><path d="M3.5 8v8M20.5 8v8" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
  check: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#4cbf3e"/><path d="M7 12.5l3.2 3.2L17.5 8.5" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
};
function hydrateIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach(el => {
    if (el.dataset.done) return;
    el.insertAdjacentHTML('afterbegin', ICONS[el.dataset.icon] || '');
    el.dataset.done = 1;
  });
}

// ---------------------------------------------------------------------
//  Canvas helpers
// ---------------------------------------------------------------------
function rrPath(c, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  c.beginPath();
  c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
}
function makeCanvas(w, h) {
  const cv = document.createElement('canvas');
  cv.width = Math.max(1, Math.round(w * DPR)); cv.height = Math.max(1, Math.round(h * DPR));
  const c = cv.getContext('2d'); c.scale(DPR, DPR);
  return [cv, c];
}

// ---------------- tiles ----------------
function paintTile(c, s, col) {
  const g = s * 0.045, r = s * 0.2, fh = s - 2 * g - s * 0.1;
  c.fillStyle = col.dark; rrPath(c, g, g, s - 2 * g, s - 2 * g, r); c.fill();
  const grd = c.createLinearGradient(0, g, 0, g + fh);
  grd.addColorStop(0, col.light); grd.addColorStop(0.55, col.base); grd.addColorStop(1, col.base);
  c.fillStyle = grd; rrPath(c, g, g, s - 2 * g, fh, r); c.fill();
  const gl = c.createLinearGradient(0, s * 0.1, 0, s * 0.4);
  gl.addColorStop(0, 'rgba(255,255,255,.6)'); gl.addColorStop(1, 'rgba(255,255,255,0)');
  c.fillStyle = gl; rrPath(c, s * 0.14, s * 0.1, s * 0.72, s * 0.3, s * 0.12); c.fill();
  c.fillStyle = 'rgba(255,255,255,.9)';
  c.beginPath(); c.ellipse(s * 0.26, s * 0.21, s * 0.075, s * 0.045, -0.6, 0, Math.PI * 2); c.fill();
  c.lineWidth = Math.max(1, s * 0.028); c.strokeStyle = 'rgba(45,20,10,.28)';
  rrPath(c, g, g, s - 2 * g, s - 2 * g, r); c.stroke();
}
function paintIce(c, s, hp) {
  paintTile(c, s, hp >= 2 ? ICE_THICK : ICE_THIN);
  c.lineCap = 'round';
  c.strokeStyle = 'rgba(255,255,255,.9)'; c.lineWidth = Math.max(1, s * 0.055);
  c.beginPath();
  c.moveTo(s * 0.28, s * 0.62); c.lineTo(s * 0.43, s * 0.32);
  c.moveTo(s * 0.46, s * 0.68); c.lineTo(s * 0.6, s * 0.4);
  c.stroke();
  if (hp >= 2) {
    c.lineWidth = Math.max(1.5, s * 0.065);
    rrPath(c, s * 0.15, s * 0.14, s * 0.7, s * 0.62, s * 0.12); c.stroke();
  } else {
    c.strokeStyle = 'rgba(18,60,92,.65)'; c.lineWidth = Math.max(1, s * 0.045); c.lineJoin = 'round';
    c.beginPath();
    c.moveTo(s * 0.72, s * 0.12); c.lineTo(s * 0.56, s * 0.42); c.lineTo(s * 0.72, s * 0.56); c.lineTo(s * 0.6, s * 0.82);
    c.moveTo(s * 0.56, s * 0.42); c.lineTo(s * 0.38, s * 0.5);
    c.stroke();
  }
}
const tileCache = new Map();
function cachedTile(key, s, paint) {
  const px = Math.max(4, Math.round(s * DPR));
  const k = key + '|' + px;
  let cv = tileCache.get(k);
  if (!cv) {
    if (tileCache.size > 400) tileCache.clear();
    cv = document.createElement('canvas'); cv.width = cv.height = px;
    paint(cv.getContext('2d'), px);
    tileCache.set(k, cv);
  }
  return cv;
}
// idx: 0..6 colour, 'grey'
function drawTile(c, x, y, s, idx, alpha = 1, base = s) {
  const img = cachedTile('t' + idx, base, (cc, px) => paintTile(cc, px, idx === 'grey' ? TILE_GREY : TILE_COLORS[idx]));
  if (alpha !== 1) c.globalAlpha = alpha;
  c.drawImage(img, x, y, s, s);
  if (alpha !== 1) c.globalAlpha = 1;
}
function drawIceTile(c, x, y, s, hp, base = s) {
  c.drawImage(cachedTile('ice' + hp, base, (cc, px) => paintIce(cc, px, hp)), x, y, s, s);
}
function drawGem(c, cx, cy, s) {
  const P = (dx, dy) => [cx + dx * s, cy + dy * s];
  const poly = (pts, fill) => { c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.closePath(); c.fillStyle = fill; c.fill(); };
  const tl = P(-0.22, -0.3), tr = P(0.22, -0.3), r = P(0.4, -0.08), b = P(0, 0.42), l = P(-0.4, -0.08), m = P(0, -0.08);
  poly([tl, tr, r, b, l], '#27c7dc');
  poly([tl, tr, r, l], '#8cefff');
  poly([P(-0.11, -0.3), P(0.11, -0.3), P(0.2, -0.08), P(-0.2, -0.08)], '#d6fcff');
  poly([l, m, b], '#1fb0cc');
  poly([m, r, b], '#1592b4');
  c.beginPath(); [tl, tr, r, b, l].forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.closePath();
  c.lineJoin = 'round'; c.lineWidth = Math.max(1, s * 0.06); c.strokeStyle = '#0b4f63'; c.stroke();
}
function drawBomb(c, x, y, s, n, now) {
  c.drawImage(cachedTile('stone', s, (cc, px) => paintTile(cc, px, TILE_STONE)), x, y, s, s);
  const cx = x + s * 0.47, cy = y + s * 0.55, r = s * 0.26;
  if (n != null && n <= 3) {
    c.globalAlpha = 0.3 + 0.3 * Math.sin(now / 90);
    c.fillStyle = '#ff3040'; rrPath(c, x + s * 0.05, y + s * 0.05, s * 0.9, s * 0.9, s * 0.2); c.fill();
    c.globalAlpha = 1;
  }
  const rg = c.createRadialGradient(cx - r * 0.4, cy - r * 0.4, r * 0.1, cx, cy, r);
  rg.addColorStop(0, '#5a5970'); rg.addColorStop(1, '#16151f');
  c.fillStyle = rg; c.beginPath(); c.arc(cx, cy, r, 0, Math.PI * 2); c.fill();
  c.strokeStyle = '#c9a36b'; c.lineWidth = Math.max(1, s * 0.05); c.lineCap = 'round';
  c.beginPath(); c.moveTo(cx + r * 0.55, cy - r * 0.8); c.quadraticCurveTo(cx + r * 1.0, cy - r * 1.55, cx + r * 1.3, cy - r * 1.25); c.stroke();
  const sp = s * (0.06 + 0.02 * Math.sin(now / 60));
  c.fillStyle = '#ffb02e'; c.beginPath(); c.arc(cx + r * 1.3, cy - r * 1.25, sp * 1.5, 0, Math.PI * 2); c.fill();
  c.fillStyle = '#fff6b0'; c.beginPath(); c.arc(cx + r * 1.3, cy - r * 1.25, sp * 0.7, 0, Math.PI * 2); c.fill();
  if (n != null) {
    const bxp = x + s * 0.74, byp = y + s * 0.74, br = s * 0.2;
    c.fillStyle = n <= 3 ? '#f0303f' : '#fff6e6';
    c.beginPath(); c.arc(bxp, byp, br, 0, Math.PI * 2); c.fill();
    c.lineWidth = Math.max(1, s * 0.04); c.strokeStyle = '#4a2c17'; c.stroke();
    c.fillStyle = n <= 3 ? '#fff' : '#4a2c17';
    c.font = `${Math.round(s * 0.28)}px "Lilita One", sans-serif`;
    c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(n, bxp, byp + s * 0.015);
  }
}
function drawStarShape(c, cx, cy, s, fill = '#ffcf3f', stroke = '#d4860f') {
  c.beginPath();
  for (let k = 0; k < 10; k++) {
    const a = -Math.PI / 2 + k * Math.PI / 5, rad = k % 2 ? s * 0.22 : s * 0.48;
    c.lineTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad);
  }
  c.closePath(); c.fillStyle = fill; c.fill();
  c.lineJoin = 'round'; c.lineWidth = Math.max(1, s * 0.07); c.strokeStyle = stroke; c.stroke();
}
function drawCheck(c, cx, cy, r) {
  c.fillStyle = '#4cbf3e'; c.beginPath(); c.arc(cx, cy, r, 0, Math.PI * 2); c.fill();
  c.lineWidth = r * 0.22; c.strokeStyle = '#2c8a22'; c.stroke();
  c.strokeStyle = '#fff'; c.lineWidth = r * 0.28; c.lineCap = 'round'; c.lineJoin = 'round';
  c.beginPath(); c.moveTo(cx - r * 0.45, cy + r * 0.02); c.lineTo(cx - r * 0.12, cy + r * 0.35); c.lineTo(cx + r * 0.48, cy - r * 0.32); c.stroke();
}
function drawCrown(c, cx, cy, s) {
  c.save(); c.translate(cx - s / 2, cy - s / 2); c.scale(s / 40, s / 40);
  c.lineJoin = 'round'; c.lineWidth = 2.6; c.strokeStyle = '#d4860f';
  c.beginPath(); c.moveTo(6, 29); c.lineTo(4, 12); c.lineTo(13, 19); c.lineTo(20, 8); c.lineTo(27, 19); c.lineTo(36, 12); c.lineTo(34, 29); c.closePath();
  c.fillStyle = '#ffcf3f'; c.fill(); c.stroke();
  rrPath(c, 6, 28, 28, 6, 2.5); c.fillStyle = '#f7a823'; c.fill(); c.stroke();
  c.restore();
}

// ---------------------------------------------------------------------
//  Scenes (static backdrop, painted once per theme / size)
// ---------------------------------------------------------------------
function hillPath(c, W, H, y, amp, freq, ph) {
  c.beginPath(); c.moveTo(0, H);
  for (let x = 0; x <= W + 10; x += 8)
    c.lineTo(x, y + Math.sin(x * freq + ph) * amp + Math.sin(x * freq * 2.3 + ph * 1.7) * amp * 0.35);
  c.lineTo(W, H); c.closePath();
}
function sceneTree(c, x, y, r) {
  c.fillStyle = '#7a5230'; c.fillRect(x - r * 0.15, y - r * 0.9, r * 0.3, r * 0.9);
  c.fillStyle = '#4f9a3f'; c.beginPath(); c.arc(x, y - r * 1.25, r * 0.75, 0, 7); c.fill();
  c.fillStyle = '#62b04d'; c.beginPath(); c.arc(x - r * 0.25, y - r * 1.4, r * 0.45, 0, 7); c.fill();
}
function crystal(c, x, y, w, h, ang, col) {
  c.save(); c.translate(x, y); c.rotate(ang);
  c.fillStyle = col[1];
  c.beginPath(); c.moveTo(-w / 2, 0); c.lineTo(-w / 2, -h * 0.75); c.lineTo(0, -h); c.lineTo(w / 2, -h * 0.75); c.lineTo(w / 2, 0); c.closePath(); c.fill();
  c.fillStyle = col[0];
  c.beginPath(); c.moveTo(-w / 2, 0); c.lineTo(-w / 2, -h * 0.75); c.lineTo(0, -h); c.lineTo(0, 0); c.closePath(); c.fill();
  c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 1.5;
  c.beginPath(); c.moveTo(-w * 0.3, -h * 0.1); c.lineTo(-w * 0.3, -h * 0.7); c.stroke();
  c.restore();
}
function mountains(c, W, H, base, height, col, rnd, n) {
  const pts = []; const step = (W + 100) / n;
  for (let i = 0; i <= n; i++) {
    pts.push([-50 + i * step - step / 2 + rnd() * step * 0.3, base - height * 0.05 * rnd()]);
    pts.push([-50 + i * step + (rnd() - 0.5) * step * 0.3, base - height * (0.5 + rnd() * 0.5)]);
  }
  c.fillStyle = col; c.beginPath(); c.moveTo(-60, H);
  pts.forEach(p => c.lineTo(p[0], p[1])); c.lineTo(W + 60, H); c.closePath(); c.fill();
  c.fillStyle = '#ffffff';
  for (let i = 1; i < pts.length - 1; i += 2) {
    const p = pts[i], a = pts[i - 1], b = pts[i + 1];
    const L = (q, t) => [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t];
    const l = L(a, 0.28), r = L(b, 0.28), m1 = L(a, 0.18), m2 = L(b, 0.2);
    c.beginPath(); c.moveTo(p[0], p[1]); c.lineTo(r[0], r[1]);
    c.lineTo(m2[0] - 4, m2[1] + 6); c.lineTo(p[0], p[1] + (r[1] - p[1]) * 0.6);
    c.lineTo(m1[0] + 4, m1[1] + 5); c.lineTo(l[0], l[1]); c.closePath(); c.fill();
  }
}
function pine(c, x, y, h) {
  c.fillStyle = '#6b4a2e'; c.fillRect(x - h * 0.05, y - h * 0.15, h * 0.1, h * 0.15);
  for (let k = 0; k < 3; k++) {
    const ty = y - h * 0.15 - k * h * 0.25, w = h * (0.42 - k * 0.1);
    c.fillStyle = '#2d5a6b'; c.beginPath(); c.moveTo(x - w, ty); c.lineTo(x + w, ty); c.lineTo(x, ty - h * 0.4); c.closePath(); c.fill();
    c.fillStyle = '#f4fbff'; c.beginPath(); c.moveTo(x - w * 0.35, ty - h * 0.26); c.lineTo(x + w * 0.35, ty - h * 0.26); c.lineTo(x, ty - h * 0.4); c.closePath(); c.fill();
  }
}
function leaf(c, x, y, len, ang, col) {
  c.save(); c.translate(x, y); c.rotate(ang);
  c.fillStyle = col;
  c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(len * 0.5, -len * 0.32, len, 0); c.quadraticCurveTo(len * 0.5, len * 0.32, 0, 0); c.fill();
  c.strokeStyle = 'rgba(255,255,255,.16)'; c.lineWidth = 2;
  c.beginPath(); c.moveTo(0, 0); c.lineTo(len * 0.95, 0); c.stroke();
  c.restore();
}
function skyline(c, W, base, maxH, col, rnd, windows) {
  let x = -10;
  while (x < W + 10) {
    const w = 22 + rnd() * 42, h = maxH * (0.3 + rnd() * 0.7);
    c.fillStyle = col; c.fillRect(x, base - h, w, h);
    if (windows) {
      for (let wy = base - h + 8; wy < base - 8; wy += 10)
        for (let wx = x + 5; wx < x + w - 6; wx += 9)
          if (rnd() < 0.28) { c.fillStyle = rnd() < 0.6 ? 'rgba(255,214,107,.85)' : 'rgba(77,230,255,.8)'; c.fillRect(wx, wy, 4, 5); }
    }
    x += w + 3;
  }
}
const SCENES = {
  meadow(c, W, H, rnd) {
    const sx = W * 0.82, sy = H * 0.08, sr = Math.min(W, H) * 0.07;
    const rg = c.createRadialGradient(sx, sy, 0, sx, sy, sr * 6);
    rg.addColorStop(0, 'rgba(255,246,196,.95)'); rg.addColorStop(1, 'rgba(255,246,196,0)');
    c.fillStyle = rg; c.fillRect(0, 0, W, H);
    c.fillStyle = '#fff6c4'; c.beginPath(); c.arc(sx, sy, sr, 0, 7); c.fill();
    c.fillStyle = '#b6e39b'; hillPath(c, W, H, H * 0.66, H * 0.03, 0.008, 1); c.fill();
    for (let i = 0; i < 10; i++) { const x = rnd() * W; sceneTree(c, x, H * 0.66 + Math.sin(x * 0.008 + 1) * H * 0.03 + 6, 9 + rnd() * 9); }
    c.fillStyle = '#88cd65'; hillPath(c, W, H, H * 0.76, H * 0.025, 0.011, 3); c.fill();
    c.fillStyle = '#5fae47'; hillPath(c, W, H, H * 0.87, H * 0.02, 0.014, 5); c.fill();
    for (let i = 0; i < 90; i++) {
      const x = rnd() * W, y = H * 0.89 + rnd() * H * 0.11;
      c.fillStyle = ['#ffffff', '#ffd2e6', '#fff19a', '#4c9a3a'][i % 4];
      c.beginPath(); c.arc(x, y, 1.4 + rnd() * 1.8, 0, 7); c.fill();
    }
  },
  caves(c, W, H, rnd) {
    const rg = c.createRadialGradient(W / 2, H * 0.95, 0, W / 2, H * 0.95, H * 0.75);
    rg.addColorStop(0, 'rgba(170,110,255,.5)'); rg.addColorStop(1, 'rgba(170,110,255,0)');
    c.fillStyle = rg; c.fillRect(0, 0, W, H);
    c.fillStyle = '#13072a';
    for (let x = -10; x < W + 20;) {
      const w = 22 + rnd() * 44, h = H * (0.04 + rnd() * 0.13);
      c.beginPath(); c.moveTo(x, 0); c.lineTo(x + w, 0); c.lineTo(x + w * 0.5 + (rnd() - 0.5) * 8, h); c.closePath(); c.fill();
      x += w * 0.7;
    }
    c.fillStyle = '#180a2d'; hillPath(c, W, H, H * 0.9, H * 0.015, 0.02, 2); c.fill();
    const cols = [['#d2b0ff', '#8a5ad8'], ['#9af2ff', '#3aaed4'], ['#ffaee4', '#c2549f']];
    for (const [cx, count] of [[W * 0.06, 6], [W * 0.94, 6], [W * 0.5, 3], [W * 0.27, 3], [W * 0.73, 3]]) {
      for (let i = 0; i < count; i++)
        crystal(c, cx + (rnd() - 0.5) * 60, H * 0.93 + rnd() * 10, 10 + rnd() * 15, 40 + rnd() * 75, (rnd() - 0.5) * 0.8, cols[Math.floor(rnd() * 3)]);
    }
  },
  frozen(c, W, H, rnd) {
    mountains(c, W, H, H * 0.52, H * 0.2, '#b4d1ea', rnd, 6);
    mountains(c, W, H, H * 0.64, H * 0.17, '#88afd2', rnd, 5);
    c.fillStyle = '#f3faff'; hillPath(c, W, H, H * 0.86, H * 0.02, 0.012, 2); c.fill();
    for (let i = 0; i < 12; i++) pine(c, rnd() * W, H * 0.87 + rnd() * H * 0.07, 16 + rnd() * 18);
  },
  volcano(c, W, H, rnd) {
    const vx = W * 0.7, top = H * 0.58, base = H * 0.87;
    c.fillStyle = 'rgba(45,16,16,.55)';
    for (let i = 0; i < 9; i++) { c.beginPath(); c.arc(vx + (rnd() - 0.5) * 40 + i * 12, top - 24 - i * 30, 22 + i * 7, 0, 7); c.fill(); }
    const rg = c.createRadialGradient(vx, top, 0, vx, top, 140);
    rg.addColorStop(0, 'rgba(255,150,50,.85)'); rg.addColorStop(1, 'rgba(255,150,50,0)');
    c.fillStyle = rg; c.fillRect(0, 0, W, H);
    c.fillStyle = '#1e0c0a';
    c.beginPath(); c.moveTo(-40, base); c.lineTo(W * 0.18, H * 0.68); c.lineTo(W * 0.26, H * 0.69); c.lineTo(W * 0.5, base); c.closePath(); c.fill();
    c.fillStyle = '#2b1310';
    c.beginPath(); c.moveTo(vx - W * 0.55, base); c.lineTo(vx - 30, top); c.lineTo(vx + 30, top); c.lineTo(vx + W * 0.55, base); c.closePath(); c.fill();
    c.fillStyle = '#ffb347'; c.beginPath(); c.ellipse(vx, top + 1, 30, 4, 0, 0, 7); c.fill();
    c.strokeStyle = '#ff7a1a'; c.lineWidth = 3; c.lineCap = 'round'; c.lineJoin = 'round';
    for (let i = 0; i < 4; i++) {
      c.beginPath(); let x = vx - 20 + i * 13, y = top + 2; c.moveTo(x, y);
      for (let k = 0; k < 6; k++) { x += (rnd() - 0.5) * 14 + (i - 1.5) * 7; y += (base - top) / 8; c.lineTo(x, y); }
      c.stroke();
    }
    c.fillStyle = '#150807';
    c.beginPath(); c.moveTo(0, H);
    for (let x = 0; x <= W + 20; x += 18) c.lineTo(x, H * 0.88 + rnd() * H * 0.025);
    c.lineTo(W, H); c.closePath(); c.fill();
  },
  jungle(c, W, H, rnd) {
    c.fillStyle = 'rgba(255,255,200,.06)';
    for (let i = 0; i < 5; i++) { const x = rnd() * W; c.beginPath(); c.moveTo(x, 0); c.lineTo(x + 60, 0); c.lineTo(x + 40, H); c.lineTo(x - 80, H); c.closePath(); c.fill(); }
    c.fillStyle = '#0b2c1f';
    for (let i = 0; i < 6; i++) { const x = rnd() * W, w = 14 + rnd() * 22; c.fillRect(x, 0, w, H); }
    c.fillStyle = '#0e3826'; hillPath(c, W, H, H * 0.88, H * 0.02, 0.02, 3); c.fill();
    const greens = ['#1d6a3f', '#2a8a50', '#3aa35e', '#17573a'];
    for (const [x, y, a] of [[0, 0, 0.6], [W, 0, 2.54], [0, H, -0.6], [W, H, -2.54]])
      for (let i = 0; i < 8; i++) leaf(c, x, y, 70 + rnd() * 100, a + (rnd() - 0.5) * 1.5, greens[i % 4]);
  },
  neon(c, W, H, rnd) {
    for (let i = 0; i < 90; i++) { c.fillStyle = `rgba(255,255,255,${0.2 + rnd() * 0.6})`; c.fillRect(rnd() * W, rnd() * H * 0.6, 1.5, 1.5); }
    const g = c.createLinearGradient(0, H * 0.55, 0, H * 0.86);
    g.addColorStop(0, 'rgba(233,79,176,0)'); g.addColorStop(1, 'rgba(233,79,176,.4)');
    c.fillStyle = g; c.fillRect(0, H * 0.55, W, H * 0.31);
    skyline(c, W, H * 0.86, H * 0.26, '#1d1442', rnd, false);
    skyline(c, W, H * 0.86, H * 0.18, '#110b29', rnd, true);
    c.fillStyle = '#090616'; c.fillRect(0, H * 0.86, W, H * 0.14);
    c.strokeStyle = 'rgba(77,230,255,.35)'; c.lineWidth = 1;
    for (let i = 0; i < 9; i++) { const y = H * 0.86 + Math.pow(i / 9, 1.8) * H * 0.14; c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
    for (let i = -12; i <= 12; i++) { c.beginPath(); c.moveTo(W / 2 + i * 22, H * 0.86); c.lineTo(W / 2 + i * 95, H); c.stroke(); }
  },
  classic(c, W, H, rnd) {
    for (let i = 0; i < 16; i++) {
      c.fillStyle = `rgba(255,255,255,${0.02 + rnd() * 0.05})`;
      c.beginPath(); c.arc(rnd() * W, rnd() * H, 30 + rnd() * 120, 0, 7); c.fill();
    }
  },
};
function buildScene(th, W, H) {
  const [cv, c] = makeCanvas(W, H);
  const g = c.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, th.sky[0]); g.addColorStop(1, th.sky[1]);
  c.fillStyle = g; c.fillRect(0, 0, W, H);
  SCENES[th.scene](c, W, H, mulberry32(th.id.charCodeAt(0) * 977 + th.id.length));
  return cv;
}

// ---------------------------------------------------------------------
//  Ambient (animated) layer
// ---------------------------------------------------------------------
let amb = [], clouds = [];
function spawnAmb(type, W, H, anywhere) {
  const p = { type, x: Math.random() * W, y: Math.random() * H, ph: Math.random() * 6.28, vx: 0, vy: 0, r: 2 };
  if (type === 'pollen') { p.vy = -(8 + Math.random() * 14); p.r = 1.4 + Math.random() * 2; if (!anywhere) p.y = H + 5; }
  else if (type === 'snow') { p.vy = 25 + Math.random() * 45; p.vx = -10; p.r = 1.4 + Math.random() * 2.6; if (!anywhere) p.y = -5; }
  else if (type === 'ember') { p.vy = -(30 + Math.random() * 55); p.r = 1.2 + Math.random() * 2; if (!anywhere) p.y = H + 5; }
  else if (type === 'firefly') { p.r = 1.8 + Math.random() * 1.4; }
  else if (type === 'sparkle') { p.r = 3 + Math.random() * 4; }
  else if (type === 'neon') { p.vy = 70 + Math.random() * 90; p.len = 8 + Math.random() * 16; p.col = Math.random() < 0.5 ? '77,230,255' : '233,79,176'; if (!anywhere) p.y = -20; }
  else if (type === 'bokeh') { p.vy = -(5 + Math.random() * 10); p.r = 6 + Math.random() * 18; if (!anywhere) p.y = H + 20; }
  return p;
}
function initAmbient(th, W, H) {
  amb = []; clouds = [];
  const n = { pollen: 30, sparkle: 26, snow: 70, ember: 40, firefly: 22, neon: 18, bokeh: 14 }[th.amb] || 0;
  for (let i = 0; i < n; i++) amb.push(spawnAmb(th.amb, W, H, true));
  if (th.scene === 'meadow')
    for (let i = 0; i < 4; i++) clouds.push({ x: Math.random() * W, y: H * (0.04 + Math.random() * 0.22), s: 0.6 + Math.random() * 0.8, v: 5 + Math.random() * 9 });
}
function cloud(c, x, y, s) {
  c.fillStyle = 'rgba(255,255,255,.92)';
  for (const [dx, dy, r] of [[0, 0, 20], [22, -10, 26], [48, -2, 22], [26, 8, 22], [66, 6, 15]]) {
    c.beginPath(); c.arc(x + dx * s, y + dy * s, r * s, 0, 7); c.fill();
  }
}
function drawAmbient(c, dt, now, W, H) {
  for (const cl of clouds) { cl.x += cl.v * dt; if (cl.x > W + 20) cl.x = -100 * cl.s; cloud(c, cl.x, cl.y, cl.s); }
  const t = now / 1000;
  for (let i = 0; i < amb.length; i++) {
    const p = amb[i];
    if (p.type === 'pollen') {
      p.x += (Math.sin(t + p.ph) * 12 + 5) * dt; p.y += p.vy * dt;
      c.fillStyle = 'rgba(255,250,215,.85)'; c.beginPath(); c.arc(p.x, p.y, p.r, 0, 7); c.fill();
      if (p.y < -5) amb[i] = spawnAmb(p.type, W, H, false);
    } else if (p.type === 'snow') {
      p.x += (p.vx + Math.sin(t * 1.3 + p.ph) * 14) * dt; p.y += p.vy * dt;
      c.fillStyle = 'rgba(255,255,255,.9)'; c.beginPath(); c.arc(p.x, p.y, p.r, 0, 7); c.fill();
      if (p.y > H + 5) amb[i] = spawnAmb(p.type, W, H, false);
    } else if (p.type === 'ember') {
      p.x += Math.sin(t * 2 + p.ph) * 18 * dt; p.y += p.vy * dt;
      c.fillStyle = `rgba(255,${140 + Math.floor(60 * Math.sin(t * 8 + p.ph))},40,${0.6 + 0.4 * Math.sin(t * 6 + p.ph)})`;
      c.beginPath(); c.arc(p.x, p.y, p.r, 0, 7); c.fill();
      if (p.y < -5) amb[i] = spawnAmb(p.type, W, H, false);
    } else if (p.type === 'firefly') {
      p.x += Math.cos(t * 0.7 + p.ph) * 22 * dt; p.y += Math.sin(t * 0.9 + p.ph * 1.3) * 22 * dt;
      const a = Math.max(0, Math.sin(t * 2.2 + p.ph));
      c.fillStyle = `rgba(210,255,120,${a * 0.22})`; c.beginPath(); c.arc(p.x, p.y, p.r * 4.5, 0, 7); c.fill();
      c.fillStyle = `rgba(240,255,170,${a})`; c.beginPath(); c.arc(p.x, p.y, p.r, 0, 7); c.fill();
    } else if (p.type === 'sparkle') {
      const a = Math.sin(t * 1.8 + p.ph);
      if (a < -0.98) { p.x = Math.random() * W; p.y = Math.random() * H; }
      if (a > 0) {
        c.fillStyle = `rgba(230,210,255,${a})`;
        const r = p.r * a;
        c.beginPath(); c.moveTo(p.x, p.y - r); c.lineTo(p.x + r * 0.25, p.y - r * 0.25); c.lineTo(p.x + r, p.y);
        c.lineTo(p.x + r * 0.25, p.y + r * 0.25); c.lineTo(p.x, p.y + r); c.lineTo(p.x - r * 0.25, p.y + r * 0.25);
        c.lineTo(p.x - r, p.y); c.lineTo(p.x - r * 0.25, p.y - r * 0.25); c.closePath(); c.fill();
      }
    } else if (p.type === 'neon') {
      p.y += p.vy * dt;
      c.strokeStyle = `rgba(${p.col},.5)`; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(p.x, p.y); c.lineTo(p.x, p.y + p.len); c.stroke();
      if (p.y > H) amb[i] = spawnAmb(p.type, W, H, false);
    } else if (p.type === 'bokeh') {
      p.y += p.vy * dt; p.x += Math.sin(t * 0.5 + p.ph) * 6 * dt;
      c.fillStyle = 'rgba(255,255,255,.05)'; c.beginPath(); c.arc(p.x, p.y, p.r, 0, 7); c.fill();
      if (p.y < -30) amb[i] = spawnAmb(p.type, W, H, false);
    }
  }
}

// ---------------------------------------------------------------------
//  Board backdrop (frame + empty cells), painted once per theme / size
// ---------------------------------------------------------------------
function paintEmpty(c, x, y, s, th) {
  const g = s * 0.055;
  c.fillStyle = th.empty; rrPath(c, x + g, y + g, s - 2 * g, s - 2 * g, s * 0.17); c.fill();
  const sg = c.createLinearGradient(0, y + g, 0, y + s * 0.4);
  sg.addColorStop(0, 'rgba(0,0,0,.32)'); sg.addColorStop(1, 'rgba(0,0,0,0)');
  c.fillStyle = sg; rrPath(c, x + g, y + g, s - 2 * g, s * 0.36, s * 0.17); c.fill();
  c.fillStyle = 'rgba(255,255,255,.08)'; c.fillRect(x + s * 0.2, y + s - g - 1.5, s * 0.6, 1.5);
}
function buildBoard(th, bs, cell, pad) {
  const size = bs + pad * 2;
  const [cv, c] = makeCanvas(size, size);
  const o = pad;
  c.save();
  c.shadowColor = 'rgba(0,0,0,.4)'; c.shadowBlur = 26; c.shadowOffsetY = 14;
  const fg = c.createLinearGradient(0, o - 16, 0, o + bs + 16);
  fg.addColorStop(0, th.frame[0]); fg.addColorStop(1, th.frame[1]);
  c.fillStyle = fg; rrPath(c, o - 16, o - 16, bs + 32, bs + 32, 26); c.fill();
  c.restore();
  c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = 2;
  rrPath(c, o - 14, o - 14, bs + 28, bs + 28, 24); c.stroke();
  c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = 2;
  rrPath(c, o - 6, o - 6, bs + 12, bs + 12, 15); c.stroke();
  c.fillStyle = th.board; rrPath(c, o - 5, o - 5, bs + 10, bs + 10, 14); c.fill();
  const ig = c.createLinearGradient(0, o - 5, 0, o + 22);
  ig.addColorStop(0, 'rgba(0,0,0,.4)'); ig.addColorStop(1, 'rgba(0,0,0,0)');
  c.fillStyle = ig; rrPath(c, o - 5, o - 5, bs + 10, 30, 14); c.fill();
  for (let r = 0; r < 8; r++) for (let k = 0; k < 8; k++) paintEmpty(c, o + k * cell, o + r * cell, cell, th);
  return cv;
}

// ---------------------------------------------------------------------
//  Map decorations (SVG)
// ---------------------------------------------------------------------
function mapDecoItem(id, x, y, k, rnd) {
  const g = inner => `<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) scale(${k.toFixed(2)})">${inner}</g>`;
  const pick = a => a[Math.floor(rnd() * a.length)];
  switch (id) {
    case 'meadow': return g(rnd() < 0.6
      ? '<ellipse cx="0" cy="28" rx="24" ry="6" fill="rgba(0,0,0,.14)"/><rect x="-5" y="0" width="10" height="28" rx="3" fill="#7a5230"/><circle cx="0" cy="-8" r="23" fill="#3f9a3a"/><circle cx="-13" cy="1" r="15" fill="#4fb045"/><circle cx="13" cy="-1" r="16" fill="#4fb045"/><circle cx="-6" cy="-17" r="8" fill="#7fd36a"/>'
      : '<ellipse cx="0" cy="12" rx="26" ry="5" fill="rgba(0,0,0,.14)"/><circle cx="-12" cy="2" r="12" fill="#3f9a3a"/><circle cx="10" cy="0" r="14" fill="#4fb045"/><circle cx="-2" cy="-6" r="11" fill="#5fbf4f"/><circle cx="-6" cy="-3" r="2.5" fill="#ff6b8a"/><circle cx="8" cy="-8" r="2.5" fill="#fff"/><circle cx="14" cy="3" r="2.5" fill="#ffd84a"/>');
    case 'caves': {
      const col = pick([['#d2b0ff', '#8a5ad8'], ['#9af2ff', '#3aaed4'], ['#ffaee4', '#c2549f']]);
      const cr = (dx, w, h, a) => `<g transform="translate(${dx} 0) rotate(${a})"><path d="M${-w / 2} 0V${-h * 0.75}L0 ${-h}L${w / 2} ${-h * 0.75}V0z" fill="${col[1]}"/><path d="M${-w / 2} 0V${-h * 0.75}L0 ${-h}V0z" fill="${col[0]}"/></g>`;
      return g('<ellipse cx="0" cy="2" rx="28" ry="6" fill="rgba(0,0,0,.25)"/>' + cr(-12, 12, 34, -18) + cr(12, 13, 38, 16) + cr(0, 16, 54, 0));
    }
    case 'frozen': return g(rnd() < 0.7
      ? '<ellipse cx="0" cy="30" rx="20" ry="5" fill="rgba(60,100,140,.18)"/><rect x="-3" y="20" width="6" height="10" fill="#6b4a2e"/><path d="M-22 22h44L0 -4z" fill="#2d5a6b"/><path d="M-17 6h34L0 -18z" fill="#2d5a6b"/><path d="M-12 -8h24L0 -32z" fill="#2d5a6b"/><path d="M-7 -20h14L0 -32z" fill="#fff"/><path d="M-9 -6h18L0 -18z" fill="#fff"/><path d="M-12 8h24L0 -4z" fill="#fff"/>'
      : '<ellipse cx="0" cy="6" rx="30" ry="12" fill="#fff"/><ellipse cx="-8" cy="2" rx="16" ry="9" fill="#fff"/><ellipse cx="2" cy="10" rx="28" ry="4" fill="rgba(60,100,140,.15)"/>');
    case 'volcano': return g('<ellipse cx="0" cy="14" rx="30" ry="6" fill="rgba(0,0,0,.3)"/><path d="M-28 14l6-18 14-8 16 4 14 10 4 12z" fill="#2b1310"/><path d="M-22 -4l14-8 16 4" fill="none" stroke="#4a241c" stroke-width="3" stroke-linecap="round"/><path d="M-10 12l4-8 6 3 5-9" fill="none" stroke="#ff8a24" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>');
    case 'jungle': {
      const lf = (a, l, col) => `<g transform="rotate(${a})"><path d="M0 0Q${l / 2} ${-l * 0.32} ${l} 0Q${l / 2} ${l * 0.32} 0 0z" fill="${col}"/><path d="M0 0H${l * 0.92}" stroke="rgba(255,255,255,.2)" stroke-width="2"/></g>`;
      return g(lf(-150, 48, '#1d6a3f') + lf(-110, 56, '#2a8a50') + lf(-70, 52, '#3aa35e') + lf(-30, 46, '#2a8a50') + lf(-90, 40, '#4fbf6e'));
    }
    case 'neon': {
      let s = '<rect x="-18" y="-60" width="36" height="66" fill="#1d1442"/><rect x="-18" y="-62" width="36" height="3" fill="#e94fb0"/>';
      for (let yy = -52; yy < 0; yy += 10) for (let xx = -12; xx < 14; xx += 9) if (rnd() < 0.45) s += `<rect x="${xx}" y="${yy}" width="5" height="5" fill="${rnd() < 0.6 ? '#ffd66b' : '#4de6ff'}"/>`;
      return g(s);
    }
  }
  return '';
}
function mapTexture(id, x, y, rnd) {
  const X = x.toFixed(0), Y = y.toFixed(0);
  switch (id) {
    case 'meadow': return `<path d="M${X} ${Y}l-3 -7M${X} ${Y}l0 -9M${X} ${Y}l3 -7" stroke="#4e9e3c" stroke-width="2" stroke-linecap="round"/>`;
    case 'caves': return `<circle cx="${X}" cy="${Y}" r="${(1 + rnd() * 1.8).toFixed(1)}" fill="#c9a2ff" opacity=".5"/>`;
    case 'frozen': return `<circle cx="${X}" cy="${Y}" r="${(1.5 + rnd() * 2).toFixed(1)}" fill="#fff"/>`;
    case 'volcano': return `<circle cx="${X}" cy="${Y}" r="${(1 + rnd() * 1.6).toFixed(1)}" fill="#ff8a24" opacity=".45"/>`;
    case 'jungle': return `<ellipse cx="${X}" cy="${Y}" rx="5" ry="2.2" transform="rotate(${(rnd() * 180).toFixed(0)} ${X} ${Y})" fill="#1f6b40" opacity=".7"/>`;
    case 'neon': return `<rect x="${X}" y="${Y}" width="2" height="2" fill="#4de6ff" opacity=".4"/>`;
  }
  return '';
}
function mapDeco(th, w, h, rnd) {
  let s = '';
  for (let i = 0; i < 46; i++) s += mapTexture(th.id, rnd() * w, rnd() * h, rnd);
  for (let i = 0; i < 10; i++) {
    const left = i % 2 === 0;
    const x = left ? rnd() * w * 0.15 : w - rnd() * w * 0.15;
    s += mapDecoItem(th.id, x, 70 + (i / 10) * (h - 140) + rnd() * 60, 0.75 + rnd() * 0.5, rnd);
  }
  return `<svg class="deco" width="${w}" height="${h}">${s}</svg>`;
}
