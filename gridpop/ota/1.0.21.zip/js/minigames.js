'use strict';
// =====================================================================
//  MINI GAMES ("Assorti") — a hub of small candy games, kept fully
//  separate from the block-puzzle engine. DOM/CSS, juicy & animated.
// =====================================================================
const MiniGames = (() => {
  const PAL = TILE_COLORS;
  const $ = id => document.getElementById(id);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const sfx = (n, ...a) => { try { if (typeof Sfx !== 'undefined' && Sfx[n]) Sfx[n](...a); } catch (e) {} };
  const vibe = n => { try { if (typeof Haptic !== 'undefined' && Haptic[n]) Haptic[n](); } catch (e) {} };
  const rnd = n => (Math.random() * n) | 0;
  const getBest = k => +localStorage.getItem('gp_mg_' + k) || 0;
  const setBest = (k, v) => { if (v > getBest(k)) localStorage.setItem('gp_mg_' + k, v); };
  // glossy candy fill: a soft shine spot + gradient body + rounded 3D shadow
  function candyCss(ci) {
    const c = PAL[ci % PAL.length];
    return `background:radial-gradient(circle at 34% 24%, rgba(255,255,255,.65), rgba(255,255,255,0) 46%), linear-gradient(${c.light},${c.base});` +
      `box-shadow:inset 0 -5px 0 ${c.dark}, inset 0 4px 0 rgba(255,255,255,.32);`;
  }
  // floating "+score" text + a little candy-coloured spark burst at (cx,cy) viewport coords
  function burst(cx, cy, text, color) {
    const host = $('mini');
    if (text) { const p = el('div', 'mg-float', text); p.style.left = cx + 'px'; p.style.top = cy + 'px'; if (color) p.style.color = color; host.appendChild(p); setTimeout(() => p.remove(), 760); }
    for (let i = 0; i < 9; i++) {
      const s = el('span', 'mg-spark'); const a = Math.random() * 6.283, d = 18 + Math.random() * 38;
      s.style.left = cx + 'px'; s.style.top = cy + 'px';
      s.style.setProperty('--dx', (Math.cos(a) * d).toFixed(1) + 'px');
      s.style.setProperty('--dy', (Math.sin(a) * d).toFixed(1) + 'px');
      s.style.background = PAL[rnd(PAL.length)].base;
      host.appendChild(s); setTimeout(() => s.remove(), 600);
    }
  }
  const centerOf = node => { const r = node.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; };

  // ---------------- navigation ----------------
  let active = null;
  function openHub() { renderHub(); $('menu').classList.remove('show'); $('mini').classList.remove('show'); $('games').classList.add('show'); active = null; sfx('button'); }
  function backToMenu() { $('games').classList.remove('show'); $('mini').classList.remove('show'); $('menu').classList.add('show'); active = null; sfx('button'); }
  function openGame(key) { $('games').classList.remove('show'); $('mini').classList.add('show'); active = key; GAMES[key].start(); sfx('button'); vibe('light'); }
  function backToHub() { $('mini').classList.remove('show'); renderHub(); $('games').classList.add('show'); active = null; sfx('button'); }

  const GAME_LIST = [
    { key: 'blast', name: 'Candy Blast', tag: 'Tap to pop', c: 0 },
    { key: 'merge', name: '2048 Merge', tag: 'Swipe to join', c: 4 },
    { key: 'memory', name: 'Memory', tag: 'Find the pairs', c: 3 },
    { key: 'sort', name: 'Color Sort', tag: 'Sort the tubes', c: 5 },
  ];
  function renderHub() {
    const g = $('gamesGrid'); g.innerHTML = '';
    GAME_LIST.forEach(it => {
      const card = el('button', 'game-card');
      const best = getBest(it.key);
      card.innerHTML =
        `<div class="gc-art">${[0, 1, 2, 3].map(i => `<span style="${candyCss((it.c + i) % PAL.length)}"></span>`).join('')}</div>` +
        `<b>${it.name}</b><small>${it.tag}</small>` +
        (best ? `<em class="gc-best">Best ${best}</em>` : '');
      card.onclick = () => openGame(it.key);
      g.appendChild(card);
    });
  }

  function shell(title, scoreHtml) {
    $('miniTitle').textContent = title;
    $('miniScore').innerHTML = scoreHtml || '';
    const host = $('miniBoard'); host.innerHTML = '';
    const b = el('div', 'mini-inner'); host.appendChild(b);
    $('miniFoot').innerHTML = '';
    return b;
  }
  function footButton(label, fn) { const btn = el('button', 'mini-btn', label); btn.onclick = fn; $('miniFoot').appendChild(btn); return btn; }
  function toastMini(text, color) { const o = el('div', 'mini-pop', text); if (color) o.style.color = color; $('mini').appendChild(o); setTimeout(() => o.remove(), 1200); }

  // =================================================================
  //  1) CANDY BLAST
  // =================================================================
  const Blast = (() => {
    const COLS = 8, ROWS = 9, NC = 5;
    let grid, score, refs, lock;
    function start() {
      score = 0; lock = false; grid = [];
      for (let r = 0; r < ROWS; r++) { grid[r] = []; for (let c = 0; c < COLS; c++) grid[r][c] = rnd(NC); }
      draw(null);
    }
    function draw(dropCols) {
      const b = shell('Candy Blast', scoreHtml());
      b.className = 'grid-board';
      b.style.setProperty('--cols', COLS);
      b.style.maxWidth = Math.min(COLS * 48, 400) + 'px';
      refs = [];
      for (let r = 0; r < ROWS; r++) {
        refs[r] = [];
        for (let c = 0; c < COLS; c++) {
          const v = grid[r][c]; const cell = el('button', 'cell');
          if (v < 0) cell.style.visibility = 'hidden';
          else {
            cell.style.cssText += candyCss(v);
            cell.onclick = () => tap(r, c);
            if (dropCols && dropCols.has(c)) { cell.classList.add('dropin'); cell.style.animationDelay = ((ROWS - r) * 0.022).toFixed(3) + 's'; }
          }
          refs[r][c] = cell; b.appendChild(cell);
        }
      }
      footButton('New game', start);
    }
    function scoreHtml() { return `<b>${score}</b> <small>best ${getBest('blast')}</small>`; }
    function group(r, c) {
      const col = grid[r][c]; if (col < 0) return [];
      const seen = new Set(), stack = [[r, c]], out = [];
      while (stack.length) {
        const [y, x] = stack.pop(), k = y * COLS + x;
        if (seen.has(k)) continue; seen.add(k);
        if (y < 0 || x < 0 || y >= ROWS || x >= COLS || grid[y][x] !== col) continue;
        out.push([y, x]); stack.push([y + 1, x], [y - 1, x], [y, x + 1], [y, x - 1]);
      }
      return out;
    }
    function tap(r, c) {
      if (lock) return;
      const grp = group(r, c);
      if (grp.length < 2) { sfx('nope'); vibe('light'); return; }
      lock = true;
      const gained = grp.length * (grp.length + 1);
      const [cx, cy] = centerOf(refs[r][c]);
      grp.forEach(([y, x]) => { const cell = refs[y][x]; if (cell) { cell.classList.add('popping'); cell.style.animationDelay = (Math.random() * 0.05).toFixed(3) + 's'; } });
      score += gained; setBest('blast', score);
      sfx('clear', Math.min(grp.length, 4), 1); vibe(grp.length >= 5 ? 'heavy' : 'medium');
      burst(cx, cy, '+' + gained, '#fff6e6');
      const cols = new Set(grp.map(p => p[1]));
      setTimeout(() => { grp.forEach(([y, x]) => grid[y][x] = -1); gravity(); draw(cols); lock = false; }, 180);
    }
    function gravity() {
      for (let c = 0; c < COLS; c++) {
        const colv = [];
        for (let r = ROWS - 1; r >= 0; r--) if (grid[r][c] >= 0) colv.push(grid[r][c]);
        for (let r = ROWS - 1; r >= 0; r--) grid[r][c] = colv[ROWS - 1 - r] != null ? colv[ROWS - 1 - r] : rnd(NC);
      }
    }
    return { start };
  })();

  // =================================================================
  //  2) 2048 MERGE
  // =================================================================
  const Merge = (() => {
    const N = 4;
    let g, score, lastSpawn, mergedSet;
    function start() { g = Array.from({ length: N }, () => Array(N).fill(0)); score = 0; lastSpawn = null; mergedSet = new Set(); spawn(); spawn(); draw(); }
    function spawn() {
      const empty = [];
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!g[r][c]) empty.push([r, c]);
      if (!empty.length) return false;
      const [r, c] = empty[rnd(empty.length)]; g[r][c] = Math.random() < 0.9 ? 2 : 4; lastSpawn = r * N + c; return true;
    }
    function slideRow(row) {
      let a = row.filter(v => v), out = [], merged = [], gained = 0;
      for (let i = 0; i < a.length; i++) {
        if (i + 1 < a.length && a[i] === a[i + 1]) { out.push(a[i] * 2); merged.push(out.length - 1); gained += a[i] * 2; i++; }
        else out.push(a[i]);
      }
      while (out.length < N) out.push(0);
      return { out, gained, merged };
    }
    function move(dir) {
      const before = JSON.stringify(g); mergedSet = new Set();
      for (let i = 0; i < N; i++) {
        let line = [];
        for (let j = 0; j < N; j++) line.push(dir === 0 ? g[i][j] : dir === 1 ? g[i][N - 1 - j] : dir === 2 ? g[j][i] : g[N - 1 - j][i]);
        const { out, gained, merged } = slideRow(line); score += gained;
        for (let j = 0; j < N; j++) {
          const v = out[j];
          if (dir === 0) g[i][j] = v; else if (dir === 1) g[i][N - 1 - j] = v; else if (dir === 2) g[j][i] = v; else g[N - 1 - j][i] = v;
        }
        merged.forEach(j => {
          const key = dir === 0 ? i * N + j : dir === 1 ? i * N + (N - 1 - j) : dir === 2 ? j * N + i : (N - 1 - j) * N + i;
          mergedSet.add(key);
        });
      }
      if (JSON.stringify(g) === before) return;
      setBest('merge', score);
      sfx('place', 2); vibe(mergedSet.size ? 'medium' : 'light'); spawn(); draw();
      if (!canMove()) { toastMini('No moves!', '#ffd86b'); sfx('lose'); }
    }
    function canMove() {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        if (!g[r][c]) return true;
        if (c + 1 < N && g[r][c] === g[r][c + 1]) return true;
        if (r + 1 < N && g[r][c] === g[r + 1][c]) return true;
      }
      return false;
    }
    function draw() {
      const b = shell('2048 Merge', `<b>${score}</b> <small>best ${getBest('merge')}</small>`);
      b.className = 'grid-board'; b.style.setProperty('--cols', N); b.style.maxWidth = '360px';
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const v = g[r][c]; const k = r * N + c; const cell = el('div', 'cell merge-cell');
        if (v) {
          cell.style.cssText += candyCss((Math.log2(v) - 1) % PAL.length);
          cell.innerHTML = `<span>${v}</span>`;
          if (mergedSet.has(k)) cell.classList.add('merged');
          else if (k === lastSpawn) cell.classList.add('spawn');
        }
        b.appendChild(cell);
      }
      let sx = 0, sy = 0;
      b.onpointerdown = e => { sx = e.clientX; sy = e.clientY; };
      b.onpointerup = e => {
        const dx = e.clientX - sx, dy = e.clientY - sy;
        if (Math.abs(dx) < 18 && Math.abs(dy) < 18) return;
        if (Math.abs(dx) > Math.abs(dy)) move(dx > 0 ? 1 : 0); else move(dy > 0 ? 3 : 2);
      };
      footButton('New game', start);
    }
    function key(e) { const m = { ArrowLeft: 0, ArrowRight: 1, ArrowUp: 2, ArrowDown: 3 }; if (m[e.key] != null) { e.preventDefault(); move(m[e.key]); } }
    return { start, key };
  })();

  // =================================================================
  //  3) MEMORY MATCH  (persistent cards -> smooth 3D flip)
  // =================================================================
  const Memory = (() => {
    const COLS = 4, PAIRS = 6;
    let deck, first, lock, moves, matched, cards, movesEl;
    function start() {
      const faces = []; for (let i = 0; i < PAIRS; i++) faces.push(i, i);
      for (let i = faces.length - 1; i > 0; i--) { const j = rnd(i + 1);[faces[i], faces[j]] = [faces[j], faces[i]]; }
      deck = faces; first = -1; lock = false; moves = 0; matched = 0; cards = [];
      const b = shell('Memory', `<b id="mgMoves">0</b> <small>moves</small>`);
      movesEl = $('mgMoves');
      b.className = 'grid-board'; b.style.setProperty('--cols', COLS); b.style.maxWidth = '360px';
      for (let i = 0; i < deck.length; i++) {
        const card = el('button', 'mcard');
        card.innerHTML = `<span class="mcard-in"><span class="mcard-back">?</span><span class="mcard-front" style="${candyCss(deck[i])}"><i class="pip"></i></span></span>`;
        card.onclick = () => flip(i);
        cards.push(card); b.appendChild(card);
      }
      footButton('New game', start);
    }
    function flip(i) {
      const card = cards[i];
      if (lock || card.classList.contains('flipped') || card.classList.contains('matched')) return;
      card.classList.add('flipped'); sfx('pick'); vibe('light');
      if (first < 0) { first = i; return; }
      moves++; if (movesEl) movesEl.textContent = moves;
      const a = first; first = -1;
      if (deck[a] === deck[i]) {
        setTimeout(() => { cards[a].classList.add('matched'); card.classList.add('matched'); }, 260);
        matched++; sfx('coin'); vibe('medium');
        const [cx, cy] = centerOf(card); burst(cx, cy, '', '#fff');
        if (matched === PAIRS) { setBest('memory', Math.max(1, 120 - moves * 3)); setTimeout(() => { toastMini('You win! ' + moves + ' moves', '#86e391'); sfx('win'); vibe('success'); }, 350); }
      } else {
        lock = true;
        setTimeout(() => { cards[a].classList.remove('flipped'); card.classList.remove('flipped'); lock = false; }, 760);
      }
    }
    return { start };
  })();

  // =================================================================
  //  4) COLOR SORT  (pour drop-in animation)
  // =================================================================
  const Sort = (() => {
    const CAP = 4, COLORS = 5, EMPTY = 2;
    let tubes, sel, moves, lastPour;
    function start() {
      const NT = COLORS + EMPTY;
      tubes = Array.from({ length: NT }, () => []);
      for (let i = 0; i < COLORS; i++) for (let k = 0; k < CAP; k++) tubes[i].push(i);
      for (let n = 0; n < 220; n++) { const s = rnd(NT), d = rnd(NT); if (s !== d && tubes[s].length && tubes[d].length < CAP) tubes[d].push(tubes[s].pop()); }
      sel = -1; moves = 0; lastPour = null; draw();
    }
    function solved() { return tubes.every(t => t.length === 0 || (t.length === CAP && t.every(v => v === t[0]))); }
    function tap(i) {
      lastPour = null;
      if (sel < 0) { if (tubes[i].length) { sel = i; sfx('pick'); vibe('light'); draw(); } return; }
      if (sel === i) { sel = -1; draw(); return; }
      const src = tubes[sel], dst = tubes[i], col = src[src.length - 1];
      if (dst.length < CAP && (dst.length === 0 || dst[dst.length - 1] === col)) {
        let moved = 0;
        while (src.length && dst.length < CAP && src[src.length - 1] === col) { dst.push(src.pop()); moved++; }
        if (moved) { moves++; sfx('place', 2); vibe('light'); lastPour = { tube: i, count: moved }; }
      } else sfx('nope');
      sel = -1; draw();
      if (solved()) { setBest('sort', Math.max(1, 220 - moves)); setTimeout(() => { toastMini('Solved! ' + moves + ' moves', '#86e391'); sfx('win'); vibe('success'); }, 250); }
    }
    function draw() {
      const b = shell('Color Sort', `<b>${moves}</b> <small>moves</small>`);
      b.className = 'tube-board';
      tubes.forEach((t, i) => {
        const tube = el('button', 'tube' + (sel === i ? ' sel' : ''));
        for (let k = CAP - 1; k >= 0; k--) {
          const seg = el('span', 'seg');
          if (t[k] != null) {
            seg.style.cssText = candyCss(t[k]);
            if (lastPour && lastPour.tube === i && k >= t.length - lastPour.count) { seg.classList.add('drop'); seg.style.animationDelay = ((t.length - 1 - k) * 0.05).toFixed(3) + 's'; }
          } else seg.classList.add('empty');
          tube.appendChild(seg);
        }
        tube.onclick = () => tap(i);
        b.appendChild(tube);
      });
      footButton('Restart', start);
    }
    return { start };
  })();

  const GAMES = { blast: Blast, merge: Merge, memory: Memory, sort: Sort };
  window.addEventListener('keydown', e => { if ($('mini').classList.contains('show') && active === 'merge') Merge.key(e); });

  function wire() {
    const m = $('mAssorti'); if (m) m.onclick = openHub;
    const gb = $('gamesBack'); if (gb) gb.onclick = backToMenu;
    const mb = $('miniBack'); if (mb) mb.onclick = backToHub;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
  return { open: openHub };
})();
