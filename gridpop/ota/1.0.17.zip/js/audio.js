'use strict';
// =====================================================================
//  AUDIO: synthesized sound effects + gentle procedural music
//  (no audio files needed: everything is generated with Web Audio)
// =====================================================================
const Audio2 = (() => {
  let ac = null, master, sfxBus, musicBus, verb, noiseBuf;
  const settings = { sound: true, music: true };

  function init() {
    if (ac) { if (ac.state === 'suspended') ac.resume(); return; }
    try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return; }
    const comp = ac.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 4;
    master = ac.createGain(); master.gain.value = 0.9;
    master.connect(comp); comp.connect(ac.destination);
    sfxBus = ac.createGain(); sfxBus.gain.value = settings.sound ? 1 : 0; sfxBus.connect(master);
    musicBus = ac.createGain(); musicBus.gain.value = 0; musicBus.connect(master);
    // small room reverb from a generated impulse
    verb = ac.createConvolver();
    const len = ac.sampleRate * 1.6, ir = ac.createBuffer(2, len, ac.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = ir.getChannelData(ch);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
    }
    verb.buffer = ir;
    const vg = ac.createGain(); vg.gain.value = 0.28;
    verb.connect(vg); vg.connect(master);
    noiseBuf = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
    const nd = noiseBuf.getChannelData(0);
    for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
    if (settings.music) Music.start();
    Voice.load();
  }
  const now = () => ac.currentTime;
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);

  // ---------- building blocks ----------
  function tone({ f, f2, t = 0, d = 0.2, type = 'sine', v = 0.2, a = 0.004, wet = 0, bus, q }) {
    if (!ac) return;
    const t0 = now() + t, o = ac.createOscillator(), g = ac.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t0);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t0 + d);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(v, t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    let node = o;
    if (q) { const fl = ac.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = q; o.connect(fl); node = fl; }
    node.connect(g); g.connect(bus || sfxBus);
    if (wet) { const w = ac.createGain(); w.gain.value = wet; g.connect(w); w.connect(verb); }
    o.start(t0); o.stop(t0 + d + 0.05);
  }
  function noise({ t = 0, d = 0.1, v = 0.2, type = 'bandpass', f = 1200, f2, Q = 1, wet = 0 }) {
    if (!ac) return;
    const t0 = now() + t, s = ac.createBufferSource(), fl = ac.createBiquadFilter(), g = ac.createGain();
    s.buffer = noiseBuf; s.playbackRate.value = 0.8 + Math.random() * 0.4;
    fl.type = type; fl.frequency.setValueAtTime(f, t0); fl.Q.value = Q;
    if (f2) fl.frequency.exponentialRampToValueAtTime(f2, t0 + d);
    g.gain.setValueAtTime(v, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    s.connect(fl); fl.connect(g); g.connect(sfxBus);
    if (wet) { const w = ac.createGain(); w.gain.value = wet; g.connect(w); w.connect(verb); }
    s.start(t0, Math.random() * 0.5); s.stop(t0 + d + 0.05);
  }
  function bell(f, t = 0, v = 0.12, d = 0.9) {
    tone({ f, t, d, v, wet: 0.5 });
    tone({ f: f * 2.01, t, d: d * 0.5, v: v * 0.35, wet: 0.5 });
    tone({ f: f * 3.98, t, d: d * 0.22, v: v * 0.15, wet: 0.4 });
  }
  const PENTA = [0, 2, 4, 7, 9];
  const penta = (root, i) => root + PENTA[((i % 5) + 5) % 5] + 12 * Math.floor(i / 5);
  const jitter = () => 1 + (Math.random() - 0.5) * 0.06;

  // ---------- sound effects ----------
  const sfx = {
    pick() { tone({ f: 700 * jitter(), f2: 1100, d: 0.06, v: 0.08, type: 'triangle' }); },
    drop() { tone({ f: 500, f2: 300, d: 0.08, v: 0.05, type: 'sine' }); },
    place(cells = 3) {
      const j = jitter();
      tone({ f: 210 * j, f2: 120 * j, d: 0.12, v: 0.32, type: 'triangle' });
      tone({ f: 420 * j, f2: 260, d: 0.05, v: 0.1, type: 'sine' });
      noise({ d: 0.05, v: 0.18, f: 1800, Q: 1.2 });
      if (cells >= 5) tone({ f: 90, f2: 60, d: 0.14, v: 0.2, type: 'sine' });
    },
    clear(lines, streak) {
      const root = 72 + Math.min(streak - 1, 7) * 2;
      const n = 3 + Math.min(lines, 4);
      for (let k = 0; k < n; k++) bell(mtof(penta(root, k)), k * 0.055, 0.1, 0.7);
      noise({ d: 0.35, v: 0.12, type: 'highpass', f: 800, f2: 6000, wet: 0.3 });
      tone({ f: 160, f2: 80, d: 0.18, v: 0.22 });
      if (lines >= 2) for (let k = 0; k < 6; k++) tone({ f: mtof(penta(root + 24, k * 2)), t: 0.25 + k * 0.035, d: 0.25, v: 0.035, wet: 0.7 });
    },
    combo(streak) {
      const r = 60 + Math.min(streak, 8) * 2;
      [0, 4, 7, 12].forEach((s, i) => tone({ f: mtof(r + s), t: 0.18 + i * 0.01, d: 0.6, v: 0.06, type: 'sawtooth', q: 2400, wet: 0.4 }));
    },
    // bright, escalating "nice!/great!/amazing!" sparkle that rises with the tier
    praise(tier) {
      const base = 74 + Math.min(tier, 7) * 2;
      [0, 4, 7, 11, 12].forEach((s, i) => bell(mtof(base + s), i * 0.045, 0.095, 0.6));
      tone({ f: mtof(base - 12), d: 0.28, v: 0.13, type: 'triangle', wet: 0.3 });
      noise({ t: 0.02, d: 0.3, v: 0.08, type: 'highpass', f: 4000, f2: 9000, wet: 0.4 });
      Voice.say(PRAISE_VOICE[Math.min(tier, PRAISE_VOICE.length - 1)], 0.95, 1 + Math.min(tier, 6) * 0.015);
    },
    perfect() { [0, 4, 7, 12, 16, 19, 24].forEach((s, i) => bell(mtof(72 + s), i * 0.07, 0.09, 1.1)); Voice.say('perfect', 1.0); },
    gem() { bell(mtof(88), 0, 0.09, 0.6); bell(mtof(95), 0.07, 0.08, 0.8); },
    iceCrack() { noise({ d: 0.07, v: 0.3, type: 'highpass', f: 3000, Q: 0.7 }); tone({ f: 2400, f2: 1800, d: 0.05, v: 0.05, type: 'square', q: 4000 }); },
    iceBreak() {
      noise({ d: 0.25, v: 0.25, type: 'highpass', f: 2500, wet: 0.4 });
      for (let k = 0; k < 5; k++) tone({ f: 2000 + Math.random() * 3000, t: k * 0.02, d: 0.25, v: 0.04, wet: 0.6 });
    },
    defuse() { noise({ d: 0.4, v: 0.18, type: 'bandpass', f: 5000, f2: 600, Q: 2 }); bell(mtof(79), 0.15, 0.08); },
    explode() {
      noise({ d: 1.1, v: 0.55, type: 'lowpass', f: 1600, f2: 80, Q: 0.5, wet: 0.3 });
      tone({ f: 120, f2: 30, d: 0.8, v: 0.5 });
    },
    hammer() {
      tone({ f: 140, f2: 45, d: 0.3, v: 0.45 });
      noise({ d: 0.25, v: 0.35, type: 'lowpass', f: 2500, f2: 300 });
      noise({ t: 0.02, d: 0.12, v: 0.2, type: 'highpass', f: 2000 });
    },
    button() { tone({ f: 520, f2: 780, d: 0.07, v: 0.09, type: 'triangle' }); },
    star(i) { bell(mtof(76 + i * 4), 0, 0.13, 1.0); tone({ f: mtof(64 + i * 4), d: 0.4, v: 0.06, type: 'triangle' }); },
    coin() { tone({ f: mtof(83), d: 0.08, v: 0.08, type: 'square', q: 5000 }); tone({ f: mtof(88), t: 0.07, d: 0.35, v: 0.08, type: 'square', q: 5000, wet: 0.2 }); },
    win() {
      const seq = [60, 64, 67, 72, 76, 79, 84];
      seq.forEach((m, i) => bell(mtof(m + 12), i * 0.08, 0.09, 0.9));
      [60, 64, 67, 72].forEach(m => tone({ f: mtof(m), t: 0.6, d: 1.4, v: 0.05, type: 'sawtooth', q: 1800, wet: 0.5 }));
    },
    lose() { [67, 63, 60, 55].forEach((m, i) => tone({ f: mtof(m), t: i * 0.16, d: 0.5, v: 0.09, type: 'triangle', q: 1500, wet: 0.3 })); },
    reward() {
      for (let k = 0; k < 10; k++) tone({ f: mtof(penta(79, k)), t: k * 0.04, d: 0.3, v: 0.05, wet: 0.6 });
      sfx.coin();
    },
    nope() { tone({ f: 220, f2: 180, d: 0.12, v: 0.12, type: 'triangle' }); },
  };

  // ---------- spoken voice callouts ("Nice!", "Good!", "Wow!") ----------
  // Short MP3 clips (most reliable for iOS Web Audio decodeAudioData) decoded once
  // and played through the sfx bus, so the sound toggle and mix apply.
  // Files live in www/audio/voice/. The anti-stack guard uses a wall clock, not the
  // audio clock, which stays at ~0 while the context is suspended.
  const Voice = (() => {
    const WORDS = ['nice', 'good', 'great', 'sweet', 'awesome', 'amazing', 'fantastic', 'incredible', 'unreal', 'insane', 'wow', 'perfect', 'combo'];
    const buffers = {};
    let loaded = false;
    // Decode via a single decodeAudioData call, honouring BOTH the callback form
    // (the only form guaranteed on older iOS WebKit) and the promise form; whichever
    // settles first wins. Clips are CBR MP3 — VBR MP3 is what iOS silently refuses.
    function decode(ab) {
      return new Promise((resolve, reject) => {
        let settled = false;
        const ok = buf => { if (!settled) { settled = true; resolve(buf); } };
        const no = err => { if (!settled) { settled = true; reject(err); } };
        let p;
        try { p = ac.decodeAudioData(ab, ok, no); } catch (e) { no(e); return; }
        if (p && p.then) p.then(ok, no);
      });
    }
    function load() {
      if (loaded || !ac) return; loaded = true;
      WORDS.forEach(w => {
        fetch('audio/voice/' + w + '.mp3')
          .then(r => r.ok ? r.arrayBuffer() : Promise.reject(r.status))
          .then(ab => decode(ab))
          .then(buf => { buffers[w] = buf; })
          .catch(() => {});
      });
    }
    let lastAt = -1e9;
    const clock = () => (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    function say(word, gain = 0.95, rate = 1) {
      if (!ac || !settings.sound) return;
      const buf = buffers[word];
      if (!buf) return;
      const now = clock();                 // wall-clock ms, independent of the (maybe-suspended) audio clock
      if (now - lastAt < 120) return;      // never stack two voices on top of each other
      lastAt = now;
      if (ac.state === 'suspended') ac.resume();
      const s = ac.createBufferSource(), g = ac.createGain();
      s.buffer = buf; s.playbackRate.value = rate;
      g.gain.value = gain;
      s.connect(g); g.connect(sfxBus);
      s.start();
    }
    return { load, say };
  })();
  // Voice word for each praise tier — kept in step with PRAISE[] in game.js.
  const PRAISE_VOICE = ['nice', 'good', 'great', 'sweet', 'awesome', 'amazing', 'fantastic', 'incredible', 'unreal', 'insane'];

  // ---------- music: soft pads, bass and a plucked pentatonic melody ----------
  const Music = (() => {
    const PROG = [[0, 4, 7], [7, 11, 14], [9, 12, 16], [5, 9, 12]]; // I V vi IV
    let timer = null, step = 0, next = 0, root = 57, bpm = 92, motif = [];
    function newMotif() {
      motif = [];
      for (let i = 0; i < 16; i++) motif.push(Math.random() < 0.42 ? Math.floor(Math.random() * 8) : null);
    }
    function schedule(s, t) {
      const bar = Math.floor(s / 8) % 4, chord = PROG[bar], beat = 60 / bpm / 2;
      const T = t - ac.currentTime;
      if (s % 8 === 0) {
        chord.forEach(c => tone({ f: mtof(root + 12 + c), t: T, d: beat * 8.4, a: 0.5, v: 0.028, type: 'triangle', q: 900, bus: musicBus }));
        tone({ f: mtof(root - 12 + chord[0]), t: T, d: beat * 3, v: 0.09, a: 0.02, bus: musicBus });
      }
      if (s % 8 === 4) tone({ f: mtof(root - 12 + chord[0]), t: T, d: beat * 3, v: 0.06, a: 0.02, bus: musicBus });
      const m = motif[s % 16];
      if (m != null) {
        const f = mtof(penta(root + 24, m));
        tone({ f, t: T, d: 0.5, v: 0.045, type: 'sine', bus: musicBus });
        tone({ f: f * 2, t: T, d: 0.18, v: 0.012, type: 'triangle', bus: musicBus });
      }
      if (s % 64 === 63) newMotif();
    }
    return {
      start() {
        if (!ac || timer) return;
        newMotif(); next = ac.currentTime + 0.15;
        musicBus.gain.cancelScheduledValues(ac.currentTime);
        musicBus.gain.setTargetAtTime(0.75, ac.currentTime, 0.8);
        timer = setInterval(() => {
          while (next < ac.currentTime + 0.25) { schedule(step, next); next += 60 / bpm / 2; step++; }
        }, 60);
      },
      stop() {
        if (!timer) return;
        clearInterval(timer); timer = null;
        if (musicBus) musicBus.gain.setTargetAtTime(0, ac.currentTime, 0.2);
      },
      setTheme(i) { root = 57 + [0, 3, 5, -2, 2, 7][i % 6]; bpm = [92, 84, 88, 104, 96, 110][i % 6]; },
    };
  })();

  document.addEventListener('visibilitychange', () => {
    if (!ac) return;
    if (document.hidden) ac.suspend(); else ac.resume();
  });

  return {
    init, sfx, Music, Voice,
    get ready() { return !!ac; },
    setSound(on) { settings.sound = on; if (sfxBus) sfxBus.gain.value = on ? 1 : 0; },
    setMusic(on) { settings.music = on; if (!ac) return; if (on) Music.start(); else Music.stop(); },
    configure(s) { settings.sound = s.sound; settings.music = s.music; },
  };
})();
const Sfx = Audio2.sfx;
