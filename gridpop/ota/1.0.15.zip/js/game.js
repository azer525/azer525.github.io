'use strict';
// =====================================================================
//  GAME: logic, levels, UI screens, rendering
// =====================================================================

// Ads, Haptic: js/native.js · Audio2, Sfx: js/audio.js

// ---------------- CONFIG ----------------
const N = 8, ICE = 8, BOMB = 9, HAMMER_COST = 50;
const COLORS = TILE_COLORS.map(c => c.base);
const GOAL_ICON = { lines: 'lines', score: 'star', gems: 'gem', ice: 'ice', bombs: 'bomb' };
const GOAL_LABEL = { lines: 'lines', score: 'points', gems: 'gems', ice: 'ice blocks', bombs: 'bombs' };
const NEW_INFO = {
  gems: ['gem', 'New: Gems', 'Clear a line that holds a gem to collect it.'],
  ice: ['ice', 'New: Ice', 'Thick ice must be cleared twice before it breaks.'],
  bombs: ['bomb', 'New: Bombs', "Clear the bomb's row or column before its counter hits zero."],
};
const SHAPE_DEFS = [
  'X', 'XX', 'X\nX', 'XXX', 'X\nX\nX', 'XXXX', 'X\nX\nX\nX', 'XXXXX', 'X\nX\nX\nX\nX',
  'XX\nXX', 'XXX\nXXX\nXXX', 'XXX\nXXX', 'XX\nXX\nXX',
  'X.\nXX', '.X\nXX', 'XX\nX.', 'XX\n.X',
  'X..\nXXX', '..X\nXXX', 'XXX\nX..', 'XXX\n..X',
  'X.\nX.\nXX', '.X\n.X\nXX', 'XX\nX.\nX.', 'XX\n.X\n.X',
  'XXX\n.X.', '.X.\nXXX', 'X.\nXX\nX.', '.X\nXX\n.X',
  'XX.\n.XX', '.XX\nXX.', 'X.\nXX\n.X', '.X\nXX\nX.',
  'X..\nX..\nXXX', '..X\n..X\nXXX', 'XXX\nX..\nX..', 'XXX\n..X\n..X'
];
const SHAPES = SHAPE_DEFS.map(s => {
  const rows = s.split('\n'), cells = [];
  rows.forEach((row, r) => [...row].forEach((ch, c) => { if (ch === 'X') cells.push([r, c]); }));
  const w = Math.max(...rows.map(x => x.length)), h = rows.length;
  const weight = cells.length >= 9 ? 0.4 : (cells.length >= 5 ? 0.6 : 1);
  return { cells, w, h, weight };
});
const TOTAL_W = SHAPES.reduce((a, s) => a + s.weight, 0);

// ---------------- SAVE ----------------
const SAVE_KEY = 'gp_save_v1';
const save = Object.assign({
  unlocked: 1, stars: {}, coins: 100, best: +localStorage.getItem('gp_best') || 0, seen: {}, wins: 0,
  hammers: 0, daily: { last: null, streak: 0 }, settings: { sound: true, music: true, vibe: true },
  name: '', avatar: 0,
}, JSON.parse(localStorage.getItem(SAVE_KEY) || '{}'));
function persist() { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); updateCoins(); }
function updateCoins() {
  document.getElementById('coinTxt').textContent = save.coins;
  const price = document.getElementById('hammerPrice'), cnt = document.getElementById('hammerCount');
  price.hidden = save.hammers > 0; cnt.hidden = save.hammers <= 0; cnt.textContent = save.hammers;
}
const totalStars = () => Object.values(save.stars).reduce((a, b) => a + b, 0);

// ---------------- STATE ----------------
const cvs = document.getElementById('c');
let ctx = cvs.getContext('2d');
let mode = 'menu';           // menu | level | endless
let lv = null;
let grid, ice, gem, bomb;
let tray = [], score = 0, displayScore = 0, streak = 0, sinceClear = 0;
let over = false, continues = 0, movesLeft = 0, gamesPlayed = 0;
let prog = { lines: 0, gems: 0, ice: 0, bombs: 0 };
let drag = null, hammerMode = false;
let anims = [], particles = [], popups = [], flyers = [], flashes = [], menuTiles = [];
let shake = 0, goalPos = {};
// Escalating praise callouts (Block-Blast style): the bigger the combo, the louder the praise.
const PRAISE = ['Nice!', 'Good!', 'Great!', 'Sweet!', 'Awesome!', 'Amazing!', 'Fantastic!', 'Incredible!', 'Unreal!', 'Insane!'];
const PRAISE_COLOR = ['#86e391', '#76ccff', '#ffcf3f', '#ff96c4', '#ab97ff', '#ffa14e'];
let W, H, cell, bx, by, bs, trayY, trayH;
let sceneCv = null, boardCv = null, curThemeId = null;
const BOARD_PAD = 40;
let tilesCv = null, tilesCtx = null, boardDirty = true;
let bounces = new Map();   // cell key -> seconds since it was placed (squash & stretch)
let rings = [];            // shockwave rings on line clears
let ghost = null;          // cached drop preview {key, rows, cols}
let returning = null;      // piece flying back to the tray after an invalid drop
let introT = 1;            // level start drop-in animation, 0 -> 1
let boardPop = 1;          // small board "thump" when a piece lands
let movesBump = 0, goalBump = {}, lastProg = {};
const easeOutBack = t => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
const easeOutCubic = t => 1 - Math.pow(1 - t, 3);
const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;
function markDirty() { boardDirty = true; ghost = null; snapCache = null; for (const p of tray) if (p) p.fits = fitsAnywhere(p.shape); }

const mk = v => Array.from({ length: N }, () => Array(N).fill(v));
const copy = g => g.map(r => r.slice());

// ---------------- AUDIO / HAPTICS / TOAST ----------------
function applySettings() {
  const s = save.settings;
  Audio2.configure(s); Audio2.setSound(s.sound); Audio2.setMusic(s.music);
  window.__musicOn = s.music;
  Haptic.enabled = s.vibe;
}
document.addEventListener('pointerdown', () => { const first = !Audio2.ready; Audio2.init(); if (first) applySettings(); }, { capture: true });
document.addEventListener('click', e => { if (e.target.closest('button')) { Sfx.button(); Haptic.light(); } }, { capture: true });
let toastTimer = null;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}
const noAd = () => toast('No video available right now. Try again soon.');

// ---------------- LEVEL GENERATOR ----------------
function shuffle(a, rnd) {
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
function genLevel(L) {
  const rnd = mulberry32(L * 7919 + 13), ri = n => Math.floor(rnd() * n);
  const world = Math.floor((L - 1) / 10), inW = (L - 1) % 10;
  const avail = ['lines', 'score'];
  if (L >= 11) avail.push('gems');
  if (L >= 21) avail.push('ice');
  if (L >= 31) avail.push('bombs');
  const newest = (world >= 1 && world <= 3) ? avail[avail.length - 1] : null;
  const primary = (newest && (inW === 0 || rnd() < 0.5)) ? newest : avail[ri(avail.length)];
  const types = [primary];
  if ((inW === 4 || inW === 9) && L > 5) {
    let s; do { s = avail[ri(avail.length)]; } while (s === primary);
    types.push(s);
  }

  const d = { L, world, inW, theme: THEMES[world % THEMES.length], goals: [], grid: mk(0), ice: mk(0), gem: mk(0), bomb: mk(0) };
  const rowC = Array(N).fill(0), colC = Array(N).fill(0);
  const canFill = (r, c, extra = 0) => !d.grid[r][c] && rowC[r] + extra < 6 && colC[c] < 6;
  const fill = (r, c, v) => { d.grid[r][c] = v; rowC[r]++; colC[c]++; };
  const all = []; for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) all.push([r, c]);
  const addNew = (n, make) => {
    const out = [];
    for (const [r, c] of shuffle(all.slice(), rnd)) {
      if (out.length >= n) break;
      if (canFill(r, c)) { make(r, c); out.push([r, c]); }
    }
    return out;
  };

  const pat = ri(6), cand = [];
  for (const [r, c] of all) {
    let ok = true;
    if (pat === 1) ok = c < 4;
    else if (pat === 2) ok = r >= 1 && r <= 6 && c >= 1 && c <= 6 && (r === 1 || r === 6 || c === 1 || c === 6);
    else if (pat === 3) ok = (r + c) % 3 === 0;
    else if (pat === 4) ok = r >= 2 && r <= 5 && c >= 2 && c <= 5;
    else if (pat === 5) ok = (r < 3 || r > 4) && (c < 3 || c > 4);
    if (ok) cand.push([r, c]);
  }
  shuffle(cand, rnd);
  let want = L === 1 ? 0 : Math.min(24, 2 + Math.floor(L * 0.45) + ri(4));
  for (const [r, c] of cand) {
    if (want <= 0) break;
    if (pat === 1) {
      const c2 = N - 1 - c;
      if (canFill(r, c, 1) && canFill(r, c2, 1)) { const v = 1 + ri(7); fill(r, c, v); fill(r, c2, v); want -= 2; }
    } else if (canFill(r, c)) { fill(r, c, 1 + ri(7)); want--; }
  }

  let moves = 0;
  for (const t of types) {
    let target;
    if (t === 'lines') {
      target = Math.min(18, 3 + Math.floor(L / 3));
      moves += target * 2.6 + 5;
    } else if (t === 'score') {
      target = Math.round((120 + L * 30) / 10) * 10;
      moves += target / 11 + 6;
    } else if (t === 'gems') {
      const n = Math.min(10, 3 + Math.floor((L - 10) / 6));
      let spots = shuffle(all.filter(([r, c]) => d.grid[r][c] >= 1 && d.grid[r][c] <= 7), rnd).slice(0, n);
      if (spots.length < n) spots = spots.concat(addNew(n - spots.length, (r, c) => fill(r, c, 1 + ri(7))));
      spots.forEach(([r, c]) => { d.gem[r][c] = 1; });
      target = spots.length;
      moves += target * 4.5 + 12;
    } else if (t === 'ice') {
      const n = Math.min(14, 4 + Math.floor((L - 20) / 4));
      const hp = () => (L >= 24 && rnd() < 0.6 ? 2 : 1);
      let spots = shuffle(all.filter(([r, c]) => d.grid[r][c] >= 1 && d.grid[r][c] <= 7 && !d.gem[r][c]), rnd).slice(0, n);
      spots.forEach(([r, c]) => { d.grid[r][c] = ICE; d.ice[r][c] = hp(); });
      if (spots.length < n) spots = spots.concat(addNew(n - spots.length, (r, c) => { fill(r, c, ICE); d.ice[r][c] = hp(); }));
      target = spots.length;
      let hpSum = 0; spots.forEach(([r, c]) => { hpSum += d.ice[r][c]; });
      moves += hpSum * 2 + 12;
    } else if (t === 'bombs') {
      const n = L >= 45 ? 2 : 1;
      const timer = Math.max(6, 12 - Math.floor((L - 30) / 12));
      target = addNew(n, (r, c) => { fill(r, c, BOMB); d.bomb[r][c] = timer; }).length;
      moves += 6 + target * 3;
    }
    d.goals.push({ type: t, target });
  }
  if (types.length > 1) moves *= 0.8;
  if (inW === 9) moves *= 0.9;
  if (inW === 0) moves *= 1.15;
  d.moves = Math.max(10, Math.round(moves));
  return d;
}

// ---------------- GAME LOGIC ----------------
function randomShape() {
  let r = Math.random() * TOTAL_W;
  for (const s of SHAPES) { r -= s.weight; if (r <= 0) return s; }
  return SHAPES[0];
}
function canPlace(shape, r, c) {
  for (const [dr, dc] of shape.cells) {
    const rr = r + dr, cc = c + dc;
    if (rr < 0 || cc < 0 || rr >= N || cc >= N || grid[rr][cc]) return false;
  }
  return true;
}
function fitsAnywhere(shape) {
  for (let r = 0; r <= N - shape.h; r++)
    for (let c = 0; c <= N - shape.w; c++)
      if (canPlace(shape, r, c)) return true;
  return false;
}
function anyFits() { return tray.some(p => p && fitsAnywhere(p.shape)); }
function refill() {
  for (let attempt = 0; attempt < 40; attempt++) {
    tray = [0, 1, 2].map(i => ({ shape: randomShape(), color: (Math.random() * COLORS.length) | 0, t: -i * 0.09 }));
    if (anyFits()) break;
  }
  markDirty();
}
function resetRun() {
  score = 0; displayScore = 0; streak = 0; sinceClear = 0; continues = 0; over = false;
  prog = { lines: 0, gems: 0, ice: 0, bombs: 0 };
  anims = []; particles = []; popups = []; flyers = []; flashes = [];
  drag = null; setHammer(false);
  bounces = new Map(); rings = []; ghost = null; returning = null; landing = null;
  movesBump = 0; goalBump = {}; lastProg = {}; boardDirty = true; boardPop = 1;
}
function startEndless() {
  mode = 'endless';
  grid = mk(0); ice = mk(0); gem = mk(0); bomb = mk(0);
  resetRun(); refill();
  introT = 0;
  setHud('Endless');
  show(null);
}
function goalCard(g, withProgress) {
  const cur = Math.min(progOf(g.type), g.target), done = withProgress && cur >= g.target;
  const num = withProgress ? `${cur}<small>/${g.target}</small>` : g.target;
  return `<div class="gcard${done ? ' done' : ''}"><i data-icon="${GOAL_ICON[g.type]}"></i>${done ? '<i class="gcheck" data-icon="check"></i>' : ''}<b>${num}</b><span>${GOAL_LABEL[g.type]}</span></div>`;
}
function startLevel(L) {
  mode = 'level';
  lv = genLevel(L);
  grid = copy(lv.grid); ice = copy(lv.ice); gem = copy(lv.gem); bomb = copy(lv.bomb);
  resetRun(); refill();
  movesLeft = lv.moves;
  setHud('Level ' + L);

  const rib = document.getElementById('introRibbon');
  rib.textContent = 'Level ' + L;
  rib.style.setProperty('--rc', lv.theme.rc); rib.style.setProperty('--rd', lv.theme.rd);
  document.getElementById('introWorld').textContent = `World ${lv.world + 1} · ${lv.theme.name}`;
  const goals = document.getElementById('introGoals');
  goals.innerHTML = lv.goals.map(g => goalCard(g, false)).join('');
  const fresh = lv.goals.map(g => g.type).find(t => NEW_INFO[t] && !save.seen[t]);
  const nt = document.getElementById('introNew');
  nt.hidden = !fresh;
  if (fresh) {
    const [ic, title, text] = NEW_INFO[fresh];
    nt.innerHTML = `<i data-icon="${ic}"></i><div><b>${title}</b>${text}</div>`;
    save.seen[fresh] = 1; persist();
  }
  document.getElementById('introMoves').textContent = lv.moves;
  hydrateIcons(document.getElementById('intro'));
  show('intro');
}
function progOf(type) { return type === 'score' ? score : prog[type]; }
function goalsDone() { return lv.goals.every(g => progOf(g.type) >= g.target); }

function linesToClear() {
  const rows = [], cols = [];
  for (let r = 0; r < N; r++) if (grid[r].every(v => v)) rows.push(r);
  for (let c = 0; c < N; c++) {
    let full = true;
    for (let r = 0; r < N; r++) if (!grid[r][c]) { full = false; break; }
    if (full) cols.push(c);
  }
  return { rows, cols };
}
function cellColor(r, c) {
  const v = grid[r][c];
  return v === ICE ? '#bfe8ff' : v === BOMB ? '#5d6178' : (COLORS[v - 1] || '#fff');
}
function burst(x, y, color, n = 5, power = 230, idx = null) {
  for (let k = 0; k < n; k++) {
    const a = Math.random() * Math.PI * 2, sp = 60 + Math.random() * power;
    particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 160, life: 0.8, max: 0.8, color, idx,
      s: cell * (idx != null ? 0.26 + Math.random() * 0.14 : 0.12 + Math.random() * 0.14), rot: Math.random() * 6, vr: (Math.random() - 0.5) * 9 });
  }
}
function sparkles(x, y, n) {
  for (let k = 0; k < n; k++) {
    const a = Math.random() * Math.PI * 2, sp = 40 + Math.random() * 120;
    particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 0.55 + Math.random() * 0.3, max: 0.85, spark: true,
      s: cell * (0.12 + Math.random() * 0.12), rot: 0, vr: 0 });
  }
}
function clearCell(r, c, delay = 0) {
  const v = grid[r][c];
  anims.push({ r, c, v, hp: ice[r][c], t: -delay });
  const px = bx + (c + 0.5) * cell, py = by + (r + 0.5) * cell;
  burst(px, py, cellColor(r, c), 4, 240, v >= 1 && v <= 7 ? v - 1 : null);
  sparkles(px, py, 3);
  grid[r][c] = 0;
}
function hitCells(set, origin) {
  set.forEach(k => {
    const r = (k / N) | 0, c = k % N, v = grid[r][c];
    if (!v) return;
    const x = bx + (c + 0.5) * cell, y = by + (r + 0.5) * cell;
    const delay = origin ? Math.hypot(r - origin[0], c - origin[1]) * 0.025 : 0;
    if (v === ICE && ice[r][c] > 1) { ice[r][c]--; burst(x, y, '#eaf9ff', 7, 170); Sfx.iceCrack(); return; }
    if (v === ICE) { ice[r][c] = 0; prog.ice++; Sfx.iceBreak(); }
    if (v === BOMB) {
      bomb[r][c] = 0; prog.bombs++;
      popups.push({ x, y, text: 'Defused!', t: 0, size: 26, color: '#86e391' });
      Sfx.defuse();
    }
    if (gem[r][c]) {
      gem[r][c] = 0; prog.gems++;
      flyers.push({ x, y, t: 0 });
      Sfx.gem();
    }
    clearCell(r, c, delay);
  });
  markDirty();
}
function place(i, r, c) {
  const p = tray[i];
  for (const [dr, dc] of p.shape.cells) { grid[r + dr][c + dc] = p.color + 1; bounces.set((r + dr) * N + c + dc, 0); }
  boardPop = 0;
  score += p.shape.cells.length;
  Sfx.place(p.shape.cells.length); Haptic.light();

  const { rows, cols } = linesToClear();
  const lines = rows.length + cols.length;
  if (lines) {
    const set = new Set();
    rows.forEach(rr => { for (let cc = 0; cc < N; cc++) set.add(rr * N + cc); });
    cols.forEach(cc => { for (let rr = 0; rr < N; rr++) set.add(rr * N + cc); });
    flashes.push({ rows, cols, t: 0, or: r + p.shape.h / 2, oc: c + p.shape.w / 2 });
    hitCells(set, [r + p.shape.h / 2, c + p.shape.w / 2]);
    prog.lines += lines;
    streak++; sinceClear = 0;
    const gain = 10 * lines * lines * streak;
    score += gain;
    shake = Math.min(13, 2 + lines * 2.2 + streak * 0.9);
    const cx = bx + (c + p.shape.w / 2) * cell, cy = by + (r + p.shape.h / 2) * cell;
    popups.push({ x: cx, y: cy, text: '+' + gain, t: 0, size: 36 });
    rings.push({ x: cx, y: cy, t: 0, max: bs * (0.55 + lines * 0.18) });
    // graded praise callout — pops bigger and brighter as the combo builds
    const tier = Math.max(0, Math.min(PRAISE.length - 1, (streak - 1) + (lines - 1)));
    // Spoken callout on EVERY clear (Block-Blast style): "Nice!" for a plain clear,
    // climbing to "Great!/Amazing!/Insane!" as lines and combo streak build.
    popups.push({ x: W / 2, y: by + bs / 2 - 8, text: PRAISE[tier], t: 0, size: 44 + Math.min(tier, 6) * 3, color: PRAISE_COLOR[tier % PRAISE_COLOR.length], rot: (Math.random() - 0.5) * 0.12 });
    rings.push({ x: W / 2, y: by + bs / 2, t: 0, max: bs * 0.9 });
    Sfx.praise(tier);
    if (streak >= 2) popups.push({ x: W / 2, y: by + bs / 2 + 50, text: 'Combo x' + streak, t: 0, size: 40, color: '#ffcf3f', rot: 0.05 });
    Sfx.clear(lines, streak);
    if (streak >= 2) Sfx.combo(streak);
    if (grid.every(row => row.every(v => !v))) {
      score += 300;
      popups.push({ x: W / 2, y: by + bs / 2 + 98, text: 'Perfect +300', t: 0, size: 40, color: '#76ccff' });
      Sfx.perfect();
    }
    if (lines > 1) Haptic.heavy(); else Haptic.medium();
  } else {
    sinceClear++;
    if (sinceClear >= 3) streak = 0;
  }

  tray[i] = null;
  if (tray.every(x => !x)) refill();
  markDirty();

  if (mode === 'endless') {
    if (score > save.best) { save.best = score; persist(); }
    if (!anyFits()) { over = true; setTimeout(showGameOver, 700); }
  } else {
    afterLevelMove();
  }
}
function afterLevelMove() {
  movesLeft--; movesBump = 1;
  if (goalsDone()) return win();
  let boom = false;
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    if (grid[r][c] === BOMB) { bomb[r][c]--; if (bomb[r][c] <= 0) boom = true; }
  }
  if (boom) { shake = 18; Sfx.explode(); Haptic.error(); return lose('Boom!', 'A bomb went off.'); }
  if (movesLeft <= 0) return lose('Out of moves', 'So close! Here is how far you got:');
  // The pieces in hand no longer fit, but the player still has moves. Instead of
  // ending the level under them (which feels like it quit on its own), deal a fresh
  // hand that fits, so the move counter stays the real limit. Only a board with no
  // empty cell at all is a true dead end.
  if (!anyFits()) {
    refill();
    if (!anyFits()) return lose('No space left', 'The board is completely full. Here is how far you got:');
  }
}
function win() {
  over = true;
  const ratio = movesLeft / lv.moves;
  const stars = ratio >= 0.3 ? 3 : ratio >= 0.1 ? 2 : 1;
  const coins = 10 + stars * 5;
  save.stars[lv.L] = Math.max(save.stars[lv.L] || 0, stars);
  save.unlocked = Math.max(save.unlocked, lv.L + 1);
  save.coins += coins; save.wins++;
  persist();
  for (let k = 0; k < 100; k++) {
    particles.push({ x: Math.random() * W, y: -20 - Math.random() * 240, vx: (Math.random() - 0.5) * 120, vy: 80 + Math.random() * 200,
      life: 2.4, max: 2.4, color: COLORS[k % COLORS.length], s: 7 + Math.random() * 6, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 10, confetti: true });
  }
  Sfx.win(); Haptic.success();
  setTimeout(() => {
    const st = document.querySelectorAll('#win .ws');
    st.forEach(s => s.classList.remove('on'));
    st.forEach((s, k) => { if (k < stars) setTimeout(() => { s.classList.add('on'); Sfx.star(k); Haptic.medium(); }, 350 + k * 320); });
    document.getElementById('winRibbon').textContent = 'Level ' + lv.L;
    const nm = save.name && save.name !== 'Player' ? save.name : '';
    document.getElementById('winTitle').textContent = nm
      ? [`Nice, ${nm}!`, `Great job, ${nm}!`, `Perfect, ${nm}!`][stars - 1]
      : ['Level clear', 'Great job!', 'Perfect!'][stars - 1];
    document.getElementById('winCoins').textContent = '+' + coins;
    const dbl = document.getElementById('winDouble');
    dbl.hidden = false;
    dbl.onclick = () => Ads.showRewarded(() => {
      save.coins += coins; persist(); dbl.hidden = true; Sfx.reward();
      document.getElementById('winCoins').textContent = '+' + coins * 2;
    }, noAd);
    show('win');
  }, 900);
}
function lose(title, sub) {
  over = true;
  setTimeout(() => {
    Sfx.lose();
    document.getElementById('loseTitle').textContent = title;
    document.getElementById('loseSub').textContent = sub;
    const lg = document.getElementById('loseGoals');
    lg.innerHTML = lv.goals.map(g => goalCard(g, true)).join('');
    hydrateIcons(lg);
    document.getElementById('loseCont').hidden = continues >= 2;
    show('lose');
  }, 650);
}
function clearCross() {
  const set = new Set();
  for (let k = 0; k < N; k++) [[3, k], [4, k], [k, 3], [k, 4]].forEach(([r, c]) => set.add(r * N + c));
  hitCells(set, [3.5, 3.5]);
}
function continueLevel() {
  continues++;
  movesLeft += 5;
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (grid[r][c] === BOMB) bomb[r][c] = Math.max(bomb[r][c], 5);
  if (!anyFits()) { clearCross(); if (!anyFits()) refill(); }
  over = false;
  show(null);
}
function showGameOver() {
  Sfx.lose();
  document.getElementById('ovScore').textContent = score;
  document.getElementById('ovBest').textContent = 'Best ' + save.best;
  document.getElementById('btnCont').hidden = continues >= 1;
  show('over');
}
function continueEndless() {
  continues++;
  clearCross();
  refill();
  over = false;
  show(null);
}

// ---------------- HAMMER BOOSTER ----------------
function setHammer(on) {
  hammerMode = on;
  document.getElementById('btnHammer').classList.toggle('active', on);
}
function useHammer(r, c) {
  const set = new Set();
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
    const rr = r + dr, cc = c + dc;
    if (rr >= 0 && cc >= 0 && rr < N && cc < N) set.add(rr * N + cc);
  }
  if (save.hammers > 0) save.hammers--; else save.coins -= HAMMER_COST;
  persist();
  hitCells(set, [r, c]);
  setHammer(false);
  shake = 12;
  Sfx.hammer(); Haptic.heavy();
  if (mode === 'level' && goalsDone()) win();
}
document.getElementById('btnHammer').onclick = () => {
  if (over || mode === 'menu') return;
  if (hammerMode) return setHammer(false);
  if (save.hammers <= 0 && save.coins < HAMMER_COST) {
    Ads.showRewarded(() => {
      save.coins += HAMMER_COST; persist(); Sfx.reward();
      popups.push({ x: W / 2, y: by + bs / 2, text: `+${HAMMER_COST} coins`, t: 0, size: 38, color: '#ffcf3f' });
    }, noAd);
    return;
  }
  setHammer(true);
  popups.push({ x: W / 2, y: by + bs / 2, text: 'Tap a block to smash', t: 0, size: 26, color: '#fff6e6' });
};

// ---------------- INPUT ----------------
function trayIndexAt(x) { return Math.min(2, Math.max(0, Math.floor((x - bx) / (bs / 3)))); }
// Very forgiving "magnetic" placement for a relaxing feel:
//  - looks for the nearest free spot within SNAP_RADIUS cells of where the piece hovers
//  - sticky: keeps the current spot until another one is clearly closer, so the preview never flickers
//  - the dragged piece is pulled towards that spot while dragging (see frame), so what you see is where it lands
let snapCache = null;   // { key, res } recomputed only when the finger moves
let stickyTarget = null;
function dragTarget() {
  if (!drag) { stickyTarget = null; return null; }
  const key = drag.i + ':' + Math.round(drag.x) + ':' + Math.round(drag.y);
  if (snapCache && snapCache.key === key) return snapCache.res;
  const s = tray[drag.i].shape;
  const left = drag.x - s.w * cell / 2, top = drag.y - cell * 1.3 - s.h * cell;
  const fc = (left - bx) / cell, fr = (top - by) / cell;
  const c0 = Math.round(fc), r0 = Math.round(fr);
  const dist = (r, c) => (r - fr) * (r - fr) + (c - fc) * (c - fc);
  let best = null, bestD = SNAP_RADIUS * SNAP_RADIUS;
  for (let dr = -3; dr <= 3; dr++) for (let dc = -3; dc <= 3; dc++) {
    const r = r0 + dr, c = c0 + dc;
    const d = dist(r, c);
    if (d <= bestD && canPlace(s, r, c)) { bestD = d; best = { r, c }; }
  }
  // hysteresis: stay on the previous spot unless the new one is clearly better
  if (stickyTarget && stickyTarget.i === drag.i && canPlace(s, stickyTarget.r, stickyTarget.c)) {
    const sd = dist(stickyTarget.r, stickyTarget.c);
    if (sd <= (SNAP_RADIUS + 0.6) * (SNAP_RADIUS + 0.6) && (!best || sd - bestD < 0.55)) best = { r: stickyTarget.r, c: stickyTarget.c };
  }
  stickyTarget = best ? { i: drag.i, r: best.r, c: best.c } : null;
  snapCache = { key, res: best };
  return best;
}
const SNAP_RADIUS = 2.4;
cvs.addEventListener('pointerdown', e => {
  if (over || mode === 'menu' || landing) return;
  const x = e.clientX, y = e.clientY;
  if (hammerMode) {
    const c = Math.floor((x - bx) / cell), r = Math.floor((y - by) / cell);
    if (r >= 0 && c >= 0 && r < N && c < N) useHammer(r, c);
    return;
  }
  if (y < trayY - 20) return;
  const i = trayIndexAt(x);
  if (!tray[i]) return;
  if (returning && returning.i === i) returning = null;
  drag = { i, x, y, t: 0 };
  cvs.setPointerCapture(e.pointerId);
  Sfx.pick(); Haptic.light();
});
cvs.addEventListener('pointermove', e => { if (drag) { drag.x = e.clientX; drag.y = e.clientY; } });
cvs.addEventListener('pointerup', () => {
  if (!drag) return;
  const t = dragTarget(), d = drag;
  drag = null; ghost = null;
  if (t) {
    const sh = tray[d.i].shape;
    landing = { i: d.i, r: t.r, c: t.c, x: d.drawX != null ? d.drawX : d.x, y: d.drawY != null ? d.drawY : d.y - cell * 1.3 - sh.h * cell / 2, s: cell * (0.6 + 0.4 * easeOutBack(d.t)), t: 0 };
  } else {
    Sfx.drop();
    const sh = tray[d.i].shape, s = Math.min(cell * 0.56, (bs / 3 - 14) / 5);
    returning = { i: d.i, x: d.x, y: d.y - cell * 1.3 - sh.h * cell / 2, s0: cell * (0.6 + 0.4 * easeOutBack(d.t)), s1: s, t: 0 };
  }
});
cvs.addEventListener('pointercancel', () => { drag = null; });

// ---------------- SCREENS ----------------
const OVERLAYS = ['menu', 'map', 'intro', 'win', 'lose', 'over', 'daily', 'settings', 'name'];
function show(id) {
  OVERLAYS.forEach(o => document.getElementById(o).classList.toggle('show', o === id));
  document.getElementById('hud').style.visibility = (mode === 'menu') ? 'hidden' : 'visible';
}
function setHud(t) { document.getElementById('hudTitle').textContent = t; }
function menuTheme() { return THEMES[Math.floor((save.unlocked - 1) / 10) % THEMES.length]; }
function avatarHtml(i) { return `<span class="ava a${i}"><i class="ey"></i><i class="ey"></i><i class="mo"></i></span>`; }
function updatePlayerCard() {
  document.getElementById('mAva').innerHTML = avatarHtml(save.avatar || 0);
  document.getElementById('mName').textContent = save.name || 'Player';
  document.getElementById('mPcLv').textContent = 'Level ' + save.unlocked;
}
function openMenu() {
  mode = 'menu';
  document.getElementById('mPlayLv').textContent = 'Level ' + save.unlocked;
  document.getElementById('msStars').textContent = totalStars();
  document.getElementById('msCoins').textContent = save.coins;
  document.getElementById('msBest').textContent = save.best;
  updatePlayerCard();
  show('menu');
  // First run: greet the player and ask for a name before anything else.
  if (!save.name) { setTimeout(() => { if (mode === 'menu') openName(true); }, 400); return; }
  document.getElementById('mDaily').classList.toggle('has', !!dailyState());
  if (!dailyShown && dailyState()) { dailyShown = true; setTimeout(() => { if (mode === 'menu') openDaily(); }, 450); }
}
// ---------------- DAILY REWARD ----------------
const DAILY = [
  { coins: 40 }, { coins: 60 }, { hammers: 1 }, { coins: 80 }, { coins: 100 }, { hammers: 2 }, { coins: 250, hammers: 1 },
];
let dailyShown = false;
function dayStr(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function dailyState() {
  const today = dayStr(new Date());
  if (save.daily.last === today) return null;
  const y = new Date(); y.setDate(y.getDate() - 1);
  const streak = save.daily.last === dayStr(y) ? save.daily.streak : 0;
  return { day: streak % 7, streak, today };
}
function rewardHtml(r, big) {
  let s = '';
  if (r.coins) s += `<div class="dr"><i data-icon="coin"></i>${r.coins}</div>`;
  if (r.hammers) s += `<div class="dr"><i data-icon="hammer"></i>x${r.hammers}</div>`;
  return big ? `<div class="chest">${s}</div>` : s;
}
function openDaily() {
  const st = dailyState();
  if (!st) return false;
  const grid = document.getElementById('dailyGrid');
  grid.innerHTML = DAILY.map((r, i) =>
    `<div class="dtile${i < st.day ? ' past' : ''}${i === st.day ? ' today' : ''}${i === 6 ? ' big' : ''}">
       <span class="dday">Day ${i + 1}</span>${rewardHtml(r, i === 6)}${i < st.day ? '<i class="dcheck" data-icon="check"></i>' : ''}
     </div>`).join('');
  hydrateIcons(grid);
  document.getElementById('dailySub').textContent = st.streak > 0
    ? `${st.streak} day streak! Come back tomorrow to keep it going.`
    : 'Come back every day for bigger rewards.';
  const claim = mult => {
    const s2 = dailyState(); if (!s2) return;
    const r = DAILY[s2.day];
    save.coins += (r.coins || 0) * mult;
    save.hammers += (r.hammers || 0) * mult;
    save.daily = { last: s2.today, streak: s2.streak + 1 };
    persist();
    Sfx.reward(); Haptic.success();
    toast(`You got ${[r.coins ? (r.coins * mult) + ' coins' : '', r.hammers ? (r.hammers * mult) + ' hammer' + (r.hammers * mult > 1 ? 's' : '') : ''].filter(Boolean).join(' + ')}!`);
    openMenu();
  };
  document.getElementById('dailyClaim').onclick = () => claim(1);
  document.getElementById('dailyDouble').onclick = () => Ads.showRewarded(() => claim(2), noAd);
  show('daily');
  return true;
}

// ---------------- SETTINGS ----------------
let verTaps = 0;
document.getElementById('verLabel').onclick = () => {
  if (++verTaps < 7) return;
  verTaps = 0;
  const on = localStorage.getItem('gp_test_ads') !== '1';
  localStorage.setItem('gp_test_ads', on ? '1' : '0');
  document.getElementById('verLabel').textContent = 'v' + WEB_VERSION + (on ? ' · test ads' : '');
  toast(on ? 'Test ads ON for this phone. Restart the app.' : 'Test ads OFF. Restart the app.');
};
function openSettings() {
  const ota = Native.isNative && OTA.status ? OTA.status() : '';
  document.getElementById('verLabel').textContent = 'v' + WEB_VERSION + (Native.isNative ? (Native.P.CapacitorUpdater ? ' · native ✓' : ' · native ✗') : '') + (localStorage.getItem('gp_test_ads') === '1' ? ' · test ads' : '') + (ota ? ' · ota:' + ota : '');
  document.querySelectorAll('#settings .toggle').forEach(t => {
    t.classList.toggle('on', !!save.settings[t.dataset.key]);
    t.onclick = () => {
      const k = t.dataset.key;
      save.settings[k] = !save.settings[k];
      t.classList.toggle('on', save.settings[k]);
      persist(); applySettings();
      if (k === 'vibe' && save.settings.vibe) Haptic.medium();
    };
  });
  show('settings');
}

// Track the visible viewport so open modals shrink to the area above the
// on-screen keyboard (see --kbH/--kbTop in the CSS) instead of the page jumping.
(function keyboardAwareModals() {
  const vv = window.visualViewport;
  if (!vv) return;
  const root = document.documentElement.style;
  const upd = () => {
    root.setProperty('--kbH', Math.round(vv.height) + 'px');
    root.setProperty('--kbTop', Math.round(vv.offsetTop) + 'px');
  };
  vv.addEventListener('resize', upd);
  vv.addEventListener('scroll', upd);
  upd();
})();

// ---------------- NAME / AVATAR ----------------
let nameSel = 0, ageSel = -1;
function openName(first) {
  nameSel = save.avatar || 0;
  ageSel = (typeof save.age === 'number') ? save.age : -1;
  document.getElementById('nameRibbon').textContent = first ? 'Welcome!' : 'Your buddy';
  document.getElementById('nameSub').textContent = first ? 'Pick a buddy, your age and a name' : 'Change your buddy, age or name';
  const pick = document.getElementById('avaPick');
  pick.innerHTML = [0, 1, 2, 3, 4, 5, 6].map(i =>
    `<span class="ava a${i}${i === nameSel ? ' sel' : ''}" data-ava="${i}"><i class="ey"></i><i class="ey"></i><i class="mo"></i></span>`).join('');
  pick.querySelectorAll('.ava').forEach(el => el.onclick = () => {
    nameSel = +el.dataset.ava;
    pick.querySelectorAll('.ava').forEach(a => a.classList.toggle('sel', +a.dataset.ava === nameSel));
    Sfx.pick(); Haptic.light();
  });
  const age = document.getElementById('agePick');
  age.querySelectorAll('button').forEach(el => {
    el.classList.toggle('sel', +el.dataset.age === ageSel);
    el.onclick = () => {
      ageSel = +el.dataset.age;
      age.querySelectorAll('button').forEach(b => b.classList.toggle('sel', +b.dataset.age === ageSel));
      Sfx.pick(); Haptic.light();
    };
  });
  const inp = document.getElementById('nameInput');
  inp.value = save.name || '';
  document.getElementById('nameSkip').hidden = !first;
  show('name');
  // Don't pop the keyboard automatically on a phone — it would shove the modal
  // up the moment it appears. The player taps the field when ready.
  if (!Native.isNative) setTimeout(() => { try { inp.focus(); } catch (e) {} }, 80);
}
function saveName() {
  const v = document.getElementById('nameInput').value.trim().replace(/\s+/g, ' ').slice(0, 12);
  save.name = v || save.name || 'Player';
  save.avatar = nameSel;
  if (ageSel >= 0) { save.age = ageSel; try { localStorage.setItem('gp_age', String(ageSel)); } catch (e) {} }
  persist();
  Sfx.reward(); Haptic.success();
  openMenu();
}
document.getElementById('mPlayer').onclick = () => openName(false);
document.getElementById('nameSave').onclick = saveName;
document.getElementById('nameSkip').onclick = () => { if (!save.name) { save.name = 'Player'; save.avatar = nameSel; persist(); } openMenu(); };
document.getElementById('nameInput').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); saveName(); } });

function smoothPath(p) {
  let d = `M${p[0].x.toFixed(1)},${p[0].y.toFixed(1)}`;
  for (let i = 0; i < p.length - 1; i++) {
    const p0 = p[i - 1] || p[i], p1 = p[i], p2 = p[i + 1], p3 = p[i + 2] || p2;
    d += ` C${(p1.x + (p2.x - p0.x) / 6).toFixed(1)},${(p1.y + (p2.y - p0.y) / 6).toFixed(1)} ${(p2.x - (p3.x - p1.x) / 6).toFixed(1)},${(p2.y - (p3.y - p1.y) / 6).toFixed(1)} ${p2.x.toFixed(1)},${p2.y.toFixed(1)}`;
  }
  return d;
}
function openMap() {
  mode = 'menu';
  show('map');
  const scroll = document.getElementById('mapScroll'), inner = document.getElementById('mapInner');
  const MW = scroll.clientWidth || innerWidth;
  const worlds = Math.ceil(save.unlocked / 10) + 2;   // show more path ahead
  const step = 96, header = 120, secH = header + 10 * step, topPad = 130;
  const totalH = worlds * secH + topPad;
  const amp = Math.min(MW * 0.27, 140);
  const nodeXY = L => {
    const w = Math.floor((L - 1) / 10), i = (L - 1) % 10;
    return { x: MW / 2 + Math.sin(L * 0.9) * amp, y: totalH - (w * secH + header + i * step + step / 2) };
  };
  let html = '';
  for (let w = 0; w < worlds; w++) {
    const th = THEMES[w % THEMES.length];
    html += `<div class="mworld" style="top:${totalH - (w + 1) * secH - (w === worlds - 1 ? topPad : 0)}px;height:${secH + (w === worlds - 1 ? topPad : 0)}px;background:${th.mapBg}">`
      + mapDeco(th, MW, secH + (w === worlds - 1 ? topPad : 0), mulberry32(w * 131 + 7))
      + `<div class="mbanner" style="--rc:${th.rc};--rd:${th.rd}"><small>World ${w + 1}</small>${th.name}</div></div>`;
  }
  const pts = [];
  for (let L = 1; L <= worlds * 10; L++) pts.push(nodeXY(L));
  const d = smoothPath(pts);
  const doneIdx = Math.min(save.unlocked, pts.length) - 1;
  const dDone = doneIdx > 0 ? smoothPath(pts.slice(0, doneIdx + 1)) : '';
  html += `<svg id="mapPath" width="${MW}" height="${totalH}">
    <path d="${d}" fill="none" stroke="rgba(0,0,0,.18)" stroke-width="30" stroke-linecap="round" transform="translate(0 5)"/>
    <path d="${d}" fill="none" stroke="#fff3d6" stroke-width="24" stroke-linecap="round"/>
    <path d="${d}" fill="none" stroke="#e7c48f" stroke-width="4" stroke-dasharray="1 14" stroke-linecap="round"/>
    ${dDone ? `<path d="${dDone}" fill="none" stroke="#ffcf3f" stroke-width="10" stroke-linecap="round"/>` : ''}
  </svg>`;
  for (let L = 1; L <= worlds * 10; L++) {
    const { x, y } = nodeXY(L), th = THEMES[Math.floor((L - 1) / 10) % THEMES.length];
    const locked = L > save.unlocked, cur = L === save.unlocked, st = save.stars[L] || 0;
    const stars = (!locked && !cur) ? `<span class="nstars">${[0, 1, 2].map(k => `<i data-icon="star"${k < st ? '' : ' class="off"'}></i>`).join('')}</span>` : '';
    html += `<button class="node${locked ? ' lock' : ''}${cur ? ' cur' : ''}" data-l="${L}" style="left:${x.toFixed(1)}px;top:${y.toFixed(1)}px;--nc:${th.accent}">`
      + (locked ? '<i data-icon="lock"></i>' : `<span>${L}</span>`) + stars + (cur ? '<i class="pin" data-icon="pin"></i>' : '') + '</button>';
  }
  inner.style.height = totalH + 'px';
  inner.innerHTML = html;
  hydrateIcons(inner);
  document.getElementById('starTxt').textContent = totalStars();
  scroll.scrollTop = nodeXY(save.unlocked).y - scroll.clientHeight * 0.6;
}
document.getElementById('mapInner').addEventListener('click', e => {
  const b = e.target.closest('.node');
  if (b && !b.classList.contains('lock')) startLevel(+b.dataset.l);
});

document.getElementById('mPlay').onclick = () => startLevel(save.unlocked);
document.getElementById('mMap').onclick = openMap;
document.getElementById('mEndless').onclick = startEndless;
// Playful menu touch: tap the GRID POP letters and each one hops with a pop.
document.querySelectorAll('.logo .t').forEach(t => {
  t.style.cursor = 'pointer';
  t.addEventListener('pointerdown', e => {
    e.preventDefault();
    Audio2.init(); Sfx.place(2); Haptic.light();
    t.classList.add('hop');
  });
  t.addEventListener('animationend', () => t.classList.remove('hop'));
});
document.getElementById('mapBack').onclick = openMenu;
document.getElementById('introStart').onclick = () => { show(null); introT = 0; };
document.getElementById('winNext').onclick = () => {
  // no interstitials during the first levels: new players should get hooked first
  if (save.wins >= 8 && save.wins % 3 === 0) Ads.showInterstitial();
  startLevel(lv.L + 1);
};
document.getElementById('winMap').onclick = openMap;
document.getElementById('loseCont').onclick = () => Ads.showRewarded(continueLevel, noAd);
document.getElementById('loseRetry').onclick = () => startLevel(lv.L);
document.getElementById('loseMap').onclick = openMap;
document.getElementById('btnCont').onclick = () => Ads.showRewarded(continueEndless, noAd);
document.getElementById('btnRestart').onclick = () => {
  gamesPlayed++;
  if (gamesPlayed % 3 === 0) Ads.showInterstitial();
  startEndless();
};
document.getElementById('mSettings').onclick = openSettings;
document.getElementById('mDaily').onclick = () => { if (!openDaily()) toast('Already claimed today. See you tomorrow!'); };
document.getElementById('settingsClose').onclick = openMenu;
document.getElementById('dailyLater').onclick = openMenu;
document.getElementById('btnOvMenu').onclick = openMenu;
document.getElementById('btnBack').onclick = () => { if (mode === 'level') openMap(); else openMenu(); };

// ---------------- RENDER ----------------
// Three stacked canvases:
//   #bgc  scene backdrop      redrawn only when the world/theme or screen size changes
//   #bdc  board frame + tiles redrawn only when the board changes; shake/thump are CSS transforms
//   #c    effects             cleared and redrawn every frame, but only moving things live here
const bgCvs = document.getElementById('bgc'), bgCtx = bgCvs.getContext('2d', { alpha: false });
const bdCvs = document.getElementById('bdc'), bdCtx = bdCvs.getContext('2d');
let layerTiles = null, layerMode = null, bdTransform = '';
let headerCv = null, headerCtx = null, headerKey = '';
let landing = null;        // piece gliding from the finger into its slot

function layout() {
  // 2x is visually identical on phones and draws far fewer pixels than 3x
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  W = innerWidth; H = innerHeight;
  for (const [cv, c] of [[cvs, ctx], [bgCvs, bgCtx], [bdCvs, bdCtx]]) {
    cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR);
    c.setTransform(DPR, 0, 0, DPR, 0, 0);
  }
  const safeTop = parseFloat(getComputedStyle(document.getElementById('hud')).paddingTop) || 10;
  const top = safeTop + 56 + 100;
  const trayMin = 150;
  bs = Math.max(200, Math.min(W - 52, H - top - trayMin - 14, 540));
  cell = bs / N;
  bx = (W - bs) / 2;
  by = top + Math.max(0, (H - top - trayMin - 14 - bs) * 0.25);
  trayY = by + bs + 30;
  trayH = Math.max(90, Math.min(H - trayY - 14, cell * 4));
  bdCvs.style.transformOrigin = `${bx + bs / 2}px ${by + bs / 2}px`;
  sceneCv = null; boardCv = null; boardDirty = true; layerTiles = null; headerCv = null; headerKey = '';
  tileCache.clear();
  if (curThemeId) { initAmbient(currentTheme(), W, H); bgDirty = true; }
}
let bgDirty = true;
addEventListener('resize', layout);

function currentTheme() { return mode === 'menu' ? menuTheme() : (mode === 'level' && lv ? lv.theme : CLASSIC); }
function rr(x, y, w, h, r) { rrPath(ctx, x, y, w, h, r); }
function font(size) { return `${size}px "Lilita One", "Arial Rounded MT Bold", sans-serif`; }
function outlined(text, x, y, size, fill, stroke = 'rgba(55,25,10,.7)', lw = size * 0.2) {
  ctx.font = font(size); ctx.lineJoin = 'round';
  ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.strokeText(text, x, y);
  ctx.fillStyle = fill; ctx.fillText(text, x, y);
}
function drawShape(shape, color, cx, cy, s, alpha = 1, base) {
  const ox = cx - shape.w * s / 2, oy = cy - shape.h * s / 2;
  for (const [dr, dc] of shape.cells) drawTile(ctx, ox + dc * s, oy + dr * s, s, color, alpha, base || s);
}
function drawGoalIcon(type, cx, cy, s, now) {
  if (type === 'lines') { const t = s * 0.3; for (let k = 0; k < 3; k++) drawTile(ctx, cx - t * 1.5 + k * t, cy - t / 2, t, [0, 2, 4][k], 1, 16); }
  else if (type === 'score') drawStarShape(ctx, cx, cy, s);
  else if (type === 'gems') drawGem(ctx, cx, cy, s);
  else if (type === 'ice') drawIceTile(ctx, cx - s * 0.42, cy - s * 0.42, s * 0.84, 2, 28);
  else if (type === 'bombs') drawBomb(ctx, cx - s * 0.42, cy - s * 0.42, s * 0.84, null, now);
}
function drawHeader(now) {
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  if (mode === 'endless') {
    drawCrown(ctx, W / 2 - 40, by - 86, 24);
    ctx.textAlign = 'left'; outlined(String(save.best), W / 2 - 24, by - 85, 20, '#ffcf3f', 'rgba(55,25,10,.6)', 5);
    ctx.textAlign = 'center';
    const sb = 1 + Math.min(0.22, (score - displayScore) / 150);
    ctx.save(); ctx.translate(W / 2, by - 44); ctx.scale(sb, sb);
    outlined(String(Math.round(displayScore)), 0, 0, 50, '#fff', 'rgba(55,25,10,.65)', 9);
    ctx.restore();
    return;
  }
  const px = bx - 16, pw = bs + 32, py = by - 98, ph = 66;
  ctx.fillStyle = 'rgba(40,20,10,.35)'; rr(px, py + 6, pw, ph, 22); ctx.fill();
  ctx.fillStyle = '#fff6e6'; rr(px, py, pw, ph, 22); ctx.fill();
  ctx.fillStyle = '#f3dfbf'; rr(px, py + ph - 10, pw, 10, 6); ctx.fill();
  ctx.fillStyle = '#fff6e6'; rr(px, py, pw, ph - 6, 22); ctx.fill();
  ctx.strokeStyle = '#e2b77d'; ctx.lineWidth = 3; rr(px + 1.5, py + 1.5, pw - 3, ph - 3, 20); ctx.stroke();

  const low = movesLeft <= 3;
  const mcx = px + pw - 42, mcy = py + ph / 2 - 1, mr = 25 * (1 + 0.22 * Math.sin(movesBump * Math.PI));
  ctx.fillStyle = low ? '#b23527' : '#1a62a3';
  ctx.beginPath(); ctx.arc(mcx, mcy + 3, mr, 0, 7); ctx.fill();
  const mg = ctx.createLinearGradient(0, mcy - mr, 0, mcy + mr);
  mg.addColorStop(0, low ? '#ff8a7a' : '#6ccfff'); mg.addColorStop(1, low ? '#e8453a' : '#2a92e0');
  ctx.fillStyle = mg; ctx.beginPath(); ctx.arc(mcx, mcy, mr, 0, 7); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(mcx, mcy - mr * 0.5, mr * 0.6, mr * 0.28, 0, 0, 7); ctx.fill();
  outlined(String(movesLeft), mcx, mcy + 2, 26, '#fff', 'rgba(0,0,0,.25)', 4);
  ctx.font = '900 9px Nunito, sans-serif'; ctx.fillStyle = '#4a2c17';
  ctx.fillText('MOVES', mcx, py + ph - 3);

  const gw = (pw - 96) / lv.goals.length;
  lv.goals.forEach((g, i) => {
    const cx = px + 14 + gw * (i + 0.5), cy = py + ph / 2 - 2;
    const cur = Math.min(progOf(g.type), g.target), done = cur >= g.target;
    const gb = 1 + 0.35 * Math.sin((goalBump[g.type] || 0) * Math.PI);
    const txt = `${cur}/${g.target}`;
    ctx.font = font(22);
    const tw = done ? 26 : ctx.measureText(txt).width, iconS = 40, total = iconS + 8 + tw;
    const ix = cx - total / 2 + iconS / 2;
    drawGoalIcon(g.type, ix, cy, iconS * gb, now);
    goalPos[g.type] = { x: ix, y: cy };
    if (done) drawCheck(ctx, ix + iconS / 2 + 8 + 13, cy, 13);
    else {
      ctx.textAlign = 'left'; ctx.fillStyle = '#4a2c17'; ctx.font = font(22);
      ctx.fillText(txt, ix + iconS / 2 + 8, cy + 2);
      ctx.textAlign = 'center';
    }
  });
}
// header is drawn into a cache and only re-rendered when its numbers change (or while it bumps)
function headerState() {
  if (mode === 'endless') return 'e|' + save.best + '|' + Math.round(displayScore) + '|' + Math.round((score - displayScore));
  return 'l|' + movesLeft + '|' + lv.goals.map(g => progOf(g.type)).join(',');
}
function drawHeaderCached(now) {
  const bumping = movesBump > 0 || Object.values(goalBump).some(v => v > 0);
  if (bumping) { drawHeader(now); headerKey = ''; return; }
  const key = headerState();
  if (!headerCv || key !== headerKey) {
    if (!headerCv) [headerCv, headerCtx] = makeCanvas(W, by);
    headerCtx.clearRect(0, 0, W, by);
    const saved = ctx; ctx = headerCtx; drawHeader(now); ctx = saved;
    headerKey = key;
  }
  ctx.drawImage(headerCv, 0, 0, W, by);
}
function drawCellAt(v, r, c, x, y, s, now) {
  if (v === ICE) drawIceTile(ctx, x, y, s, ice[r][c], cell);
  else if (v === BOMB) drawBomb(ctx, x, y, s, bomb[r][c], now);
  else drawTile(ctx, x, y, s, v - 1, 1, cell);
}
// board layer: frame + every tile that is not moving
function drawBoardLayer(th, withTiles) {
  bdCtx.clearRect(0, 0, W, H);
  if (mode !== 'menu' && grid) {
    if (!boardCv) boardCv = buildBoard(th, bs, cell, BOARD_PAD);
    bdCtx.drawImage(boardCv, bx - BOARD_PAD, by - BOARD_PAD, bs + BOARD_PAD * 2, bs + BOARD_PAD * 2);
    if (withTiles) {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const v = grid[r][c];
        if (!v || v === BOMB || bounces.has(r * N + c)) continue;
        const x = bx + c * cell, y = by + r * cell;
        if (v === ICE) drawIceTile(bdCtx, x, y, cell, ice[r][c], cell);
        else drawTile(bdCtx, x, y, cell, v - 1, 1, cell);
      }
    }
    // tray shelf is static too
    bdCtx.fillStyle = 'rgba(30,15,5,.22)'; rrPath(bdCtx, bx - 10, trayY + 4, bs + 20, trayH - 8, 26); bdCtx.fill();
    bdCtx.strokeStyle = 'rgba(255,255,255,.14)'; bdCtx.lineWidth = 2; rrPath(bdCtx, bx - 9, trayY + 5, bs + 18, trayH - 10, 25); bdCtx.stroke();
  }
  boardDirty = false; layerTiles = withTiles; layerMode = mode;
}
function drawMenuTiles(dt) {
  if (menuTiles.length < 14 && Math.random() < dt * 2.2)
    menuTiles.push({ x: Math.random() * W, y: -50, v: 30 + Math.random() * 50, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 1.4, idx: (Math.random() * 7) | 0, s: 24 + Math.random() * 30 });
  menuTiles = menuTiles.filter(t => t.y < H + 60);
  for (const t of menuTiles) {
    t.y += t.v * dt; t.rot += t.vr * dt;
    ctx.save(); ctx.translate(t.x, t.y); ctx.rotate(t.rot);
    drawTile(ctx, -t.s / 2, -t.s / 2, t.s, t.idx, 0.9, 48);
    ctx.restore();
  }
}
function sparkleAt(c, x, y, r, a) {
  c.fillStyle = `rgba(255,252,220,${a})`;
  c.beginPath(); c.moveTo(x, y - r); c.quadraticCurveTo(x, y, x + r, y); c.quadraticCurveTo(x, y, x, y + r);
  c.quadraticCurveTo(x, y, x - r, y); c.quadraticCurveTo(x, y, x, y - r); c.fill();
}

let last = performance.now();
function frame(now) {
  const dt = Math.max(0, Math.min(0.05, (now - last) / 1000)); last = now;
  displayScore += (score - displayScore) * Math.min(1, dt * 10);
  if (Math.abs(score - displayScore) < 0.5) displayScore = score;
  movesBump = Math.max(0, movesBump - dt * 3.5);
  for (const k in goalBump) goalBump[k] = Math.max(0, goalBump[k] - dt * 3);
  if (mode === 'level' && lv) for (const g of lv.goals) {
    const cur = Math.min(progOf(g.type), g.target);
    if (lastProg[g.type] !== undefined && cur > lastProg[g.type]) goalBump[g.type] = 1;
    lastProg[g.type] = cur;
  }
  boardPop = Math.min(1, boardPop + dt * 6);
  if (introT < 1) introT = Math.min(1, introT + dt / 0.85);
  for (const [k, t] of bounces) { if (t + dt > 0.32) { bounces.delete(k); boardDirty = true; } else bounces.set(k, t + dt); }

  const th = currentTheme();
  if (th.id !== curThemeId) {
    curThemeId = th.id; sceneCv = null; boardCv = null; boardDirty = true; headerCv = null; initAmbient(th, W, H);
    Audio2.Music.setTheme(Math.max(0, THEMES.indexOf(th)));
  }
  // ---- background layer (rarely) ----
  if (!sceneCv) { sceneCv = buildScene(th, W, H); bgDirty = true; }
  if (bgDirty) { bgCtx.drawImage(sceneCv, 0, 0, W, H); bgDirty = false; }
  // ---- board layer (only on change) ----
  const wantTiles = introT >= 1;
  if (boardDirty || layerTiles !== wantTiles || layerMode !== mode) drawBoardLayer(th, wantTiles);
  shake = Math.max(0, shake - dt * 40);
  const sx = shake ? (Math.random() - 0.5) * shake : 0, sy = shake ? (Math.random() - 0.5) * shake : 0;
  const bp = 1 - 0.014 * Math.sin(boardPop * Math.PI);
  const tf = (sx || sy || bp !== 1) ? `translate(${sx.toFixed(1)}px,${sy.toFixed(1)}px) scale(${bp.toFixed(4)})` : '';
  if (tf !== bdTransform) { bdCvs.style.transform = tf; bdTransform = tf; }

  // ---- effects layer (every frame) ----
  ctx.clearRect(0, 0, W, H);
  drawAmbient(ctx, dt, now, W, H);

  if (mode === 'menu') {
    drawMenuTiles(dt);
  } else if (grid) {
    drawHeaderCached(now);

    ctx.save();
    if (tf) { ctx.translate(sx, sy); ctx.translate(bx + bs / 2, by + bs / 2); ctx.scale(bp, bp); ctx.translate(-bx - bs / 2, -by - bs / 2); }
    if (hammerMode) {
      ctx.strokeStyle = '#ffcf3f'; ctx.lineWidth = 4; ctx.globalAlpha = 0.5 + 0.5 * Math.sin(now / 140);
      rr(bx - 16, by - 16, bs + 32, bs + 32, 26); ctx.stroke(); ctx.globalAlpha = 1;
    }
    // moving tiles only: level drop-in, landing squash, bombs, gems
    const intro = introT < 1;
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
      const v = grid[r][c];
      if (!v) continue;
      let x = bx + c * cell, y = by + r * cell;
      const b = bounces.get(r * N + c);
      if (intro) {
        const local = clamp01((introT * 0.85 - ((N - 1 - r) * 0.045 + c * 0.012)) / 0.38);
        if (local <= 0) continue;
        y -= (1 - easeOutBack(local)) * (by + cell * (r + 1)) * 0.6;
        drawCellAt(v, r, c, x, y, cell, now);
      } else if (b !== undefined) {
        const k = b / 0.32, w = Math.sin(k * Math.PI) * (1 - k);
        ctx.save(); ctx.translate(x + cell / 2, y + cell);
        ctx.scale(1 + 0.14 * w, 1 - 0.14 * w); ctx.translate(-cell / 2, -cell);
        drawCellAt(v, r, c, 0, 0, cell, now);
        ctx.restore();
      } else if (v === BOMB) drawBomb(ctx, x, y, cell, bomb[r][c], now);
      if (gem[r][c]) drawGem(ctx, x + cell / 2, y + cell / 2, cell * (0.6 + 0.04 * Math.sin(now / 260 + r + c)));
    }

    // drop preview: soft outline + the lines it would clear glow gently
    const t = !hammerMode && !landing && dragTarget();
    if (t) {
      const p = tray[drag.i], key = drag.i + ':' + t.r + ':' + t.c;
      if (!ghost || ghost.key !== key) {
        for (const [dr, dc] of p.shape.cells) grid[t.r + dr][t.c + dc] = p.color + 1;
        const lc = linesToClear();
        for (const [dr, dc] of p.shape.cells) grid[t.r + dr][t.c + dc] = 0;
        if (!ghost) Haptic.light();
        ghost = { key, rows: lc.rows, cols: lc.cols };
      }
      const pulse = 0.5 + 0.5 * Math.sin(now / 160);
      ctx.fillStyle = `rgba(255,255,255,${0.12 + 0.12 * pulse})`;
      ghost.rows.forEach(r => { rr(bx + 2, by + r * cell + 2, bs - 4, cell - 4, cell * 0.22); ctx.fill(); });
      ghost.cols.forEach(c => { rr(bx + c * cell + 2, by + 2, cell - 4, bs - 4, cell * 0.22); ctx.fill(); });
      for (const [dr, dc] of p.shape.cells) {
        const x = bx + (t.c + dc) * cell, y = by + (t.r + dr) * cell;
        drawTile(ctx, x, y, cell, p.color, 0.35, cell);
        ctx.strokeStyle = `rgba(255,255,255,${0.55 + 0.3 * pulse})`; ctx.lineWidth = 2;
        rr(x + cell * 0.08, y + cell * 0.08, cell * 0.84, cell * 0.84, cell * 0.2); ctx.stroke();
      }
    } else if (drag) ghost = null;

    // line clear: a soft beam of light sweeps outwards from where the piece landed
    flashes = flashes.filter(f => (f.t += dt) < 0.5);
    for (const f of flashes) {
      const k = clamp01(f.t / 0.5), reach = easeOutCubic(Math.min(1, k * 1.6)), a = (1 - k) * 0.85;
      for (const r of f.rows) {
        const x0 = bx + f.oc * cell, half = reach * bs;
        const l = Math.max(bx, x0 - half), rgt = Math.min(bx + bs, x0 + half);
        const g = ctx.createLinearGradient(0, by + r * cell, 0, by + (r + 1) * cell);
        g.addColorStop(0, 'rgba(255,255,240,0)'); g.addColorStop(0.5, `rgba(255,255,240,${a})`); g.addColorStop(1, 'rgba(255,255,240,0)');
        ctx.fillStyle = g; ctx.fillRect(l, by + r * cell - cell * 0.15, rgt - l, cell * 1.3);
      }
      for (const c of f.cols) {
        const y0 = by + f.or * cell, half = reach * bs;
        const tp = Math.max(by, y0 - half), bt = Math.min(by + bs, y0 + half);
        const g = ctx.createLinearGradient(bx + c * cell, 0, bx + (c + 1) * cell, 0);
        g.addColorStop(0, 'rgba(255,255,240,0)'); g.addColorStop(0.5, `rgba(255,255,240,${a})`); g.addColorStop(1, 'rgba(255,255,240,0)');
        ctx.fillStyle = g; ctx.fillRect(bx + c * cell - cell * 0.15, tp, cell * 1.3, bt - tp);
      }
    }
    // soft shockwave
    rings = rings.filter(g => (g.t += dt) < 0.55);
    for (const g of rings) {
      const k = g.t / 0.55, rad = easeOutCubic(k) * g.max;
      ctx.strokeStyle = `rgba(255,255,255,${0.45 * (1 - k)})`; ctx.lineWidth = 2 + 8 * (1 - k);
      ctx.beginPath(); ctx.arc(g.x, g.y, rad, 0, Math.PI * 2); ctx.stroke();
    }
    // cleared tiles swell a little, then melt away
    anims = anims.filter(a => (a.t += dt) < 0.36);
    for (const a of anims) {
      const x0 = bx + a.c * cell, y0 = by + a.r * cell;
      if (a.t < 0) {
        if (a.v === ICE) drawIceTile(ctx, x0, y0, cell, a.hp, cell); else if (a.v === BOMB) drawBomb(ctx, x0, y0, cell, null, now); else drawTile(ctx, x0, y0, cell, a.v - 1, 1, cell);
        continue;
      }
      const k = a.t / 0.36, sc = k < 0.35 ? 1 + 0.15 * easeOutCubic(k / 0.35) : 1.15 * (1 - easeOutCubic((k - 0.35) / 0.65)), s = cell * sc;
      const x = x0 + (cell - s) / 2, y = y0 + (cell - s) / 2;
      ctx.globalAlpha = Math.min(1, 1.4 - k * 1.4);
      if (a.v === ICE) drawIceTile(ctx, x, y, s, a.hp, cell);
      else if (a.v === BOMB) drawTile(ctx, x, y, s, 'grey', 1, cell);
      else drawTile(ctx, x, y, s, a.v - 1, 1, cell);
      ctx.globalAlpha = 1;
    }
    ctx.restore();

    // tray: staggered fly-in and a slow idle float
    const ts = Math.min(cell * 0.56, (bs / 3 - 14) / 5);
    for (let i = 0; i < 3; i++) {
      const p = tray[i];
      if (!p || (drag && drag.i === i) || (returning && returning.i === i) || (landing && landing.i === i)) continue;
      p.t = Math.min(1, p.t + dt * 3.2);
      if (p.t <= 0) continue;
      const e = easeOutBack(p.t);
      const cx = bx + bs * (i + 0.5) / 3;
      const cy = trayY + trayH / 2 + (1 - e) * 120 + Math.sin(now / 900 + i * 1.7) * 2;
      const fits = p.fits !== false;
      drawShape(p.shape, fits ? p.color : 'grey', cx, cy, ts * (0.55 + 0.45 * Math.min(1, e)), fits ? 1 : 0.6, ts);
    }
    if (returning) {
      const p = tray[returning.i];
      returning.t += dt;
      const k = easeOutCubic(clamp01(returning.t / 0.3));
      const tx = bx + bs * (returning.i + 0.5) / 3, ty = trayY + trayH / 2;
      if (p) drawShape(p.shape, p.color, returning.x + (tx - returning.x) * k, returning.y + (ty - returning.y) * k, returning.s0 + (returning.s1 - returning.s0) * k, 1, cell);
      if (returning.t >= 0.3) returning = null;
    }
    // landing: the released piece glides into its slot, then settles
    if (landing) {
      const p = tray[landing.i];
      landing.t += dt;
      const k = easeOutCubic(clamp01(landing.t / LAND_TIME));
      const tx = bx + (landing.c + p.shape.w / 2) * cell, ty = by + (landing.r + p.shape.h / 2) * cell;
      drawShape(p.shape, p.color, landing.x + (tx - landing.x) * k, landing.y + (ty - landing.y) * k, landing.s + (cell - landing.s) * k, 1, cell);
      if (landing.t >= LAND_TIME) { const L = landing; landing = null; place(L.i, L.r, L.c); }
    }
    if (drag) {
      const p = tray[drag.i];
      drag.t = Math.min(1, drag.t + dt * 7);
      const s = ts + (cell - ts) * easeOutBack(drag.t);
      let dx = drag.x, cy = drag.y - cell * 1.3 - p.shape.h * cell / 2;
      const snap = dragTarget();
      const pull = snap ? 0.55 : 0;
      drag.pull = (drag.pull || 0) + (pull - (drag.pull || 0)) * Math.min(1, dt * 14);
      // Glide the snap anchor between cells instead of jumping, so the magnetic
      // pull reads as one fluid motion rather than the piece ticking slot to slot.
      if (snap) {
        const tx = bx + (snap.c + p.shape.w / 2) * cell, ty = by + (snap.r + p.shape.h / 2) * cell;
        if (drag.sx == null) { drag.sx = tx; drag.sy = ty; }
        else { const g = Math.min(1, dt * 18); drag.sx += (tx - drag.sx) * g; drag.sy += (ty - drag.sy) * g; }
      } else if (drag.pull < 0.02) { drag.sx = null; }
      if (drag.sx != null && drag.pull > 0.001) { dx += (drag.sx - dx) * drag.pull; cy += (drag.sy - cy) * drag.pull; }
      drag.drawX = dx; drag.drawY = cy;
      ctx.fillStyle = 'rgba(0,0,0,.16)';
      for (const [dr, dc] of p.shape.cells) {
        rr(dx - p.shape.w * s / 2 + dc * s + 4, cy - p.shape.h * s / 2 + dr * s + s * 0.3, s - 8, s - 8, s * 0.2); ctx.fill();
      }
      drawShape(p.shape, p.color, dx, cy, s, 1, cell);
    }

    flyers = flyers.filter(f => (f.t += dt) < 0.65);
    for (const f of flyers) {
      const tgt = goalPos.gems || { x: W / 2, y: 40 }, k = f.t / 0.65, e = k * k * (3 - 2 * k);
      drawGem(ctx, f.x + (tgt.x - f.x) * e, f.y + (tgt.y - f.y) * e - Math.sin(k * Math.PI) * 70, cell * (0.75 - 0.35 * k));
    }
  }

  // particles: little candy pieces, sparkles and confetti
  particles = particles.filter(q => (q.life -= SHOT ? 0 : dt) > 0);
  for (const q of particles) {
    if (!SHOT) { q.vy += (q.confetti ? 120 : q.spark ? -20 : 600) * dt; q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.vr * dt; if (q.spark) { q.vx *= 0.92; q.vy *= 0.92; } }
    const lifeK = q.life / q.max;
    if (q.spark) { sparkleAt(ctx, q.x, q.y, q.s * Math.sin(lifeK * Math.PI), Math.min(1, lifeK * 2)); continue; }
    ctx.globalAlpha = Math.min(1, lifeK * 1.6);
    ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.rot);
    if (q.idx != null) { const s = q.s * (0.6 + 0.4 * lifeK); drawTile(ctx, -s / 2, -s / 2, s, q.idx, 1, 24); }
    else { ctx.fillStyle = q.color; if (q.confetti) ctx.fillRect(-q.s / 2, -q.s / 4, q.s, q.s / 2); else { rr(-q.s / 2, -q.s / 2, q.s, q.s, q.s * 0.25); ctx.fill(); } }
    ctx.restore();
  }
  ctx.globalAlpha = 1;

  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  popups = popups.filter(q => (q.t += SHOT ? 0 : dt) < 1.15);
  for (const q of popups) {
    const k = q.t / 1.15;
    const sc = q.t < 0.18 ? 0.4 + (q.t / 0.18) * 0.8 : q.t < 0.3 ? 1.2 - ((q.t - 0.18) / 0.12) * 0.2 : 1;
    ctx.globalAlpha = 1 - Math.pow(k, 3);
    ctx.save(); ctx.translate(q.x, q.y - k * 46); ctx.rotate(q.rot || 0); ctx.scale(sc, sc);
    outlined(q.text, 0, 0, q.size, q.color || '#fff', 'rgba(55,25,10,.75)', q.size * 0.22);
    ctx.restore();
  }
  ctx.globalAlpha = 1;

  requestAnimationFrame(frame);
}
const LAND_TIME = 0.12;

// ---------------- SCREENSHOT MODE (store images; only via #shot=<scene>) ----------------
const SHOT = (location.hash.match(/^#shot=(\w+)/) || [])[1] || null;
function stageBoard(cells) {
  // cells: array of strings, '.' empty, 0-6 colour, I ice, B bomb, G gem on colour 4
  cells.forEach((row, r) => [...row].forEach((ch, c) => {
    if (ch === '.') return;
    if (ch === 'I') { grid[r][c] = ICE; ice[r][c] = 2; }
    else if (ch === 'i') { grid[r][c] = ICE; ice[r][c] = 1; }
    else if (ch === 'B') { grid[r][c] = BOMB; bomb[r][c] = 4; }
    else if (ch === 'G') { grid[r][c] = 5; gem[r][c] = 1; }
    else grid[r][c] = +ch + 1;
  }));
}
function setupShot(scene) {
  dailyShown = true;
  Object.assign(save, { unlocked: 14, coins: 1250, best: 4820, hammers: 2,
    stars: { 1: 3, 2: 3, 3: 2, 4: 3, 5: 3, 6: 2, 7: 3, 8: 3, 9: 3, 10: 2, 11: 3, 12: 3, 13: 2 } });
  updateCoins();
  const shape = s => SHAPES[SHAPE_DEFS.indexOf(s)];
  const level = (L, board, trayDefs, extra) => {
    startLevel(L); show(null);
    grid = mk(0); ice = mk(0); gem = mk(0); bomb = mk(0);
    stageBoard(board);
    tray = trayDefs.map(([s, col]) => ({ shape: shape(s), color: col, t: 1 }));
    introT = 1; markDirty();
    if (extra) extra();
  };
  if (scene === 'menu') { openMenu(); return; }
  if (scene === 'map') { openMap(); return; }
  if (scene === 'daily') { const y = new Date(); y.setDate(y.getDate() - 1); save.daily = { last: dayStr(y), streak: 3 }; openMenu(); openDaily(); return; }
  if (scene === 'play') {
    level(4, [
      '........', '..3.....', '.334....', '0000.000', '1122.155', '.5.2..66', '.556....', '4444.444'
    ], [['X\nX\nX\nX\nX', 4], ['XX\nXX', 1], ['X..\nXXX', 6]], () => {
      movesLeft = 14; score = displayScore = 96;
      drag = { i: 0, x: bx + 4.5 * cell, y: by + 8 * cell + cell * 1.3 + 0.2 * cell, t: 1 };
      popups.push({ x: W / 2, y: by + bs * 0.28, text: 'Combo x3', t: 0.3, size: 46, color: '#ffcf3f', rot: -0.08 });
    });
    return;
  }
  if (scene === 'gems') {
    level(15, [
      '.G..1...', '22G.11..', '.2..3G..', '........', '5..G.0..', '55.GG00.', '..6..G..', '.666....'
    ], [['XXX', 2], ['X.\nXX', 3], ['XX', 0]], () => { movesLeft = 19; lv.goals = [{ type: 'gems', target: 8 }]; prog.gems = 2; });
    return;
  }
  if (scene === 'ice') {
    level(24, [
      'I.....iI', '.I...I..', '..2.i...', '1.22..3.', '1..I.33.', '..i...I.', '.I..5...', 'I.....iI'
    ], [['XXXX', 4], ['XX\nX.', 0], ['XXX\n.X.', 5]], () => { movesLeft = 22; lv.goals = [{ type: 'ice', target: 16 }]; prog.ice = 3; });
    return;
  }
  if (scene === 'bombs') {
    level(34, [
      '........', '.0...B..', '.00..1..', '..2.11..', 'B.22....', '...3..4.', '.33..44B', '........'
    ], [['XX\nXX', 6], ['X\nX\nX', 1], ['XXX\n..X', 3]], () => { movesLeft = 11; lv.goals = [{ type: 'bombs', target: 3 }, { type: 'lines', target: 8 }]; prog.lines = 3; });
    return;
  }
  if (scene === 'win') {
    level(9, ['........', '........', '........', '........', '........', '........', '........', '........'], [['X', 0], ['X', 1], ['X', 2]]);
    document.getElementById('winRibbon').textContent = 'Level 9';
    document.getElementById('winTitle').textContent = 'Perfect!';
    document.getElementById('winCoins').textContent = '+25';
    document.querySelectorAll('#win .ws').forEach(s => s.classList.add('on'));
    for (let k = 0; k < 90; k++) particles.push({ x: Math.random() * W, y: Math.random() * H, vx: 0, vy: 0, life: 9, max: 9,
      color: COLORS[k % COLORS.length], s: 7 + Math.random() * 6, rot: Math.random() * 6, vr: 0, confetti: true });
    show('win');
  }
}

// ---------------- BOOT ----------------
hydrateIcons();
Haptic.enabled = save.settings.vibe;
window.__musicOn = save.settings.music;
Ads.init();
OTA.check();
layout();
updateCoins();
if (SHOT) { document.documentElement.classList.add('shot'); setupShot(SHOT); } else openMenu();
requestAnimationFrame(frame);
if (document.fonts) document.fonts.ready.then(() => { boardCv = null; });
